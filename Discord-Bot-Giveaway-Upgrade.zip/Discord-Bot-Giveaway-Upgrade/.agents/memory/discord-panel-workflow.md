---
name: Discord panel workflow
description: The interaction pattern for private Discord administration panels and forms.
---

For this bot, panels are the primary user experience: button clicks open private Discord modals for sensitive input, while embeds keep their controls in the same message. Prefix commands remain available for initial setup and fallback administration.

**Why:** The user explicitly wants clean, private administration instead of exposing ticket, clock, moderation, and giveaway settings in public chat.

**How to apply:** New configurable bot systems should ship with a setup command that posts a button panel, modal handlers for edits/actions, and an expanded `~help` entry that points to the panel.