---
name: Giveaway state handling
description: Durable rules for completing Discord giveaways safely across restarts and concurrent interactions.
---

Persist the final giveaway state and selected winners before sending result messages to Discord. Guard completion per giveaway, deduplicate entrants, and use unbiased random selection; Discord message delivery can fail or arrive more than once.

**Why:** Timers, button clicks, and process restarts can overlap, while Discord messages may be deleted or temporarily unavailable. State must remain authoritative even when delivery is not.

**How to apply:** Keep giveaway completion idempotent, recover overdue records at startup, and treat message edits/announcements as best-effort follow-up work rather than the source of truth.