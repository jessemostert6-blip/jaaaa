---
name: Discord bot transport
description: Why the Discord bot talks to Gateway and REST directly instead of using discord.js.
---

The Discord bot intentionally uses Node's native WebSocket plus Discord's REST API rather than a Discord SDK.

**Why:** The workspace dependency installer rejected the Discord SDK package, while the native transport keeps the API service lightweight and still supports Gateway events, buttons, DMs, channels, roles, bans, and embeds.

**How to apply:** Keep future Discord features inside the existing bot transport unless a package is required for a capability that cannot be implemented safely with the native Gateway and REST APIs.