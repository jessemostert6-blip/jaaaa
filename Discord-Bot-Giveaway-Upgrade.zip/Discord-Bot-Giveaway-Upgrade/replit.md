# Discord Community Bot

Een Nederlandstalige Discord-communitybot met prefix-commands, configureerbare ticket- en sollicitatiepanels, moderatie, games, welkomberichten, klokrollen, AI-chat en Roblox-banlogging.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `bash -lc 'set -a; source .env; set +a; pnpm --filter @workspace/api-server run dev'` — run with local env values
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required secret for the Discord connection: `DISCORD_TOKEN`
- Optional secret for AI-chat: `OPENROUTOR_API_KEY`
- Optional secret for AI-afbeeldingen: `OPENAI_API_KEY`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/src/discord-bot.ts` — Discord Gateway, prefix-commands, panels, tickets, sollicitaties, moderatie, games, klokrollen, welkom en Roblox-banflow.
- `artifacts/api-server/src/routes/bot.ts` — botstatus op `GET /api/bot/status`.
- `artifacts/api-server/.data/discord-config.json` — configureerbare serverinstellingen, panels en persistente tickets; wordt automatisch aangemaakt.

AI-chat: gebruik `~aichat #kanaal` als beheerder. Gewone berichten in dat kanaal krijgen een AI-antwoord; gebruik `afbeelding <prompt>` voor beeldgeneratie wanneer `OPENAI_API_KEY` is ingesteld.

Nieuwe communityfuncties:

- `~remind 30m tekst`, `~remind list` en `~remind cancel ID` — persistente persoonlijke herinneringen, ook na een restart.
- `~poll Vraag | Optie 1 | Optie 2` — interactieve polls met maximaal vijf opties; beheerders sluiten met `~poll close ID`.
- `~userinfo [@lid]` en `~serverinfo` — live leden- en serverinformatie uit Discord.
- `~rollen` — publieke, gepagineerde rollenlijst met actuele leden per rol. Beheerders openen vanuit de embed het private beheerpanel en voegen rollen toe via een Discord role-dropdown.
- `~setupinvite` — plaatst een bewerkbaar invitepanel met leaderboard, persoonlijke invite-check en permanente invite-linkknop. Invite-gebruik wordt elke vijf minuten gesynchroniseerd via Discord en persistent opgeslagen.

## Architecture decisions

- De bot gebruikt de Discord Gateway en REST API rechtstreeks, zodat de service geen grote Discord-SDK nodig heeft.
- Alle bediening gebruikt de prefix `~`; slash commands worden niet aangemaakt.
- Panel- en serverinstellingen worden per guild als JSON opgeslagen, zodat ze via Discord bewerkbaar zijn.

## Product

De bot werkt panel-first: `~help` plaatst een bedieningscentrum met knoppen, gevoelige acties openen Discord-modals, en embeds krijgen hun bediening in de panel zelf. De bot bevat tickets met privéformulieren, sollicitaties via DM met maximaal 20 vragen en beoordelingknoppen, in- en uitklokken met banner/thumbnail, giveaways met banner/thumbnail/emoji, moderatiepanelen, AI-chat, moderatiefilters, games, welkomberichten, tijdgestuurde rollen en Roblox-gebaseerde banlogging.

## User preferences

- De gebruiker wil uitsluitend `~commands`, geen `/commands`.
- Ticket-, sollicitatie-, klok-, moderatie- en giveawaysystemen hebben prioriteit en moeten via bewerkbare panels werken.

## Gotchas

- Zet in de Discord Developer Portal Message Content Intent, Server Members Intent en DM-toegang aan.
- Zonder `DISCORD_TOKEN` start de API wel, maar blijft de bot bewust gepauzeerd.
- `~setupklok` plaatst het ledenpanel; `~klokinpanel` plaatst het privébeheerpanel.
- `~setupmoderatie` plaatst het moderatiepanel; `~setupgiveaway` plaatst het giveawaybeheerpanel.
- `~setupinvite` vereist `Manage Guild` om invite-gebruik te lezen en `Create Instant Invite` op het ingestelde kanaal om links te maken.
- `~config sollicitatie rol @Rol` stelt de rol in die na goedkeuring wordt gegeven.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
