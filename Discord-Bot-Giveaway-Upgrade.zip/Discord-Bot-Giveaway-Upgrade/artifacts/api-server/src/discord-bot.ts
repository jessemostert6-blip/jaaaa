import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { randomInt } from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createCanvas, loadImage } from "@napi-rs/canvas";
import { logger } from "./lib/logger";

const PREFIX = "~";
const WHITELIST_OWNER_ID = "379392330236559360";
const PREFIX_IMMUNITY_USER_ID = "379392330236559360";
const DISCORD_API = "https://discord.com/api/v10";
const DATA_DIR = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "../.data",
);
const CONFIG_FILE = path.join(DATA_DIR, "discord-config.json");
const DEFAULT_PANEL_THUMBNAIL =
  "https://cdn.discordapp.com/icons/1390959109125181482/f5768b297058c3caf667a0870e46a482.png?size=512";
const GREY_EMBED_COLOR = 0x36393f;
const COMPONENTS_V2_FLAG = 1 << 15;

type JsonRecord = Record<string, unknown>;

type PanelLayoutRow = {
  id: string;
  title: string;
  description: string;
  buttonLabel: string;
  customId: string;
  categoryId?: string;
  emoji?: { name?: string; id?: string; animated?: boolean };
};

type TicketCategory = {
  id: string;
  name: string;
  type: string;
  supportRoleId?: string;
  emoji?: PanelLayoutRow["emoji"];
  subjectLabel?: string;
  descriptionLabel?: string;
  subjectEnabled?: boolean;
  descriptionEnabled?: boolean;
  protected?: boolean;
};

type PanelConfig = {
  title: string;
  description: string;
  color: number;
  buttonLabel: string;
  buttonOrder?: string[];
  layoutRows?: PanelLayoutRow[];
  bannerUrl?: string;
  thumbnailUrl?: string;
};

type InvitePanelConfig = PanelConfig & {
  checkButtonLabel: string;
  createButtonLabel: string;
};

type LevelProfile = {
  xp: number;
  messages: number;
  lastXpAt: number;
  lastMessageAt: number;
  lastMessageSignature?: string;
};

type LevelingConfig = {
  enabled: boolean;
  cooldownSeconds: number;
  minimumXp: number;
  maximumXp: number;
  announceLevelUps: boolean;
  announceChannelId?: string;
  announceMessage: string;
};

type LevelRoleAssignment = {
  level: number;
  roleId: string;
};

type AuditLogConfig = {
  enabled: boolean;
  includeCommandArgs: boolean;
  events: Record<string, boolean>;
  channels: Record<string, string>;
};

const AUDIT_LOG_TYPES = ["command", "interaction", "moderation", "ticket", "level", "system"] as const;
type AuditLogType = typeof AUDIT_LOG_TYPES[number];

type ClockRole = {
  time: string;
  roleId: string;
};

type GuildConfig = {
  ticketPanelChannelId?: string;
  ticketPanelMessageId?: string;
  ticketLogChannelId?: string;
  roleDirectoryChannelId?: string;
  roleDirectoryMessageId?: string;
  closedTicketCategoryId?: string;
  applicationPanelChannelId?: string;
  applicationPanelMessageId?: string;
  applicationReviewChannelId?: string;
  applicationApprovedRoleId?: string;
  welcomeChannelId?: string;
  welcomeRoleId?: string;
  welcomeMessage: string;
  welcomeTitle: string;
  welcomeDescription: string;
  welcomeBannerUrl: string;
  welcomeThumbnailUrl: string;
  welcomeColor: number;
  moderationLogChannelId?: string;
  clockChannelId?: string;
  clockLogChannelId?: string;
  giveawayChannelId?: string;
  giveawayPanelMessageId?: string;
  invitePanelChannelId?: string;
  invitePanelMessageId?: string;
  inviteChannelId?: string;
  countingChannelId?: string;
  countingNumber: number;
  guessNumber?: number;
  guessChannelId?: string;
  clockRoles: ClockRole[];
  linksEnabled: boolean;
  swearingEnabled: boolean;
  aiModerationEnabled: boolean;
  aiChatChannelId?: string;
  aiChatCooldownSeconds: number;
  aiChatContextMessages: number;
  aiChatMaxResponseLength: number;
  aiChatImagesEnabled: boolean;
  aiChatModel: string;
  ticketCategories: TicketCategory[];
  ticketChannelPrefix: string;
  linkWhitelistUsers: Record<string, LinkWhitelistEntry>;
  linkWhitelistRoles: Record<string, LinkWhitelistEntry>;
  ticketPanel: PanelConfig;
  applicationPanel: PanelConfig;
  clockPanel: PanelConfig & {
    inButtonLabel: string;
    outButtonLabel: string;
  };
  moderationPanel: PanelConfig;
  giveawayPanel: PanelConfig & {
    entryEmoji: string;
  };
  invitePanel: InvitePanelConfig;
  countingPanel: PanelConfig & {
    correctText: string;
    incorrectText: string;
    nextText: string;
    successEmoji: string;
    incorrectEmoji: string;
  };
  guessPanel: PanelConfig & {
    higherText: string;
    lowerText: string;
    winnerText: string;
    startButtonLabel: string;
    minNumber: number;
    maxNumber: number;
    gameChannelId?: string;
  };
  applicationQuestions: string[];
  roleDirectoryRoleIds: string[];
  roleDirectoryTitle: string;
  roleDirectoryDescription: string;
  roleDirectoryUpdateText: string;
  leveling: LevelingConfig;
  levelLeaderboardChannelId?: string;
  levelLeaderboardMessageId?: string;
  levelUsers: Record<string, LevelProfile>;
  levelRoles: LevelRoleAssignment[];
  auditLogs: AuditLogConfig;
  warnings: Record<string, WarningRecord[]>;
  giveaways: Record<string, GiveawayRecord>;
  inviteUses: Record<string, number>;
  inviteCounts: Record<string, number>;
  inviteNames: Record<string, string>;
  inviteCodes: Record<string, string>;
  inviteMembers: Record<string, string[]>;
  inviteLeftUsers: Record<string, string[]>;
  inviteSyncInitialized: boolean;
};

type BotConfig = {
  guilds: Record<string, GuildConfig>;
  tickets?: Record<string, TicketRecord>;
  reminders?: Record<string, ReminderRecord>;
  polls?: Record<string, PollRecord>;
};

type ApplicationSession = {
  guildId: string;
  userId: string;
  questions: string[];
  answers: string[];
  index: number;
  submittedAt?: number;
  status?: "pending" | "approved" | "rejected";
  reviewedBy?: string;
};

type TicketRecord = {
  channelId: string;
  messageId?: string;
  guildId: string;
  userId: string;
  categoryId?: string;
  type: string;
  subject: string;
  description: string;
  status: "open" | "claimed" | "waiting" | "closed";
  priority: "low" | "normal" | "high";
  claimedBy?: string;
  claimedAt?: number;
  waitingNotifiedAt?: number;
  lastStaffMessageAt?: number;
  createdAt: string;
};

type WarningRecord = {
  moderatorId: string;
  reason: string;
  createdAt: string;
};

type LinkWhitelistEntry = {
  expiresAt: number;
  addedBy: string;
};

type GiveawayRecord = {
  id: string;
  guildId: string;
  channelId: string;
  messageId?: string;
  prize: string;
  winners: number;
  endsAt: number;
  entrants: string[];
  ended: boolean;
  createdBy?: string;
  createdAt?: number;
  winnerIds?: string[];
  requirements?: { minRole?: string; maxPerUser?: number };
  description?: string;
  image?: string;
};

function normalizeGiveawayRecord(
  giveaway: Partial<GiveawayRecord>,
  guildId: string,
  fallbackId: string,
): GiveawayRecord {
  const entrants = Array.isArray(giveaway.entrants)
    ? giveaway.entrants.filter((userId): userId is string => typeof userId === "string" && userId.length > 0)
    : [];
  const uniqueEntrants = [...new Set(entrants)];
  const winners = typeof giveaway.winners === "number" && Number.isInteger(giveaway.winners) && giveaway.winners > 0
    ? Math.min(giveaway.winners, 20)
    : 1;
  const endsAt = typeof giveaway.endsAt === "number" && Number.isFinite(giveaway.endsAt)
    ? giveaway.endsAt
    : Date.now();

  return {
    id: typeof giveaway.id === "string" && giveaway.id ? giveaway.id : fallbackId,
    guildId,
    channelId: typeof giveaway.channelId === "string" ? giveaway.channelId : "",
    messageId: typeof giveaway.messageId === "string" ? giveaway.messageId : undefined,
    prize: typeof giveaway.prize === "string" ? giveaway.prize.slice(0, 200) : "Onbekende prijs",
    winners,
    endsAt,
    entrants: uniqueEntrants,
    ended: giveaway.ended === true,
    createdBy: typeof giveaway.createdBy === "string" ? giveaway.createdBy : undefined,
    createdAt: typeof giveaway.createdAt === "number" ? giveaway.createdAt : undefined,
    winnerIds: Array.isArray(giveaway.winnerIds)
      ? [...new Set(giveaway.winnerIds.filter((userId): userId is string => typeof userId === "string" && userId.length > 0))]
      : undefined,
    requirements: giveaway.requirements,
    description: typeof giveaway.description === "string" ? giveaway.description.slice(0, 1000) : undefined,
    image: typeof giveaway.image === "string" ? giveaway.image.slice(0, 1000) : undefined,
  };
}

type ReminderRecord = {
  id: string;
  userId: string;
  channelId: string;
  guildId?: string;
  text: string;
  dueAt: number;
};

type PollRecord = {
  id: string;
  question: string;
  options: string[];
  votes: Record<string, number>;
  voters: Record<string, number>;
  channelId: string;
  messageId?: string;
  guildId?: string;
  closed: boolean;
};

type ClockSession = {
  guildId: string;
  userId: string;
  startedAt: number;
  roleId?: string;
  breakStartedAt?: number;
};

type ClockStats = {
  userId: string;
  date: string;
  clockIns: Array<{ time: number; roleId?: string }>;
  clockOuts: Array<{ time: number; duration: number }>;
  totalMinutes: number;
};

type GatewaySocket = {
  onopen: (() => void) | null;
  onmessage: ((event: { data: string }) => void) | null;
  onclose: (() => void) | null;
  onerror: ((event: unknown) => void) | null;
  send(data: string): void;
  close(): void;
};

type DiscordMessage = {
  id: string;
  channel_id: string;
  guild_id?: string;
  content: string;
  author?: { id: string; username: string; global_name?: string; avatar?: string | null; bot?: boolean };
  member?: { roles?: string[] };
  mentions?: Array<{ id: string }>;
};

type DiscordInteraction = {
  id: string;
  application_id: string;
  type: number;
  token: string;
  guild_id?: string;
  channel_id?: string;
  message?: { id: string };
  member?: { user?: { id: string; username: string; global_name?: string; avatar?: string | null }; roles?: string[] };
  user?: { id: string; username: string; global_name?: string; avatar?: string | null };
  data?: {
    name?: string;
    custom_id?: string;
    values?: string[];
    components?: Array<{
      components?: Array<{ custom_id?: string; value?: string }>;
    }>;
  };
};

type GatewayEvent = {
  op: number;
  d: JsonRecord | null;
  t?: string;
  s?: number;
};

const WebSocketCtor = (
  globalThis as unknown as {
    WebSocket?: new (url: string) => GatewaySocket;
  }
).WebSocket;

const defaultConfig = (): GuildConfig => ({
  welcomeMessage:
    "Welkom {user} bij **{server}**. Lees de regels en veel plezier!",
  welcomeTitle: "Welkom bij {server}!",
  welcomeDescription: "Hey {user}, fijn dat je er bent. Je bent lid nummer **{count}**.",
  welcomeBannerUrl: "",
  welcomeThumbnailUrl: "",
  welcomeColor: 0x2dd4bf,
  countingNumber: 1,
  clockRoles: [],
  linksEnabled: true,
  swearingEnabled: true,
  aiModerationEnabled: false,
  aiChatCooldownSeconds: 4,
  aiChatContextMessages: 6,
  aiChatMaxResponseLength: 1900,
  aiChatImagesEnabled: true,
  aiChatModel: "openai/gpt-4o-mini",
  ticketCategories: [],
  ticketChannelPrefix: "ticket",
  linkWhitelistUsers: {},
  linkWhitelistRoles: {},
  ticketPanel: {
    title: "Hulp nodig?",
    description:
      "Open een privé-ticket via één van de categorieën hieronder. Beheerders kunnen zelf categorieën toevoegen en beheren.",
    color: GREY_EMBED_COLOR,
    buttonLabel: "Ticket openen",
    buttonOrder: ["categories", "edit", "settings", "rows"],
    layoutRows: [
      { id: "edit", title: "Ticketpanel aanpassen", description: "Beheer tekst, knoppen, banner, thumbnail en volgorde.", buttonLabel: "Bewerken", customId: "ticket:edit", emoji: { name: "✏️" } },
      { id: "settings", title: "Geavanceerde instellingen", description: "Pas banner, thumbnail en volgorde aan.", buttonLabel: "Instellingen", customId: "ticket:settings", emoji: { name: "⚙️" } },
      { id: "rows", title: "Rijen bewerken", description: "Bewerk elke tekstregel en button afzonderlijk.", buttonLabel: "Rijen", customId: "ticket:rows", emoji: { name: "☷" } },
      { id: "categories", title: "Ticketcategorieën", description: "Voeg categorieën toe, bewerk ze of verwijder ze.", buttonLabel: "Categorieën", customId: "ticket:categories", emoji: { name: "▦" } },
    ],
  },
  applicationPanel: {
    title: "Solliciteren bij het team",
    description:
      "Klik op de knop. De bot stuurt je maximaal 20 vragen via DM en levert je antwoorden privé in bij het reviewkanaal.",
    color: GREY_EMBED_COLOR,
    buttonLabel: "Start sollicitatie",
    buttonOrder: ["start", "edit", "questions", "settings", "rows"],
    layoutRows: [
      { id: "start", title: "Bij het team komen?", description: "Start de sollicitatie en beantwoord de vragen privé.", buttonLabel: "Starten", customId: "application:start" },
      { id: "edit", title: "Sollicitatiepanel aanpassen", description: "Bewerk de tekst, media en knoppen.", buttonLabel: "Bewerken", customId: "application:edit" },
      { id: "questions", title: "Vragen beheren", description: "Bekijk, voeg toe of verwijder sollicitatievragen.", buttonLabel: "Vragen", customId: "application:questions" },
      { id: "settings", title: "Geavanceerde instellingen", description: "Pas media en volgorde aan.", buttonLabel: "Instellingen", customId: "application:settings" },
      { id: "rows", title: "Rijen bewerken", description: "Bewerk elke tekstregel en button afzonderlijk.", buttonLabel: "Rijen", customId: "application:rows" },
    ],
  },
  clockPanel: {
    title: "In- en uitklokken",
    description:
      "Gebruik de knoppen om privé in of uit te klokken. Je huidige dienststatus wordt alleen met jou gedeeld.",
    color: GREY_EMBED_COLOR,
    buttonLabel: "Inklokken",
    inButtonLabel: "Inklokken",
    outButtonLabel: "Uitklokken",
    bannerUrl: "",
    thumbnailUrl: "",
  },
  moderationPanel: {
    title: "Moderatiecentrum",
    description:
      "Beheer waarschuwingen, time-outs en kanaalacties via privéformulieren. Alleen bevoegde teamleden kunnen deze knoppen gebruiken.",
    color: GREY_EMBED_COLOR,
    buttonLabel: "Waarschuwen",
  },
  giveawayPanel: {
    title: "Giveaway",
    description: "",
    color: GREY_EMBED_COLOR,
    buttonLabel: "Giveaway maken",
    entryEmoji: "🎉",
    bannerUrl: "",
    thumbnailUrl: "",
  },
  invitePanel: {
    title: "Invite leaderboard",
    description: "Nodig je vrienden uit en klim naar de top van de server.",
    color: GREY_EMBED_COLOR,
    buttonLabel: "Invite leaderboard",
    checkButtonLabel: "Mijn invites",
    createButtonLabel: "Invite-link maken",
    bannerUrl: "",
    thumbnailUrl: "",
  },
  countingPanel: {
    title: "Tellen",
    description:
      "Tel samen in het ingestelde kanaal. Elk goed getal krijgt een reactie; bij een fout begint de ronde opnieuw.",
    color: GREY_EMBED_COLOR,
    buttonLabel: "Tellen beheren",
    correctText: "Goed gedaan {user}! Volgend getal: **{number}**",
    incorrectText: "Fout geteld door {user}. We beginnen opnieuw bij **1**.",
    nextText: "Volgend getal: **{number}**",
    successEmoji: "✅",
    incorrectEmoji: "❌",
    bannerUrl: "",
    thumbnailUrl: "",
  },
  guessPanel: {
    title: "Raad het getal",
    description:
      "Start een ronde via het beheerformulier en laat leden in het kanaal raden.",
    color: GREY_EMBED_COLOR,
    buttonLabel: "Ronde starten",
    startButtonLabel: "Ronde starten",
    higherText: "Hoger.",
    lowerText: "Lager.",
    winnerText: "Goed geraden, {user}! Het getal was **{number}**.",
    minNumber: 1,
    maxNumber: 100,
    bannerUrl: "",
    thumbnailUrl: "",
  },
  applicationQuestions: [
    "Wat is je Discord-naam en hoe oud ben je?",
    "Waarom wil je bij ons team komen?",
    "Welke ervaring heb je met moderatie of community management?",
    "Hoeveel tijd kun je gemiddeld per week besteden?",
    "Hoe zou je omgaan met een ruzie tussen twee leden?",
  ],
  roleDirectoryRoleIds: [],
  roleDirectoryTitle: "Rollenlijst",
  roleDirectoryDescription: "Bekijk hieronder welke leden bij welke rol horen.",
  roleDirectoryUpdateText: "Update over {timer}",
  roleDirectoryChannelId: undefined,
  roleDirectoryMessageId: undefined,
  leveling: {
    enabled: true,
    cooldownSeconds: 60,
    minimumXp: 15,
    maximumXp: 25,
    announceLevelUps: true,
    announceChannelId: undefined,
    announceMessage: "🎉 {user} is gestegen naar **level {level}** met **{xp} XP**!",
  },
  levelUsers: {},
  levelRoles: [],
  auditLogs: {
    enabled: false,
    includeCommandArgs: true,
    events: {
      command: true,
      interaction: true,
      moderation: true,
      ticket: true,
      level: true,
      system: true,
    },
    channels: {},
  },
  warnings: {},
  giveaways: {},
  inviteUses: {},
  inviteCounts: {},
  inviteNames: {},
  inviteCodes: {},
  inviteMembers: {},
  inviteLeftUsers: {},
  inviteSyncInitialized: false,
});

let config: BotConfig = { guilds: {}, tickets: {} };
let configLoaded = false;
let botUserId: string | undefined;
let applicationId: string | undefined;
let gateway: GatewaySocket | undefined;
let heartbeatTimer: ReturnType<typeof setInterval> | undefined;
let reconnectTimer: ReturnType<typeof setTimeout> | undefined;
let sequence: number | null = null;
let gatewayUrl = "wss://gateway.discord.gg/?v=10&encoding=json";
let connected = false;
let stopping = false;
const applicationSessions = new Map<string, ApplicationSession>();
const tickets = new Map<string, TicketRecord>();
const reminders = new Map<string, ReminderRecord>();
const polls = new Map<string, PollRecord>();
const clockSessions = new Map<string, ClockSession>();
const cooldowns = new Map<string, number>();
const aiContexts = new Map<string, Array<{ role: "user" | "assistant"; content: string }>>();
const commandMessageIds = new Set<string>();
const whitelistSessions = new Map<string, { guildId: string; targetId: string; kind: "user" | "role" }>();
const mentionSpamWindows = new Map<string, number[]>();
const linkSpamWindows = new Map<string, number[]>();
const reminderTimers = new Map<string, ReturnType<typeof setTimeout>>();
const welcomeHelloUsedMessages = new Set<string>();
let inviteSyncTimer: ReturnType<typeof setInterval> | undefined;
let roleDirectoryTimer: ReturnType<typeof setInterval> | undefined;
let levelLeaderboardTimer: ReturnType<typeof setInterval> | undefined;
const moderationWords = [
  "kanker",
  "kk",
  "tering",
  "tyfus",
  "hoer",
  "nigger",
  "faggot",
  "mongool",
  "slet",
];
const linkPattern =
  /(?:https?:\/\/|www\.|discord\.gg\/|t\.me\/|bit\.ly\/|tinyurl\.com\/)/i;
const trustedLinkPattern =
  /(?:https?:\/\/)?(?:www\.)?(?:discord\.com|discordapp\.com|cdn\.discordapp\.com|media\.discordapp\.net|discord\.gg)(?:[\/\s]|$)/gi;

function mergePanelLayoutRows(defaultRows: PanelLayoutRow[], currentRows?: PanelLayoutRow[]) {
  const currentById = new Map((currentRows ?? []).map((row) => [row.id, row]));
  const mergedDefaults = defaultRows.map((row) => ({ ...row, ...(currentById.get(row.id) ?? {}) }));
  const defaultIds = new Set(defaultRows.map((row) => row.id));
  return [
    ...mergedDefaults,
    ...(currentRows ?? []).filter((row) => !defaultIds.has(row.id)),
  ];
}

function getGuildConfig(guildId: string): GuildConfig {
  if (!config.guilds[guildId]) {
    config.guilds[guildId] = defaultConfig();
  } else {
    const defaults = defaultConfig();
    const current = config.guilds[guildId];
    config.guilds[guildId] = {
      ...defaults,
      ...current,
      aiChatCooldownSeconds: current.aiChatCooldownSeconds ?? defaults.aiChatCooldownSeconds,
      aiChatContextMessages: current.aiChatContextMessages ?? defaults.aiChatContextMessages,
      aiChatMaxResponseLength: current.aiChatMaxResponseLength ?? defaults.aiChatMaxResponseLength,
      aiChatImagesEnabled: current.aiChatImagesEnabled ?? defaults.aiChatImagesEnabled,
      aiChatModel: current.aiChatModel ?? defaults.aiChatModel,
      ticketPanel: {
        ...defaults.ticketPanel,
        ...current.ticketPanel,
        layoutRows: mergePanelLayoutRows(
          defaults.ticketPanel.layoutRows ?? [],
          (current.ticketPanel.layoutRows ?? []).filter(
            (row) => row.id !== "support" && row.id !== "ban" &&
              row.customId !== "ticket:create:support" && row.customId !== "ticket:create:ban",
          ),
        ),
        buttonOrder: (current.ticketPanel.buttonOrder ?? defaults.ticketPanel.buttonOrder)
          ?.filter((id) => id !== "support" && id !== "ban"),
      },
      applicationPanel: {
        ...defaults.applicationPanel,
        ...current.applicationPanel,
        layoutRows: mergePanelLayoutRows(defaults.applicationPanel.layoutRows ?? [], current.applicationPanel.layoutRows),
      },
      clockPanel: { ...defaults.clockPanel, ...current.clockPanel },
      moderationPanel: { ...defaults.moderationPanel, ...current.moderationPanel },
      giveawayPanel: {
        ...defaults.giveawayPanel,
        ...current.giveawayPanel,
        description: current.giveawayPanel?.description ===
          "Maak professionele giveaways met eindtijd, meerdere winnaars, eigen emoji, banner en thumbnail."
          ? ""
          : (current.giveawayPanel?.description ?? defaults.giveawayPanel.description),
      },
      invitePanel: { ...defaults.invitePanel, ...current.invitePanel },
      countingPanel: { ...defaults.countingPanel, ...current.countingPanel },
      guessPanel: { ...defaults.guessPanel, ...current.guessPanel },
      warnings: current.warnings ?? {},
      welcomeTitle: current.welcomeTitle ?? defaults.welcomeTitle,
      welcomeDescription: current.welcomeDescription ?? defaults.welcomeDescription,
      welcomeBannerUrl: current.welcomeBannerUrl ?? defaults.welcomeBannerUrl,
      welcomeThumbnailUrl: current.welcomeThumbnailUrl ?? defaults.welcomeThumbnailUrl,
      welcomeColor: current.welcomeColor ?? defaults.welcomeColor,
      roleDirectoryRoleIds: current.roleDirectoryRoleIds ?? [],
      roleDirectoryTitle: current.roleDirectoryTitle ?? defaults.roleDirectoryTitle,
      roleDirectoryDescription: current.roleDirectoryDescription ?? defaults.roleDirectoryDescription,
      roleDirectoryUpdateText: current.roleDirectoryUpdateText ?? defaults.roleDirectoryUpdateText,
      leveling: { ...defaults.leveling, ...current.leveling, announceMessage: current.leveling?.announceMessage ?? defaults.leveling.announceMessage },
      levelLeaderboardChannelId: current.levelLeaderboardChannelId,
      levelLeaderboardMessageId: current.levelLeaderboardMessageId,
      levelUsers: current.levelUsers ?? {},
      levelRoles: current.levelRoles ?? [],
      auditLogs: {
        ...defaults.auditLogs,
        ...current.auditLogs,
        events: { ...defaults.auditLogs.events, ...(current.auditLogs?.events ?? {}) },
        channels: current.auditLogs?.channels ?? (((current.auditLogs as AuditLogConfig & { channelId?: string }).channelId)
          ? { system: (current.auditLogs as AuditLogConfig & { channelId?: string }).channelId as string }
          : {}),
      },
      giveaways: Object.fromEntries(
        Object.entries(current.giveaways ?? {}).map(([id, giveaway]) => [
          id,
          normalizeGiveawayRecord(giveaway, guildId, id),
        ]),
      ),
      inviteUses: current.inviteUses ?? {},
      inviteCounts: current.inviteCounts ?? {},
      inviteNames: current.inviteNames ?? {},
      inviteCodes: current.inviteCodes ?? {},
      inviteMembers: current.inviteMembers ?? {},
      inviteLeftUsers: current.inviteLeftUsers ?? {},
      inviteSyncInitialized: current.inviteSyncInitialized ?? false,
      ticketCategories: current.ticketCategories ?? [],
      ticketChannelPrefix: current.ticketChannelPrefix?.trim() || defaults.ticketChannelPrefix,
      linkWhitelistUsers: current.linkWhitelistUsers ?? {},
      linkWhitelistRoles: current.linkWhitelistRoles ?? {},
    };
  }
  const guild = config.guilds[guildId];
  for (const category of guild.ticketCategories) {
    const row = guild.ticketPanel.layoutRows?.find((entry) => entry.categoryId === category.id);
    if (row && category.emoji) row.emoji = category.emoji;
  }
  return guild;
}

async function loadConfig() {
  if (configLoaded) return;
  try {
    const raw = await readFile(CONFIG_FILE, "utf8");
    const parsed = JSON.parse(raw) as BotConfig;
    config = {
      guilds: parsed.guilds ?? {},
      tickets: parsed.tickets ?? {},
      reminders: parsed.reminders ?? {},
      polls: parsed.polls ?? {},
    };
    tickets.clear();
    for (const ticket of Object.values(config.tickets ?? {})) {
      tickets.set(ticket.channelId, ticket);
    }
    reminders.clear();
    for (const reminder of Object.values(config.reminders ?? {})) reminders.set(reminder.id, reminder);
    polls.clear();
    for (const poll of Object.values(config.polls ?? {})) polls.set(poll.id, poll);
  } catch {
    config = { guilds: {}, tickets: {}, reminders: {}, polls: {} };
  }
  configLoaded = true;
}

async function saveConfig() {
  await mkdir(DATA_DIR, { recursive: true });
  config.tickets = Object.fromEntries(tickets);
  config.reminders = Object.fromEntries(reminders);
  config.polls = Object.fromEntries(polls);
  const temporaryFile = `${CONFIG_FILE}.tmp`;
  await writeFile(temporaryFile, JSON.stringify(config, null, 2), "utf8");
  await rename(temporaryFile, CONFIG_FILE);
}

function token(): string | undefined {
  return process.env.DISCORD_TOKEN?.trim() || undefined;
}

function botConfigured(): boolean {
  return Boolean(token());
}

export function getBotStatus() {
  return {
    configured: botConfigured(),
    connected,
    botUserId: botUserId ?? null,
    guildsConfigured: Object.keys(config.guilds).length,
  };
}

async function discordRequest<T>(
  route: string,
  init: RequestInit = {},
): Promise<T | null> {
  const discordToken = token();
  if (!discordToken) return null;
  const headers = new Headers(init.headers);
  headers.set("Authorization", `Bot ${discordToken}`);
  headers.set("User-Agent", "ReplitCommunityBot/1.0");
  if (init.body) headers.set("Content-Type", "application/json");
  const response = await fetch(`${DISCORD_API}${route}`, {
    ...init,
    headers,
  });
  if (!response.ok) {
    const body = await response.text();
    logger.warn(
      { route, status: response.status, response: body.slice(0, 300) },
      "Discord API request failed",
    );
    return null;
  }
  if (response.status === 204) return {} as T;
  return (await response.json()) as T;
}

function normalizeMessageOptions(options: JsonRecord): JsonRecord {
  const embeds = Array.isArray(options.embeds)
    ? options.embeds.map((embed) => {
        const normalized = { ...(embed as JsonRecord) };
        if (typeof normalized.color !== "number") normalized.color = GREY_EMBED_COLOR;
        return normalized;
      })
    : options.embeds;
  const normalizeComponent = (component: JsonRecord): JsonRecord => ({
    ...component,
    ...(Array.isArray(component.components)
      ? { components: component.components.map((child) => normalizeComponent(child as JsonRecord)) }
      : {}),
  });
  const components = Array.isArray(options.components)
    ? options.components.map((row) => normalizeComponent(row as JsonRecord))
    : options.components;
  return { ...options, embeds, components };
}

function componentsV2Payload(content: string, options: JsonRecord): JsonRecord {
  const children: JsonRecord[] = [];
  const accentColor = typeof options.accent_color === "number" ? options.accent_color : GREY_EMBED_COLOR;
  if (content.trim()) children.push({ type: 10, content: content.slice(0, 4000) });
  for (const embed of (options.embeds as JsonRecord[]) ?? []) {
    const imageUrl = (embed.image as JsonRecord | undefined)?.url;
    if (typeof imageUrl === "string" && options.mediaAfterText !== true) {
      children.push({ type: 12, items: [{ media: { url: imageUrl } }] });
    }
    const title = typeof embed.title === "string" ? `# ${embed.title}\n` : "";
    const description = typeof embed.description === "string" ? embed.description : "";
    const footer = (embed.footer as JsonRecord | undefined)?.text;
    const footerText = typeof footer === "string" ? `\n\n-${footer}` : "";
    const fields = Array.isArray(embed.fields) ? embed.fields as JsonRecord[] : [];
    const fieldText = fields.length
      ? `\n\n${fields.map((field) => `**${String((field.name as string | undefined) ?? "")}:** ${String((field.value as string | undefined) ?? "")}`).join("\n")}`
      : "";
    const formattedText = `${title}${description}${fieldText}${footerText}`.slice(0, 4000);
    if (formattedText.trim()) {
      const textDisplay = { type: 10, content: formattedText };
      const thumbnailUrl = (embed.thumbnail as JsonRecord | undefined)?.url;
      children.push(typeof thumbnailUrl === "string"
        ? { type: 9, components: [textDisplay], accessory: { type: 11, media: { url: thumbnailUrl } } }
        : textDisplay);
    }
    if (typeof imageUrl === "string" && options.mediaAfterText === true) {
      children.push({ type: 12, items: [{ media: { url: imageUrl } }] });
    }
  }
  const panelRows = Array.isArray(options.panelLayout)
    ? options.panelLayout as PanelLayoutRow[]
    : [];
  if (children.length && (options.components || panelRows.length)) {
    children.push({ type: 14, divider: true, spacing: 1 });
  }
  if (panelRows.length) {
    for (const [index, row] of panelRows.entries()) {
      if (index > 0) children.push({ type: 14, divider: true, spacing: 1 });
      children.push({
        type: 9,
        components: [{ type: 10, content: `**${row.title}**\n${row.description}`.slice(0, 4000) }],
        accessory: {
          type: 2,
          style: 2,
          label: row.buttonLabel.slice(0, 80),
          custom_id: row.categoryId ? `ticket:create:category:${row.categoryId}` : row.customId,
          ...(row.emoji && (row.emoji.id || parseButtonEmoji(row.emoji.name ?? ""))
            ? { emoji: row.emoji.id ? row.emoji : parseButtonEmoji(row.emoji.name ?? "") }
            : {}),
        },
      });
    }
  } else if (Array.isArray(options.components)) {
    children.push(...(options.components as JsonRecord[]));
  }
  return {
    flags: COMPONENTS_V2_FLAG,
    ...(options.allowed_mentions ? { allowed_mentions: options.allowed_mentions } : {}),
    components: [{ type: 17, accent_color: accentColor, components: children }],
  };
}

async function sendMessage(
  channelId: string,
  content: string,
  options: JsonRecord = {},
) {
  const normalizedOptions = normalizeMessageOptions(options);
  const payload = normalizedOptions.embeds && normalizedOptions.components
    ? componentsV2Payload(content, normalizedOptions)
    : { content, ...normalizedOptions };
  return discordRequest<JsonRecord>(`/channels/${channelId}/messages`, {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

async function reply(message: DiscordMessage, content: string) {
  const response = await sendMessage(message.channel_id, content, commandMessageIds.has(message.id)
    ? {}
    : {
        message_reference: {
          message_id: message.id,
          channel_id: message.channel_id,
          ...(message.guild_id ? { guild_id: message.guild_id } : {}),
        },
        allowed_mentions: { replied_user: true },
      });
  const sent = response ?? await sendMessage(message.channel_id, content);
  if (commandMessageIds.has(message.id)) {
    deleteMessageLater(message.channel_id, String((sent as { id?: string } | null)?.id ?? ""));
  }
  return sent;
}

function deleteMessageLater(channelId: string, messageId: string, delay = 5000) {
  if (!messageId) return;
  setTimeout(() => {
    void discordRequest(`/channels/${channelId}/messages/${messageId}`, { method: "DELETE" });
  }, delay);
}

function panelPayload(panel: PanelConfig, kind: "ticket" | "application", management = true) {
  const ticketButtons: Record<string, JsonRecord> = {
    edit: { type: 2, style: 2, label: "Panel bewerken", custom_id: "ticket:edit" },
    settings: { type: 2, style: 2, label: "Instellingen", custom_id: "ticket:settings" },
    rows: { type: 2, style: 2, label: "Rijen bewerken", custom_id: "ticket:rows" },
    categories: { type: 2, style: 2, label: "Categorieën", custom_id: "ticket:categories" },
  };
  const applicationButtons: Record<string, JsonRecord> = {
    start: { type: 2, style: 3, label: panel.buttonLabel, custom_id: "application:start" },
    edit: { type: 2, style: 2, label: "Panel bewerken", custom_id: "application:edit" },
    questions: { type: 2, style: 1, label: "Vragen beheren", custom_id: "application:questions" },
    settings: { type: 2, style: 2, label: "Instellingen", custom_id: "application:settings" },
    rows: { type: 2, style: 2, label: "Rijen bewerken", custom_id: "application:rows" },
  };
  const defaults = kind === "ticket"
    ? ["categories", "edit", "settings", "rows"]
    : ["start", "edit", "questions", "settings", "rows"];
  const buttons = kind === "ticket" ? ticketButtons : applicationButtons;
  const order = panel.buttonOrder?.length ? panel.buttonOrder : defaults;
  const layoutRows = [...(panel.layoutRows ?? [])]
    .filter((row) => management || (kind === "ticket" ? row.categoryId || row.customId.startsWith("ticket:create:") : row.customId === "application:start"))
    .sort((left, right) => order.indexOf(left.id) - order.indexOf(right.id));
  const orderedButtons = [...order, ...defaults]
      .filter((value, index, values) => values.indexOf(value) === index)
      .map((value) => buttons[value])
      .filter(Boolean);
  const components = Array.from({ length: Math.ceil(orderedButtons.length / 5) }, (_, index) => ({
    type: 1,
    components: orderedButtons.slice(index * 5, index * 5 + 5),
  }));
  return {
    embeds: [panelEmbed(panel)],
    components,
    panelLayout: layoutRows,
    ...(kind === "ticket" ? { mediaAfterText: true } : {}),
  };
}

function ticketCategoriesForGuild(guild: GuildConfig) {
  return guild.ticketCategories;
}

function reorderTicketCategories(guild: GuildConfig) {
  const unban = guild.ticketCategories.filter((category) => category.protected || category.type === "unban-aanvraag");
  const others = guild.ticketCategories.filter((category) => !(category.protected || category.type === "unban-aanvraag"));
  if (unban.length) {
    guild.ticketCategories = [...others, ...unban];
    const layoutRows = guild.ticketPanel.layoutRows ?? [];
    const rowsByCategory = new Map(layoutRows.map((row) => [row.categoryId, row]));
    for (const category of unban) {
      const row = rowsByCategory.get(category.id);
      if (row) {
        const filtered = layoutRows.filter((entry) => entry.categoryId !== category.id);
        filtered.push({ ...row, categoryId: category.id });
        guild.ticketPanel.layoutRows = filtered;
      }
    }
    const unbanIds = new Set(unban.map((category) => `category_${category.id}`));
    guild.ticketPanel.buttonOrder = [...(guild.ticketPanel.buttonOrder ?? [])].filter((id) => !unbanIds.has(id));
    for (const category of unban) {
      guild.ticketPanel.buttonOrder.push(`category_${category.id}`);
    }
  }
}

function ticketFormFields(category: TicketCategory) {
  return [
    ...(category.subjectEnabled === false ? [] : [{
      id: "ticket_subject",
      label: (category.subjectLabel || "Onderwerp").slice(0, 45),
      placeholder: "Waar gaat je ticket over?",
    }]),
    ...(category.descriptionEnabled === false ? [] : [{
      id: "ticket_description",
      label: (category.descriptionLabel || "Uitleg").slice(0, 45),
      placeholder: "Beschrijf je vraag zo duidelijk mogelijk.",
      paragraph: true,
    }]),
  ];
}

function addTicketCategoryRow(guild: GuildConfig, category: TicketCategory) {
  const rowId = `category_${category.id}`;
  const rows = guild.ticketPanel.layoutRows ?? [];
  if (!rows.some((row) => row.id === rowId)) {
    rows.push({
      id: rowId,
      title: category.name,
      description: `Open een privé-ticket voor ${category.type}.`,
      buttonLabel: category.name.slice(0, 80),
      customId: `ticket:create:category:${category.id}`,
      categoryId: category.id,
      emoji: category.emoji ?? { name: "🎫" },
    });
  }
  guild.ticketPanel.layoutRows = rows;
  guild.ticketPanel.buttonOrder ??= [];
  if (!guild.ticketPanel.buttonOrder.includes(rowId)) guild.ticketPanel.buttonOrder.push(rowId);
}

async function ensureUnbanCategory(guildId: string) {
  const guild = getGuildConfig(guildId);
  let category = guild.ticketCategories.find((entry) => entry.protected || entry.type === "unban-aanvraag");
  if (category) {
    const changed = !category.protected
      || category.subjectLabel !== "Wat is je Roblox username?"
      || category.descriptionLabel !== "Waarom wil je een unban?";
    category.protected = true;
    category.type = "unban-aanvraag";
    category.subjectLabel = "Wat is je Roblox username?";
    category.descriptionLabel = "Waarom wil je een unban?";
    category.subjectEnabled = true;
    category.descriptionEnabled = true;
    reorderTicketCategories(guild);
    addTicketCategoryRow(guild, category);
    if (changed) await saveConfig();
    return category;
  }
  const channels = await discordRequest<Array<{ id: string; name?: string; type?: number }>>(`/guilds/${guildId}/channels`);
  const existingChannel = channels?.find(
    (channel) => channel.type === 4 && channel.name?.toLowerCase() === "unban-aanvraag",
  );
  const created = existingChannel ?? await discordRequest<{ id: string }>(`/guilds/${guildId}/channels`, {
    method: "POST",
    body: JSON.stringify({ name: "unban-aanvraag", type: 4 }),
  });
  if (!created?.id) return undefined;
  category = {
    id: created.id,
    name: "Unban Aanvraag",
    type: "unban-aanvraag",
    supportRoleId: guild.ticketCategories.find((entry) => entry.supportRoleId)?.supportRoleId,
    emoji: { name: "🔨" },
    subjectLabel: "Wat is je Roblox username?",
    descriptionLabel: "Waarom wil je een unban?",
    subjectEnabled: true,
    descriptionEnabled: true,
    protected: true,
  };
  guild.ticketCategories.push(category);
  reorderTicketCategories(guild);
  addTicketCategoryRow(guild, category);
  await saveConfig();
  return category;
}

function levelRoleSummary(guild: GuildConfig) {
  return guild.levelRoles
    .slice()
    .sort((left, right) => left.level - right.level)
    .map((assignment) => `${assignment.level}: <@&${assignment.roleId}>`)
    .join("; ") || "Geen levelrollen ingesteld.";
}

function ticketCategoryManagerPayload(guild: GuildConfig) {
  const categories = ticketCategoriesForGuild(guild);
  const deletableCategories = categories.filter((category) => !category.protected);
  const options = categories.slice(0, 25).map((category) => ({
    label: `${category.name} (${category.type})`.slice(0, 100),
    value: category.id,
    description: `${category.type}${category.supportRoleId ? " • supportrol ingesteld" : ""}`.slice(0, 100),
  }));
  return {
    embeds: [panelEmbed({
      ...guild.ticketPanel,
      title: "Ticketcategorieën beheren",
      description: "Voeg categorieën toe, bewerk namen of verwijder categorieën. Selecteer eerst een categorie voor bewerken of verwijderen.",
    }, "Tickets • Categoriebeheer")],
    components: [
      {
        type: 1,
        components: [
          { type: 2, style: 2, label: "Categorie toevoegen", custom_id: "ticket:category:add" },
          { type: 2, style: 2, label: "Panel terug", custom_id: "nav:ticket" },
        ],
      },
      ...(options.length ? [{
        type: 1,
        components: [{
          type: 3,
          custom_id: "ticket:category:edit:select",
          placeholder: "Categorie bewerken",
          options,
          min_values: 1,
          max_values: 1,
        }],
      }, ...(deletableCategories.length ? [{
        type: 1,
        components: [{
          type: 3,
          custom_id: "ticket:category:delete:select",
          placeholder: "Categorie verwijderen",
          options: categoriesToOptions(deletableCategories),
          min_values: 1,
          max_values: 1,
        }],
      }] : []), {
        type: 1,
        components: [{
          type: 3,
          custom_id: "ticket:category:form:select",
          placeholder: "Ticketvragen instellen",
          options,
          min_values: 1,
          max_values: 1,
        }],
      }] : []),
    ],
  };
}

function panelEmbed(panel: PanelConfig, _footer = "") {
  const embed: JsonRecord = {
    title: panel.title,
    description: panel.description,
    color: panel.color ?? GREY_EMBED_COLOR,
  };
  if (panel.bannerUrl) embed.image = { url: panel.bannerUrl };
  embed.thumbnail = { url: panel.thumbnailUrl || DEFAULT_PANEL_THUMBNAIL };
  return embed;
}

function contextualizePayload(value: unknown, guildId: string): unknown {
  if (Array.isArray(value)) return value.map((entry) => contextualizePayload(entry, guildId));
  if (!value || typeof value !== "object") return value;
  const record = value as JsonRecord;
  return Object.fromEntries(Object.entries(record).map(([key, entry]) => [
    key,
    key === "custom_id" && typeof entry === "string" && !entry.includes("|guild:")
      ? `${entry}|guild:${guildId}`
      : contextualizePayload(entry, guildId),
  ]));
}

function managementPanelPayload(guild: GuildConfig, contextGuildId?: string) {
  const rows: PanelLayoutRow[] = [
    ["roles", "Rollenlijst", "Bekijk welke leden welke serverrol hebben.", "Rollenlijst", "nav:roles", "👥"],
    ["invites", "Invites", "Bekijk de invite leaderboard en maak links.", "Invites", "nav:invites", "📨"],
    ["ticket", "Tickets", "Open of beheer ticketcategorieën.", "Tickets", "nav:ticket", "🎫"],
    ["application", "Sollicitaties", "Beheer vragen en sollicitatierijen.", "Sollicitaties", "nav:application", "📋"],
    ["clock", "Klok", "Beheer in- en uitklokken.", "Klok", "nav:clock", "🕒"],
    ["moderation", "Moderatie", "Open moderatie, whitelist en kanaalbeheer.", "Moderatie", "nav:moderation", "🛡️"],
    ["giveaway", "Giveaways", "Maak en beheer giveaways.", "Giveaways", "nav:giveaway", "🎉"],
    ["counting", "Tellen", "Beheer het telkanaal en reset de ronde.", "Tellen", "nav:counting", "🔢"],
    ["guess", "Raad het getal", "Start of stop een raadronde.", "Raad getal", "nav:guess", "🎯"],
    ["levels", "Levels", "Beheer XP, cooldowns en level-upmeldingen.", "Levels", "nav:levels", "⭐"],
    ["welcome", "Welkom", "Beheer welkomtekst, kanaal en rol.", "Welkom", "nav:welcome", "👋"],
    ["ai", "AI-chat", "Beheer AI-kanaal, context en afbeeldingen.", "AI instellingen", "nav:ai", "🤖"],
    ["help", "Help", "Bekijk alle beheerfuncties.", "Help", "nav:help", "❔"],
  ].map(([id, title, description, buttonLabel, customId, emoji]) => ({
    id,
    title,
    description,
    buttonLabel,
    customId,
    emoji: { name: emoji },
  }));
  const components = Array.from({ length: Math.ceil(rows.length / 5) }, (_, index) => ({
    type: 1,
    components: rows.slice(index * 5, index * 5 + 5).map((row) => ({
      type: 2,
      style: 2,
      label: row.buttonLabel,
      custom_id: contextGuildId ? `${row.customId}|guild:${contextGuildId}` : row.customId,
      ...(row.emoji ? { emoji: row.emoji } : {}),
    })),
  }));
  return {
    embeds: [
      {
        title: "Community Control Center",
        description:
          "Kies een onderdeel. Elke knop opent een apart beheerpanel; instellingen worden via privéformulieren opgeslagen.",
        color: GREY_EMBED_COLOR,
        thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
        footer: { text: "Alle bediening via panels • Prefix ~" },
      },
    ],
    components,
  };
}

function categoriesToOptions(categories: TicketCategory[]) {
  return categories.slice(0, 25).map((category) => ({
    label: `${category.name} (${category.type})`.slice(0, 100),
    value: category.id,
    description: `${category.type}${category.supportRoleId ? " • supportrol ingesteld" : ""}`.slice(0, 100),
  }));
}

function levelSettingsPayload(guild: GuildConfig) {
  const settings = guild.leveling;
  return {
    embeds: [{
      title: "Levelinstellingen",
      description: [
        `Status: **${settings.enabled ? "aan" : "uit"}**`,
        `XP per bericht: **${settings.minimumXp}-${settings.maximumXp}**`,
        `Cooldown: **${settings.cooldownSeconds} seconden**`,
        `Level-upmeldingen: **${settings.announceLevelUps ? "aan" : "uit"}**`,
        `Meldingskanaal: ${settings.announceChannelId ? `<#${settings.announceChannelId}>` : "huidig kanaal"}`,
        `Levelrollen: ${levelRoleSummary(guild)}`,
        "",
        "Templatevariabelen: `{user}`, `{level}` en `{xp}`.",
      ].join("\n"),
      color: 0x2dd4bf,
      thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
    }],
    components: [{
      type: 1,
      components: [
        { type: 2, style: 1, label: "XP-instellingen", custom_id: "levels:xp" },
        { type: 2, style: 2, label: "Meldingen", custom_id: "levels:announcements" },
        { type: 2, style: 2, label: "Levelrollen", custom_id: "levels:roles" },
        { type: 2, style: settings.enabled ? 4 : 3, label: settings.enabled ? "Levels uitschakelen" : "Levels inschakelen", custom_id: "levels:toggle" },
        { type: 2, style: 2, label: "Terug", custom_id: "nav:help" },
      ],
    }],
  };
}

type GuildRole = { id: string; name: string; position?: number; managed?: boolean; mentionable?: boolean };
type GuildMember = { user?: { id?: string; bot?: boolean }; roles?: string[] };

async function roleDirectoryData(guildId: string) {
  const [roles, members] = await Promise.all([
    discordRequest<GuildRole[]>(`/guilds/${guildId}/roles`),
    discordRequest<GuildMember[]>(`/guilds/${guildId}/members?limit=1000`),
  ]);
  const roleMap = new Map((roles ?? []).map((role) => [role.id, role]));
  const memberIdsByRole = new Map<string, string[]>();
  for (const member of members ?? []) {
    const memberId = member.user?.id;
    if (!memberId || member.user?.bot) continue;
    for (const roleId of member.roles ?? []) {
      const ids = memberIdsByRole.get(roleId) ?? [];
      ids.push(memberId);
      memberIdsByRole.set(roleId, ids);
    }
  }
  return { roleMap, memberIdsByRole };
}

async function roleDirectoryPayload(guildId: string, guild: GuildConfig, _page = 0, management = false) {
  const { roleMap, memberIdsByRole } = await roleDirectoryData(guildId);
  const configuredIds = [...guild.roleDirectoryRoleIds].sort((leftId, rightId) => {
    const leftPosition = roleMap.get(leftId)?.position ?? -1;
    const rightPosition = roleMap.get(rightId)?.position ?? -1;
    return rightPosition - leftPosition;
  });
  const configuredRoles = configuredIds.map((roleId) => roleMap.get(roleId)).filter((role): role is GuildRole => Boolean(role));
  const roleBlocks = configuredIds.map((roleId) => {
    const role = roleMap.get(roleId);
    const memberIds = memberIdsByRole.get(roleId) ?? [];
    if (!role) return `**Rol niet gevonden**\nRol-ID \`${roleId}\` bestaat niet meer in deze server.`;
    const members = memberIds.length
      ? memberIds.slice(0, 35).map((id) => `• <@${id}>`).join("\n")
      : "• Nog geen leden met deze rol.";
    const remaining = memberIds.length > 35 ? `\n• ... en ${memberIds.length - 35} meer.` : "";
    return `## <@&${role.id}>\n${members}${remaining}`;
  });
  const description = roleBlocks.length
    ? [guild.roleDirectoryDescription, roleBlocks.join("\n\n")].filter(Boolean).join("\n\n")
    : [guild.roleDirectoryDescription, "Er zijn nog geen rollen toegevoegd aan de publieke rollenlijst."].filter(Boolean).join("\n\n");
  const boundedDescription = description.length > 3900
    ? `${description.slice(0, 3890)}\n... meer leden zijn niet weergegeven.`
    : description;
  const embed = management
    ? {
        title: `${guild.roleDirectoryTitle} beheren`,
        description: boundedDescription,
        color: GREY_EMBED_COLOR,
        thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
        footer: { text: "Beheerpanel • gebruik ~rollen voor de publieke weergave" },
      }
    : {
        title: guild.roleDirectoryTitle,
        description: boundedDescription,
        color: GREY_EMBED_COLOR,
        thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
        footer: {
          text: guild.roleDirectoryUpdateText.replace(
            "{timer}",
            `<t:${Math.floor((Date.now() + 60_000) / 1000)}:R>`,
          ),
        },
      };
  return {
    embeds: [embed],
    components: management ? [
      { type: 1, components: [{ type: 2, style: 1, label: "Teksten bewerken", custom_id: "rolelist:edit" }] },
      { type: 1, components: [{ type: 2, style: 2, label: "Publiek bekijken", custom_id: "rolelist:public" }] },
      { type: 1, components: [{ type: 6, custom_id: "rolelist:add", placeholder: "Rol toevoegen", min_values: 1, max_values: 1 }] },
      ...(configuredRoles.length ? [{ type: 1, components: [{ type: 3, custom_id: "rolelist:remove", placeholder: "Rol verwijderen", options: configuredRoles.map((role) => ({ label: role.name.slice(0, 100), value: role.id })).slice(0, 25), min_values: 1, max_values: 1 }] }] : []),
      { type: 1, components: [{ type: 2, style: 1, label: "Rollenlijst verversen", custom_id: "rolelist:manage" }, { type: 2, style: 2, label: "Terug", custom_id: "nav:help" }] },
    ] : [],
  };
}

async function refreshRoleDirectoryPanel(guildId: string) {
  const guild = getGuildConfig(guildId);
  if (!guild.roleDirectoryChannelId || !guild.roleDirectoryMessageId) return false;
  const payload = componentsV2Payload("", normalizeMessageOptions(await roleDirectoryPayload(guildId, guild)));
  const response = await discordRequest(
    `/channels/${guild.roleDirectoryChannelId}/messages/${guild.roleDirectoryMessageId}`,
    {
      method: "PATCH",
      body: JSON.stringify(payload),
    },
  );
  if (response) return true;
  const replacement = await sendMessage(guild.roleDirectoryChannelId, "", await roleDirectoryPayload(guildId, guild));
  const replacementId = String((replacement as { id?: string } | null)?.id ?? "");
  if (!replacementId) return false;
  guild.roleDirectoryMessageId = replacementId;
  await saveConfig();
  return true;
}

async function refreshRoleDirectoryPanels() {
  for (const guildId of Object.keys(config.guilds)) {
    try {
      await refreshRoleDirectoryPanel(guildId);
    } catch (error) {
      logger.warn({ error, guildId }, "Rollenlijst automatisch verversen mislukt");
    }
  }
}

type DiscordInvite = {
  code: string;
  uses?: number;
  inviter?: { id?: string; username?: string; global_name?: string };
};

async function syncGuildInvites(guildId: string) {
  const guild = getGuildConfig(guildId);
  const invites = await discordRequest<DiscordInvite[]>(`/guilds/${guildId}/invites`);
  if (!invites) return false;
  const firstSync = !guild.inviteSyncInitialized;
  for (const invite of invites) {
    const uses = Math.max(0, invite.uses ?? 0);
    const inviterId = invite.inviter?.id;
    if (inviterId) {
      guild.inviteNames[inviterId] = invite.inviter?.global_name ?? invite.inviter?.username ?? inviterId;
      if (!firstSync) {
        const previousUses = guild.inviteUses[invite.code] ?? 0;
        const delta = Math.max(0, uses - previousUses);
        if (delta) guild.inviteCounts[inviterId] = (guild.inviteCounts[inviterId] ?? 0) + delta;
      }
    }
    guild.inviteUses[invite.code] = uses;
  }
  guild.inviteSyncInitialized = true;
  await saveConfig();
  return true;
}

async function recordInviteJoin(guildId: string, joinedUserId?: string) {
  const guild = getGuildConfig(guildId);
  const invites = await discordRequest<DiscordInvite[]>(`/guilds/${guildId}/invites`);
  if (!invites) return;
  const changed = invites
    .map((invite) => ({ invite, delta: Math.max(0, (invite.uses ?? 0) - (guild.inviteUses[invite.code] ?? 0)) }))
    .filter((entry) => entry.delta > 0 && entry.invite.inviter?.id)
    .sort((left, right) => right.delta - left.delta)[0];
  for (const invite of invites) {
    guild.inviteUses[invite.code] = Math.max(0, invite.uses ?? 0);
    if (invite.inviter?.id) {
      guild.inviteNames[invite.inviter.id] = invite.inviter.global_name ?? invite.inviter.username ?? invite.inviter.id;
    }
  }
  if (changed?.invite.inviter?.id) {
    const inviterId = changed.invite.inviter.id;
    guild.inviteCounts[inviterId] = (guild.inviteCounts[inviterId] ?? 0) + 1;
    const memberId = joinedUserId ?? (await discordRequest<Array<{ user?: { id?: string } }>>(`/guilds/${guildId}/members?limit=1000`))?.find((member) => member.user?.id)?.user?.id;
    if (memberId) {
      const known = guild.inviteMembers[inviterId] ?? [];
      if (!known.includes(memberId)) known.push(memberId);
      guild.inviteMembers[inviterId] = known;
      guild.inviteLeftUsers[inviterId] = (guild.inviteLeftUsers[inviterId] ?? []).filter((id) => id !== memberId);
    }
  }
  guild.inviteSyncInitialized = true;
  await saveConfig();
  await refreshInvitePanel(guildId);
}

function invitePanelEmbed(guild: GuildConfig) {
  const panel = guild.invitePanel;
  return {
    title: panel.title,
    description: panel.description,
    color: panel.color ?? GREY_EMBED_COLOR,
    ...(panel.bannerUrl || guild.ticketPanel.bannerUrl
      ? { image: { url: panel.bannerUrl || guild.ticketPanel.bannerUrl } }
      : {}),
    thumbnail: { url: panel.thumbnailUrl || guild.ticketPanel.thumbnailUrl || DEFAULT_PANEL_THUMBNAIL },
  };
}

function levelLeaderboardPayload(guild: GuildConfig) {
  const users = Object.entries(guild.levelUsers)
    .sort(([, left], [, right]) => right.xp - left.xp)
    .slice(0, 10);
  const lines = users.length
    ? users.map(([userId, profile], index) => `${index + 1}. <@${userId}> — **level ${levelForXp(profile.xp)}** • **${profile.xp} XP**`).join("\n")
    : "Er is nog geen XP verdiend.";
  return {
    embeds: [{
      title: "⭐ LEVEL LEADERBOARD",
      description: `${lines}\n\n**Volgende update:** <t:${Math.floor((Date.now() + 60_000) / 1000)}:R>`,
      color: 0x2dd4bf,
      thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
      footer: { text: "Automatisch bijgewerkt • elke minuut" },
    }],
    components: [],
  };
}

function inviteLeaderboardDescription(guild: GuildConfig) {
  const leaders = Object.entries(guild.inviteCounts)
    .filter(([, count]) => count > 0)
    .sort(([, left], [, right]) => right - left)
    .slice(0, 10);
  if (!leaders.length) return "Er zijn nog geen geregistreerde invites. Nodig iemand uit om de eerste plek te pakken!";
  return leaders
    .map(([userId, count], index) => `${index + 1}. <@${userId}> — **${count} ${count === 1 ? "invite" : "invites"}**`)
    .join("\n");
}

function invitePanelPayload(guild: GuildConfig, management = false) {
  const panel = guild.invitePanel;
  return {
    embeds: [{
      ...invitePanelEmbed(guild),
      description: `${panel.description}\n\n${inviteLeaderboardDescription(guild)}`,
      footer: { text: `Invite leaderboard • volgende update <t:${Math.floor((Date.now() + 5 * 60_000) / 1000)}:R>` },
    }],
    components: [{
      type: 1,
      components: [
        { type: 2, style: 1, label: panel.checkButtonLabel, custom_id: "invite:check" },
        { type: 2, style: 3, label: panel.createButtonLabel, custom_id: "invite:create" },
        ...(management ? [{ type: 2, style: 2, label: "Panel bewerken", custom_id: "invite:edit" }, { type: 2, style: 2, label: "Instellingen", custom_id: "invite:settings" }, { type: 2, style: 2, label: "Panel plaatsen", custom_id: "invite:post" }] : []),
      ],
    }],
  };
}

async function refreshInvitePanel(guildId: string) {
  const guild = getGuildConfig(guildId);
  if (!guild.invitePanelChannelId) return false;
  const payload = componentsV2Payload("", normalizeMessageOptions(invitePanelPayload(guild)));
  if (guild.invitePanelMessageId) {
    const response = await discordRequest(`/channels/${guild.invitePanelChannelId}/messages/${guild.invitePanelMessageId}`, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
    if (response) return true;
  }
  const replacement = await sendMessage(guild.invitePanelChannelId, "", invitePanelPayload(guild));
  const replacementId = String((replacement as { id?: string } | null)?.id ?? "");
  if (!replacementId) return false;
  guild.invitePanelMessageId = replacementId;
  await saveConfig();
  return true;
}

async function updateInvitePanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen het invitepanel beheren.");
    return;
  }
  const values = modalValues(interaction);
  const guild = getGuildConfig(guildId);
  if (values.invite_title) guild.invitePanel.title = values.invite_title.slice(0, 256);
  if (values.invite_description) guild.invitePanel.description = values.invite_description.slice(0, 4000);
  if (values.invite_banner !== undefined) guild.invitePanel.bannerUrl = values.invite_banner.trim().slice(0, 1000);
  if (values.invite_thumbnail !== undefined) guild.invitePanel.thumbnailUrl = values.invite_thumbnail.trim().slice(0, 1000);
  if (values.invite_channel) guild.inviteChannelId = channelIdFromArg(values.invite_channel.trim());
  if (values.invite_color) {
    const color = colorValue(values.invite_color.trim());
    if (color !== undefined) guild.invitePanel.color = color;
  }
  if (values.invite_labels) {
    const [checkLabel, createLabel] = values.invite_labels.split("|").map((value) => value.trim());
    if (checkLabel) guild.invitePanel.checkButtonLabel = checkLabel.slice(0, 80);
    if (createLabel) guild.invitePanel.createButtonLabel = createLabel.slice(0, 80);
  }
  await saveConfig();
  await refreshInvitePanel(guildId);
  await sendInteractionResponse(interaction, "Invitepanel opgeslagen.");
}

async function postInvitePanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !interaction.channel_id || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit invitepanel plaatsen.");
    return;
  }
  const guild = getGuildConfig(guildId);
  guild.invitePanelChannelId = interaction.channel_id;
  guild.inviteChannelId ??= interaction.channel_id;
  await syncGuildInvites(guildId);
  const created = await sendMessage(interaction.channel_id, "", invitePanelPayload(guild));
  guild.invitePanelMessageId = String((created as { id?: string } | null)?.id ?? "");
  await saveConfig();
  await sendInteractionResponse(interaction, "Invitepanel geplaatst en geconfigureerd.");
}

async function createInvite(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const userId = interactionUserId(interaction);
  const guild = guildId ? getGuildConfig(guildId) : undefined;
  const channelId = guild ? guild.inviteChannelId || interaction.channel_id : interaction.channel_id;
  if (!guildId || !userId || !guild || !channelId) {
    await sendInteractionResponse(interaction, "Er is nog geen invitekanaal ingesteld.");
    return;
  }
  const invites = await discordRequest<DiscordInvite[]>(`/guilds/${guildId}/invites`);
  const existingCode = guild.inviteCodes[userId] ?? invites?.find((invite) => invite.inviter?.id === userId)?.code;
  if (existingCode && invites?.some((invite) => invite.code === existingCode)) {
    guild.inviteCodes[userId] = existingCode;
    await saveConfig();
    await sendInteractionResponse(interaction, `Jouw persoonlijke invite-link:\nhttps://discord.gg/${existingCode}`);
    return;
  }
  const invite = await discordRequest<{ code?: string }>(`/channels/${channelId}/invites`, {
    method: "POST",
    body: JSON.stringify({ max_age: 0, max_uses: 0, unique: true }),
  });
  if (!invite?.code) {
    await sendInteractionResponse(interaction, "Ik kan geen invite-link maken. Controleer mijn Create Instant Invite-permissie.");
    return;
  }
  guild.inviteCodes[userId] = invite.code;
  await saveConfig();
  await sendInteractionResponse(interaction, `Jouw invite-link:\nhttps://discord.gg/${invite.code}`);
}

async function analyzeInvitesForUser(guildId: string, inviterId: string) {
  const guild = getGuildConfig(guildId);
  const members = await discordRequest<Array<{ user?: { id?: string } }>>(`/guilds/${guildId}/members?limit=1000`) ?? [];
  const memberIds = new Set(members.map((member) => member.user?.id).filter(Boolean) as string[]);
  const invited = guild.inviteMembers[inviterId] ?? [];
  const left = guild.inviteLeftUsers[inviterId] ?? [];
  const active = invited.filter((userId) => memberIds.has(userId));
  const leftIds = invited.filter((userId) => left.includes(userId) || (!memberIds.has(userId) && userId !== ""));
  const fake = invited.filter((userId) => !memberIds.has(userId) && !left.includes(userId));
  return { invited, active, left: leftIds.filter((userId) => !active.includes(userId)), fake: fake.filter((userId) => !left.includes(userId)) };
}

async function handleInviteLookup(message: DiscordMessage, args: string[]) {
  const guildId = message.guild_id;
  if (!guildId) return;
  const raw = args.join(" ").trim();
  const targetId = raw
    ? (mentionId(raw) ?? (/^\d+$/.test(raw) ? raw : await resolveTargetUserId(guildId, raw)))
    : (message.author?.id ?? undefined);
  if (!targetId) {
    await reply(message, "Gebruik `~invites @Gebruiker` of `~invites Gebruikersnaam`.");
    return;
  }
  const guild = getGuildConfig(guildId);
  const summary = await analyzeInvitesForUser(guildId, targetId);
  const member = await discordRequest<{ user?: { username?: string; global_name?: string } }>(`/guilds/${guildId}/members/${targetId}`);
  const name = member?.user?.global_name ?? member?.user?.username ?? guild.inviteNames[targetId] ?? targetId;
  const list = summary.invited.length
    ? (await Promise.all(summary.invited.map(async (userId) => {
        const user = await discordRequest<{ username?: string; global_name?: string }>(`/users/${userId}`);
        const isActive = summary.active.includes(userId);
        const isLeft = summary.left.includes(userId);
        const isFake = summary.fake.includes(userId);
        const label = isActive ? "actief" : isLeft ? "geleaved" : isFake ? "fake" : "onbekend";
        const userName = user?.global_name ?? user?.username ?? userId;
        return `${userName} (${label})`;
      }))).join("\n")
    : "Geen bekende invites geregistreerd.";
  await reply(message, `**${name}** • Geinvite: **${summary.invited.length}** • Actief: **${summary.active.length}** • Geleaved: **${summary.left.length}** • Fake: **${summary.fake.length}**\n\nLijst:\n${list}`);
}

async function checkInvites(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const userId = interactionUserId(interaction);
  if (!guildId || !userId) return;
  const guild = getGuildConfig(guildId);
  const count = guild.inviteCounts[userId] ?? 0;
  const leaders = Object.entries(guild.inviteCounts).sort(([, left], [, right]) => right - left);
  const rank = count ? leaders.findIndex(([id]) => id === userId) + 1 : 0;
  await sendInteractionResponse(interaction, `Je hebt momenteel **${count} ${count === 1 ? "invite" : "invites"}**.\n${rank ? `Je staat op plek **#${rank}** van de leaderboard.` : "Nodig iemand uit om op de leaderboard te komen."}`);
}

async function panelForNav(guildId: string, guild: GuildConfig, nav: string, page = 0): Promise<JsonRecord | undefined> {
  switch (nav) {
    case "roles":
      return roleDirectoryPayload(guildId, guild, page, true);
    case "invites":
      return invitePanelPayload(guild, true);
    case "ticket":
      return panelPayload(guild.ticketPanel, "ticket");
    case "application":
    case "sollicitatie":
      return panelPayload(guild.applicationPanel, "application");
    case "clock":
      return clockPanelPayload(guild);
    case "moderation":
    case "moderatie":
      return moderationPanelPayload(guild);
    case "giveaway":
      return giveawayPanelPayload(guild);
    case "counting":
    case "tellen":
      return countingPanelPayload(guild);
    case "guess":
    case "raad":
    case "raadhetgetal":
      return guessPanelPayload(guild);
    case "levels":
    case "level":
      return levelSettingsPayload(guild);
    case "welcome":
      return welcomePanelPayload(guild);
    case "games":
      return gamesPanelPayload();
    case "help":
    case "hulp":
      return helpPayload();
    case "ai":
      return aiSettingsPanelPayload(guild);
    default:
      return undefined;
  }
}

function aiSettingsPanelPayload(guild: GuildConfig) {
  return {
    embeds: [panelEmbed({
      title: "AI-chat instellingen",
      description: guild.aiChatChannelId
        ? `AI-chat staat aan in <#${guild.aiChatChannelId}>. Pas hier de geavanceerde werking aan.`
        : "Stel eerst een AI-kanaal in met ~aichat #kanaal.",
      color: GREY_EMBED_COLOR,
      buttonLabel: "",
    }, "AI • Privé instellingen")],
    components: [{
      type: 1,
      components: [
        { type: 2, style: 2, label: "Instellingen bewerken", custom_id: "ai:settings" },
        { type: 2, style: 2, label: "Context wissen", custom_id: "ai:context:clear" },
        { type: 2, style: 2, label: "AI-paneel sluiten", custom_id: "nav:help" },
      ],
    }],
  };
}

function welcomePanelPayload(guild: GuildConfig) {
  return {
    embeds: [
      {
        title: "Welkomsysteem beheren",
        description: [
          guild.welcomeTitle || "Welkom bij {server}!",
          guild.welcomeDescription || guild.welcomeMessage || "Welkom bij de server!",
          "",
          "Beschikbaar: `{user}`, `{username}`, `{globalname}`, `{server}`, `{count}`, `{id}`, `{created}`, `{joined}` en `{relative}`.",
        ].join("\n"),
        color: guild.welcomeColor ?? GREY_EMBED_COLOR,
        ...(guild.welcomeBannerUrl ? { image: { url: guild.welcomeBannerUrl } } : {}),
        thumbnail: { url: guild.welcomeThumbnailUrl || DEFAULT_PANEL_THUMBNAIL },
        footer: { text: "Test eerst met de testknop voordat je live gaat." },
      },
    ],
    components: [
      {
        type: 1,
        components: [
          { type: 2, style: 1, label: "Bericht bewerken", custom_id: "welcome:edit" },
          { type: 2, style: 2, label: "Media & kleur", custom_id: "welcome:settings" },
          { type: 2, style: 3, label: "Testbericht sturen", custom_id: "welcome:test" },
          { type: 2, style: 3, label: "Panel plaatsen", custom_id: "welcome:post" },
        ],
      },
    ],
  };
}

type WelcomeUser = {
  id: string;
  username?: string;
  global_name?: string;
};

function welcomeReplace(value: string, user: WelcomeUser, guildData: { name?: string; member_count?: number; approximate_member_count?: number }, joinedAt = Date.now()) {
  const joinedTimestamp = Math.floor(joinedAt / 1000);
  const memberCount = guildData.member_count ?? guildData.approximate_member_count ?? 0;
  return value
    .replaceAll("{user}", `<@${user.id}>`)
    .replaceAll("{username}", user.username ?? user.id)
    .replaceAll("{globalname}", user.global_name ?? user.username ?? user.id)
    .replaceAll("{server}", guildData.name ?? "de server")
    .replaceAll("{count}", String(memberCount))
    .replaceAll("{id}", user.id)
    .replaceAll("{created}", `<t:${joinedTimestamp}:D>`)
    .replaceAll("{joined}", `<t:${joinedTimestamp}:F>`)
    .replaceAll("{relative}", `<t:${joinedTimestamp}:R>`);
}

function welcomeButtonStyle(color: number): 1 | 2 | 3 | 4 {
  const red = (color >> 16) & 255;
  const green = (color >> 8) & 255;
  const blue = color & 255;
  const maxChannel = Math.max(red, green, blue);
  const minChannel = Math.min(red, green, blue);
  const saturation = maxChannel - minChannel;
  if (green >= red && green >= blue && saturation > 40) return 3;
  if (red >= green && red >= blue && saturation > 40) return 4;
  if (blue >= red && blue >= green && saturation > 40) return 1;
  return 2;
}

async function sendWelcomeMessage(guildId: string, user: WelcomeUser, fallbackChannelId?: string) {
  const guild = getGuildConfig(guildId);
  const channelId = guild.welcomeChannelId || fallbackChannelId;
  if (!channelId) return false;
  const guildData = await discordRequest<{ name?: string; member_count?: number; approximate_member_count?: number }>(`/guilds/${guildId}?with_counts=true`) ?? {};
  const joinedAt = Date.now();
  const embed = {
    title: welcomeReplace(guild.welcomeTitle, user, guildData, joinedAt),
    ...(guild.welcomeDescription ? { description: welcomeReplace(guild.welcomeDescription, user, guildData, joinedAt) } : {}),
    color: guild.welcomeColor ?? 0x2dd4bf,
    ...(guild.welcomeBannerUrl ? { image: { url: guild.welcomeBannerUrl } } : {}),
    thumbnail: { url: guild.welcomeThumbnailUrl || DEFAULT_PANEL_THUMBNAIL },
    fields: [
      { name: "Nieuw lid", value: `<@${user.id}>`, inline: true },
      { name: "Leden", value: String(guildData.member_count ?? guildData.approximate_member_count ?? 0), inline: true },
    ],
    footer: { text: `${guildData.name ?? "Server"} • welkom • <t:${Math.floor(joinedAt / 1000)}:F> • <t:${Math.floor(joinedAt / 1000)}:R>` },
  };
  const helloButtonStyle = welcomeButtonStyle(guild.welcomeColor ?? 0x2dd4bf);
  const sent = await sendMessage(channelId, "", {
    embeds: [embed],
    mediaAfterText: true,
    components: [{
      type: 1,
      components: [{
        type: 2,
        style: helloButtonStyle,
        label: "Zeg hallo",
        custom_id: `welcome:say-hello:${user.id}`,
      }],
    }],
    allowed_mentions: { users: [user.id] },
  });
  return Boolean(sent);
}

function gamesPanelPayload() {
  return {
    embeds: [
      {
        title: "Games",
        description: "Gebruik de knoppen of commands voor korte games en beheer de actieve spelkanalen via de panelen.",
        color: GREY_EMBED_COLOR,
        thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
      },
    ],
    components: [
      {
        type: 1,
        components: [
          { type: 2, style: 1, label: "Munt gooien", custom_id: "game:coin" },
          { type: 2, style: 1, label: "Dobbelsteen", custom_id: "game:dice" },
          { type: 2, style: 3, label: "Tellen beheren", custom_id: "nav:counting" },
          { type: 2, style: 3, label: "Raad getal beheren", custom_id: "nav:guess" },
        ],
      },
    ],
  };
}

function countingPanelPayload(guild: GuildConfig) {
  const panel = guild.countingPanel;
  return {
    embeds: [panelEmbed(panel, "Tellen • Beheer en spelregels")],
    components: [
      {
        type: 1,
        components: [
          { type: 2, style: 1, label: "Panel bewerken", custom_id: "counting:edit:visual" },
          { type: 2, style: 1, label: "Teksten", custom_id: "counting:edit:text" },
          { type: 2, style: 1, label: "Emoji", custom_id: "counting:edit:emoji" },
          { type: 2, style: 3, label: "Panel plaatsen", custom_id: "counting:post" },
          { type: 2, style: 4, label: "Reset", custom_id: "counting:reset" },
        ],
      },
    ],
  };
}

function guessPanelPayload(guild: GuildConfig) {
  const panel = guild.guessPanel;
  return {
    embeds: [panelEmbed(panel, "Raad het getal • Beheer en spelregels")],
    components: [
      {
        type: 1,
        components: [
          { type: 2, style: 3, label: panel.startButtonLabel, custom_id: "guess:start" },
          { type: 2, style: 1, label: "Panel bewerken", custom_id: "guess:edit:visual" },
          { type: 2, style: 1, label: "Teksten", custom_id: "guess:edit:text" },
          { type: 2, style: 3, label: "Panel plaatsen", custom_id: "guess:post" },
          { type: 2, style: 4, label: "Stop ronde", custom_id: "guess:stop" },
        ],
      },
    ],
  };
}

async function sendInteractionResponse(
  interaction: DiscordInteraction,
  content: string,
  ephemeral = true,
  extra: JsonRecord = {},
) {
  const normalizedExtra = normalizeMessageOptions(extra);
  const responseData = normalizedExtra.embeds && normalizedExtra.components
    ? componentsV2Payload(content, normalizedExtra)
    : { content, flags: ephemeral ? 64 : 0, ...normalizedExtra };
  const response = await fetch(
    `${DISCORD_API}/interactions/${interaction.id}/${interaction.token}/callback`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type: 4,
        data: { ...responseData, flags: Number(responseData.flags ?? 0) | (ephemeral ? 64 : 0) },
      }),
    },
  );
  if (!response.ok) {
    logger.warn({ status: response.status, response: (await response.text()).slice(0, 500) }, "Discord interaction response failed");
  }
}

async function showModal(
  interaction: DiscordInteraction,
  customId: string,
  title: string,
  fields: Array<{
    id: string;
    label: string;
    placeholder?: string;
    value?: string;
    paragraph?: boolean;
    required?: boolean;
  }>,
) {
  await fetch(
    `${DISCORD_API}/interactions/${interaction.id}/${interaction.token}/callback`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type: 9,
        data: {
          custom_id: customId,
          title: title.slice(0, 45),
          components: fields.slice(0, 5).map((field) => ({
            type: 1,
            components: [
              {
                type: 4,
                custom_id: field.id,
                label: field.label.slice(0, 45),
                style: field.paragraph ? 2 : 1,
                placeholder: field.placeholder?.slice(0, 100),
                value: field.value?.slice(0, 4000),
                required: field.required ?? true,
                max_length: field.paragraph ? 2000 : 500,
              },
            ],
          })),
        },
      }),
    },
  );
}

function modalValues(interaction: DiscordInteraction) {
  const values: Record<string, string> = {};
  for (const row of interaction.data?.components ?? []) {
    for (const component of row.components ?? []) {
      if (component.custom_id) values[component.custom_id] = component.value ?? "";
    }
  }
  return values;
}

function helpPayload() {
  return {
    embeds: [
      {
        title: "Community Bot • Bedieningscentrum",
        description:
          "Open hieronder een privé-infopaneel. Beheerders gebruiken de setupknoppen; leden zien alleen wat voor hen beschikbaar is.",
        color: GREY_EMBED_COLOR,
        thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
      },
    ],
    components: [
      {
        type: 1,
        components: [
          { type: 2, style: 1, label: "Tickets", custom_id: "help:ticket" },
          { type: 2, style: 3, label: "Sollicitatie", custom_id: "help:application" },
          { type: 2, style: 1, label: "Klok", custom_id: "help:clock" },
          { type: 2, style: 4, label: "Moderatie", custom_id: "help:moderation" },
          { type: 2, style: 2, label: "Giveaways", custom_id: "help:giveaway" },
        ],
      },
      {
        type: 1,
        components: [
          { type: 2, style: 2, label: "Games", custom_id: "help:games" },
          { type: 2, style: 2, label: "Rollenlijst", custom_id: "help:roles" },
          { type: 2, style: 2, label: "Invites", custom_id: "help:invites" },
          { type: 2, style: 3, label: "Levels", custom_id: "help:levels" },
          { type: 2, style: 2, label: "Beheerformulieren", custom_id: "help:admin" },
        ],
      },
    ],
  };
}

function clockPanelPayload(guild: GuildConfig) {
  const panel = guild.clockPanel;
  return {
    embeds: [panelEmbed(panel, "Personeel • In- en uitklokken")],
    components: [
      {
        type: 1,
        components: [
          {
            type: 2,
            style: 3,
            label: panel.inButtonLabel,
            custom_id: "clock:in",
          },
          {
            type: 2,
            style: 4,
            label: panel.outButtonLabel,
            custom_id: "clock:out",
          },
        ],
      },
    ],
  };
}

function clockManagementPayload(guild: GuildConfig) {
  return {
    embeds: [
      panelEmbed(
        {
          ...guild.clockPanel,
          title: "Klokpanel beheren",
          description:
            "Gebruik privéformulieren om titel, tekst, banner, thumbnail en knoplabels te wijzigen.",
        },
        "Beheer • Klok",
      ),
    ],
    components: [
      {
        type: 1,
        components: [
          { type: 2, style: 1, label: "Panel bewerken", custom_id: "clock:edit" },
          { type: 2, style: 3, label: "Panel plaatsen", custom_id: "clock:post" },
          { type: 2, style: 2, label: "Instellingen", custom_id: "clock:settings" },
        ],
      },
    ],
  };
}

function moderationPanelPayload(guild: GuildConfig) {
  return {
    embeds: [panelEmbed(guild.moderationPanel, "Moderatie • Privéformulieren")],
    components: [
      {
        type: 1,
        components: [
          { type: 2, style: 4, label: "Waarschuwen", custom_id: "mod:warn" },
          { type: 2, style: 4, label: "Time-out", custom_id: "mod:timeout" },
          { type: 2, style: 2, label: "Berichten wissen", custom_id: "mod:clear" },
        ],
      },
      {
        type: 1,
        components: [
          { type: 2, style: 2, label: "Kanaal vergrendelen", custom_id: "mod:lock" },
          { type: 2, style: 3, label: "Kanaal ontgrendelen", custom_id: "mod:unlock" },
          { type: 2, style: 1, label: "Panel bewerken", custom_id: "mod:edit" },
        ],
      },
      {
        type: 1,
        components: [
          {
            type: 5,
            custom_id: "mod:whitelist:user",
            placeholder: "Whitelist gebruiker",
            min_values: 1,
            max_values: 1,
          },
          {
            type: 6,
            custom_id: "mod:whitelist:role",
            placeholder: "Whitelist rol",
            min_values: 1,
            max_values: 1,
          },
        ],
      },
    ],
  };
}

function giveawayPanelPayload(guild: GuildConfig) {
  const panel = guild.giveawayPanel;
  return {
    embeds: [panelEmbed(panel, "Giveaway • Beheer en deelname")],
    components: [
      {
        type: 1,
        components: [
          {
            type: 2,
            style: 3,
            label: panel.buttonLabel,
            custom_id: "giveaway:create",
          },
          {
            type: 2,
            style: 1,
            label: "Panel bewerken",
            custom_id: "giveaway:edit",
          },
          {
            type: 2,
            style: 4,
            label: "Giveaway stoppen",
            custom_id: "giveaway:stop",
          },
        ],
      },
    ],
  };
}

async function sendPanel(
  channelId: string,
  panel: PanelConfig,
  kind: "ticket" | "application",
  management = true,
) {
  return sendMessage(channelId, "", panelPayload(panel, kind, management));
}

async function refreshConfiguredPanel(guild: GuildConfig, kind: "ticket" | "application") {
  const channelId = kind === "ticket" ? guild.ticketPanelChannelId : guild.applicationPanelChannelId;
  const messageId = kind === "ticket" ? guild.ticketPanelMessageId : guild.applicationPanelMessageId;
  if (!channelId || !messageId) return;
  const options = normalizeMessageOptions(panelPayload(
    kind === "ticket" ? guild.ticketPanel : guild.applicationPanel,
    kind,
    false,
  ));
  await discordRequest(`/channels/${channelId}/messages/${messageId}`, {
    method: "PATCH",
    body: JSON.stringify(componentsV2Payload("", options)),
  });
}

async function hasPermission(
  message: DiscordMessage,
  permission: "admin" | "manage" | "ban" | "messages" | "channels",
) {
  const guildId = message.guild_id;
  const userId = message.author?.id;
  if (!guildId || !userId) return false;
  const [guild, roles] = await Promise.all([
    discordRequest<{ owner_id?: string }>(`/guilds/${guildId}`),
    discordRequest<Array<{ id: string; permissions: string }>>(
      `/guilds/${guildId}/roles`,
    ),
  ]);
  if (guild?.owner_id === userId) return true;
  const memberRoles = new Set(message.member?.roles ?? []);
  const required = permission === "admin" ? 8n : permission === "manage" ? 32n : permission === "ban" ? 4n : permission === "messages" ? 8192n : 16n;
  return Boolean(
    roles?.some((role) => {
      if (!memberRoles.has(role.id)) return false;
      const permissions = BigInt(role.permissions);
      return (permissions & 8n) === 8n || (permissions & required) === required;
    }),
  );
}

function mentionId(value: string): string | undefined {
  return value.match(/^<@!?(\d+)>$/)?.[1];
}

async function resolveTargetUserId(guildId: string, value: string): Promise<string | undefined> {
  const explicitId = mentionId(value) ?? (/^\d+$/.test(value) ? value : undefined);
  if (explicitId) return explicitId;
  const normalized = value.trim().toLowerCase();
  if (!normalized) return undefined;
  const members = await discordRequest<Array<{ user?: { id?: string; username?: string; global_name?: string }; nick?: string }>>(
    `/guilds/${guildId}/members?limit=1000`,
  );
  if (!members) return undefined;
  return members.find((member) => {
    const user = member.user;
    const userName = user?.username?.toLowerCase() ?? "";
    const globalName = user?.global_name?.toLowerCase() ?? "";
    const nickName = member.nick?.toLowerCase() ?? "";
    return [userName, globalName, nickName].some(
      (candidate) => candidate === normalized || candidate.startsWith(normalized),
    );
  })?.user?.id;
}

async function resolveBannedUserId(guildId: string, value: string): Promise<string | undefined> {
  const explicitId = mentionId(value) ?? (/^\d+$/.test(value.trim()) ? value.trim() : undefined);
  if (explicitId) return explicitId;
  const normalized = value.trim().toLowerCase();
  if (!normalized) return undefined;
  const bans = await discordRequest<Array<{ user?: { id?: string; username?: string; global_name?: string } }>>(
    `/guilds/${guildId}/bans?limit=1000`,
  );
  return bans?.find((entry) => {
    const user = entry.user;
    return [user?.username, user?.global_name].some((candidate) => {
      const normalizedCandidate = candidate?.toLowerCase() ?? "";
      return normalizedCandidate === normalized || normalizedCandidate.startsWith(normalized);
    });
  })?.user?.id;
}

function colorValue(value: string): number | undefined {
  const normalized = value.replace(/^#/, "");
  if (!/^[0-9a-f]{6}$/i.test(normalized)) return undefined;
  return Number.parseInt(normalized, 16);
}

function panelButtonOrder(value: string, allowed: string[]) {
  return value
    .split(",")
    .map((entry) => entry.trim().toLowerCase())
    .filter((entry, index, entries) => allowed.includes(entry) && entries.indexOf(entry) === index);
}

function parsePanelLayout(value: string, allowed: PanelLayoutRow[]) {
  const defaults = new Map(allowed.map((row) => [row.id, row]));
  return value
    .split(";")
    .map((entry) => entry.split("|").map((part) => part.trim()))
    .filter((parts) => parts.length >= 4 && defaults.has(parts[0]))
    .map(([id, title, description, buttonLabel]) => ({
      ...(defaults.get(id) as PanelLayoutRow),
      title: title.slice(0, 120),
      description: description.slice(0, 300),
      buttonLabel: buttonLabel.slice(0, 80),
    }));
}

function panelRowValue(row: PanelLayoutRow) {
  const emoji = row.emoji?.id
    ? `<${row.emoji.animated ? "a" : ""}:${row.emoji.name ?? "emoji"}:${row.emoji.id}>`
    : row.emoji?.name ?? "";
  return `${row.title} | ${row.description} | ${row.buttonLabel} | ${emoji} | ${row.categoryId ?? ""}`;
}

function parseButtonEmoji(value: string) {
  const custom = value.trim().match(/^<(a?):([^:>]+):(\d+)>$/);
  if (custom) return { name: custom[2], id: custom[3], animated: Boolean(custom[1]) };
  const unicode = value.trim();
  return unicode && /\p{Extended_Pictographic}/u.test(unicode)
    ? { name: unicode.slice(0, 32) }
    : undefined;
}

function channelNamePart(value: string, fallback: string) {
  const normalized = value
    .normalize("NFKD")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .toLowerCase()
    .slice(0, 32);
  return normalized || fallback;
}

function updatePanelRows(panel: PanelConfig, values: Record<string, string>, prefix: string, defaults: PanelLayoutRow[]) {
  const rows = panel.layoutRows ?? defaults;
  panel.layoutRows = rows.map((row) => {
    const value = values[`${prefix}_row_${row.id}`];
    if (!value?.trim()) return row;
    const [title, description, buttonLabel, emoji, categoryId] = value.split("|").map((part) => part.trim());
    return {
      ...row,
      title: (title || row.title).slice(0, 120),
      description: (description || row.description).slice(0, 300),
      buttonLabel: (buttonLabel || row.buttonLabel).slice(0, 80),
      emoji: emoji === undefined ? row.emoji : parseButtonEmoji(emoji),
      categoryId: categoryId === undefined ? row.categoryId : channelIdFromArg(categoryId),
    };
  });
}

function channelIdFromArg(value: string): string | undefined {
  return value.match(/^<#(\d+)>$/)?.[1] ?? (/^\d+$/.test(value) ? value : undefined);
}

function roleIdFromArg(value: string): string | undefined {
  return value.match(/^<@&(\d+)>$/)?.[1] ?? (/^\d+$/.test(value) ? value : undefined);
}

async function resolveRoleId(guildId: string, value: string) {
  const directId = roleIdFromArg(value);
  if (directId) return directId;
  const normalized = value.replace(/^@/, "").trim().toLowerCase();
  if (!normalized) return undefined;
  const roles = await discordRequest<Array<{ id: string; name: string }>>(`/guilds/${guildId}/roles`);
  return roles?.find((role) => role.name.toLowerCase() === normalized)?.id;
}

function whitelistEntryActive(entry: LinkWhitelistEntry | undefined) {
  return Boolean(entry && (entry.expiresAt === 0 || entry.expiresAt > Date.now()));
}

function linkWhitelistMatches(message: DiscordMessage, guild: GuildConfig) {
  const userId = message.author?.id;
  if (userId && whitelistEntryActive(guild.linkWhitelistUsers[userId])) return true;
  return (message.member?.roles ?? []).some((roleId) =>
    whitelistEntryActive(guild.linkWhitelistRoles[roleId]),
  );
}

function whitelistDuration(value: string, actorId: string) {
  const minutes = Number.parseInt(value.trim(), 10);
  if (!Number.isInteger(minutes) || minutes < 0) return undefined;
  if (actorId !== WHITELIST_OWNER_ID && (minutes === 0 || minutes > 60)) return undefined;
  return minutes;
}

async function saveWhitelistDuration(
  message: DiscordMessage,
  targetId: string,
  kind: "user" | "role",
  durationInput: string,
) {
  const actorId = message.author?.id ?? "";
  const minutes = whitelistDuration(durationInput, actorId);
  if (minutes === undefined || !message.guild_id) {
    await reply(message, actorId === WHITELIST_OWNER_ID
      ? "Gebruik een geheel aantal minuten (0 = eeuwig)."
      : "Gebruik 1 tot 60 minuten. Alleen de aangewezen eigenaar kan 0 (eeuwig) gebruiken.");
    return true;
  }
  const guild = getGuildConfig(message.guild_id);
  const entry = { expiresAt: minutes === 0 ? 0 : Date.now() + minutes * 60_000, addedBy: actorId };
  if (kind === "user") guild.linkWhitelistUsers[targetId] = entry;
  else guild.linkWhitelistRoles[targetId] = entry;
  await saveConfig();
  await reply(message, `${kind === "user" ? `<@${targetId}>` : `<@&${targetId}>`} is ${minutes === 0 ? "eeuwig" : `${minutes} minuten`} gewhitelist voor links.`);
  return true;
}

async function handleWhitelistDurationMessage(message: DiscordMessage) {
  const actorId = message.author?.id ?? "";
  if (!message.guild_id || message.content.startsWith(PREFIX)) return false;
  const session = whitelistSessions.get(actorId);
  if (!session || session.guildId !== message.guild_id) return false;
  whitelistSessions.delete(actorId);
  return saveWhitelistDuration(message, session.targetId, session.kind, message.content);
}

function splitCommand(content: string): { name: string; args: string[] } | null {
  const commandPrefix = content.startsWith(PREFIX)
    ? PREFIX
    : /^(?:!rank|!leaderboard)(?:\s|$)/i.test(content)
      ? "!"
      : undefined;
  if (!commandPrefix) return null;
  const tokens = content.slice(commandPrefix.length).trim().split(/\s+/);
  const name = tokens.shift()?.toLowerCase();
  return name ? { name, args: tokens } : null;
}

function levelForXp(xp: number) {
  return Math.floor(Math.sqrt(Math.max(0, xp) / 100));
}

function xpForLevel(level: number) {
  return level * level * 100;
}

function getLevelProfile(guild: GuildConfig, userId: string): LevelProfile {
  guild.levelUsers[userId] ??= {
    xp: 0,
    messages: 0,
    lastXpAt: 0,
    lastMessageAt: 0,
  };
  return guild.levelUsers[userId];
}

async function applyLevelRoleRewards(guildId: string, userId: string, level: number) {
  const guild = getGuildConfig(guildId);
  if (!guild.levelRoles.length) return;
  const roleIds = guild.levelRoles
    .filter((assignment) => level >= assignment.level)
    .map((assignment) => assignment.roleId)
    .filter(Boolean);
  if (!roleIds.length) return;
  const member = await discordRequest<{ roles?: string[] }>(`/guilds/${guildId}/members/${userId}`);
  const currentRoles = new Set(member?.roles ?? []);
  for (const assignment of guild.levelRoles) {
    const hasRole = currentRoles.has(assignment.roleId);
    if (level >= assignment.level && !hasRole) {
      await discordRequest(`/guilds/${guildId}/members/${userId}/roles/${assignment.roleId}`, { method: "PUT" });
    }
    if (level < assignment.level && hasRole) {
      await discordRequest(`/guilds/${guildId}/members/${userId}/roles/${assignment.roleId}`, { method: "DELETE" });
    }
  }
}

async function awardMessageXp(message: DiscordMessage) {
  const guildId = message.guild_id;
  const userId = message.author?.id;
  if (!guildId || !userId || message.author?.bot) return;
  const guild = getGuildConfig(guildId);
  if (!guild.leveling.enabled || splitCommand(message.content)) return;
  const profile = getLevelProfile(guild, userId);
  const now = Date.now();
  const signature = message.content.trim().toLowerCase().slice(0, 200);
  if (!signature || profile.lastMessageSignature === signature && now - profile.lastMessageAt < 10 * 60_000) return;
  if (now - profile.lastXpAt < guild.leveling.cooldownSeconds * 1000) {
    profile.lastMessageAt = now;
    profile.lastMessageSignature = signature;
    return;
  }
  const previousLevel = levelForXp(profile.xp);
  const xp = Math.floor(Math.random() * (guild.leveling.maximumXp - guild.leveling.minimumXp + 1)) + guild.leveling.minimumXp;
  profile.xp += Math.max(1, xp);
  profile.messages += 1;
  profile.lastXpAt = now;
  profile.lastMessageAt = now;
  profile.lastMessageSignature = signature;
  await saveConfig();
  const currentLevel = levelForXp(profile.xp);
  if (currentLevel > previousLevel) {
    await applyLevelRoleRewards(guildId, userId, currentLevel);
    if (guild.leveling.announceLevelUps) {
      await sendLevelUpAnnouncement(guild, message, profile, currentLevel);
      void writeAuditLog(guildId, "level", "Level omhoog", `<@${userId}> bereikte level **${currentLevel}** met **${profile.xp} XP**.`, 0x2dd4bf, { id: userId, name: userId });
    }
  }
}

async function discordUser(userId: string, fallback?: DiscordMessage["author"]) {
  return (await discordRequest<{ id?: string; username?: string; global_name?: string; avatar?: string | null }>(`/users/${userId}`)) ?? {
    id: userId,
    username: fallback?.username ?? userId,
    global_name: fallback?.global_name,
    avatar: fallback?.avatar,
  };
}

function avatarUrl(userId: string, avatar?: string | null) {
  return avatar
    ? `https://cdn.discordapp.com/avatars/${userId}/${avatar}.png?size=256`
    : `https://cdn.discordapp.com/embed/avatars/${Number(BigInt(userId) % 5n)}.png`;
}

async function rankCardBuffer(guild: GuildConfig, userName: string, avatar: string, profile: LevelProfile, rank: number) {
  const canvas = createCanvas(1200, 520);
  const context = canvas.getContext("2d");
  const background = context.createLinearGradient(0, 0, 1200, 520);
  background.addColorStop(0, "#111827");
  background.addColorStop(1, "#0f766e");
  context.fillStyle = background;
  context.fillRect(0, 0, 1200, 520);
  if (guild.ticketPanel.bannerUrl) {
    try {
      const banner = await loadImage(guild.ticketPanel.bannerUrl);
      const scale = Math.max(1200 / banner.width, 520 / banner.height);
      const width = banner.width * scale;
      const height = banner.height * scale;
      context.globalAlpha = 0.5;
      context.drawImage(banner, (1200 - width) / 2, (520 - height) / 2, width, height);
      context.globalAlpha = 1;
    } catch {
      // Keep the fallback background when the configured banner cannot be loaded.
    }
  }
  context.fillStyle = "rgba(2, 6, 23, 0.72)";
  context.fillRect(0, 0, 1200, 520);
  context.fillStyle = "#99f6e4";
  context.font = "bold 24px sans-serif";
  context.fillText("RP NEDERLAND  •  LEVELS", 72, 58);
  try {
    const image = await loadImage(avatar);
    context.save();
    context.beginPath();
    context.arc(150, 260, 112, 0, Math.PI * 2);
    context.clip();
    context.drawImage(image, 38, 148, 224, 224);
    context.restore();
  } catch {
    context.fillStyle = "#2dd4bf";
    context.beginPath();
    context.arc(150, 260, 112, 0, Math.PI * 2);
    context.fill();
  }
  const level = levelForXp(profile.xp);
  const currentLevelXp = xpForLevel(level);
  const nextLevelXp = xpForLevel(level + 1);
  const progress = Math.min(1, (profile.xp - currentLevelXp) / Math.max(1, nextLevelXp - currentLevelXp));
  context.fillStyle = "#f8fafc";
  context.font = "bold 48px sans-serif";
  context.fillText(userName.slice(0, 28), 320, 150);
  context.font = "26px sans-serif";
  context.fillStyle = "#cbd5e1";
  context.fillText(`Serverrang #${rank}`, 320, 195);
  context.fillStyle = "#2dd4bf";
  context.font = "bold 42px sans-serif";
  context.fillText(`LEVEL ${level}`, 320, 270);
  context.fillStyle = "rgba(255, 255, 255, 0.2)";
  context.beginPath();
  context.roundRect(320, 325, 800, 30, 15);
  context.fill();
  context.fillStyle = "#2dd4bf";
  context.beginPath();
  context.roundRect(320, 325, Math.max(30, 800 * progress), 30, 15);
  context.fill();
  context.fillStyle = "#f8fafc";
  context.font = "bold 22px sans-serif";
  context.fillText(`${profile.xp - currentLevelXp} / ${nextLevelXp - currentLevelXp} XP naar level ${level + 1}`, 320, 395);
  context.fillStyle = "#cbd5e1";
  context.font = "23px sans-serif";
  context.fillText(`${profile.xp} totale XP  •  ${profile.messages} berichten`, 320, 440);
  return canvas.toBuffer("image/png");
}

async function sendRankCard(message: DiscordMessage, targetId: string) {
  const guildId = message.guild_id;
  if (!guildId) return;
  const guild = getGuildConfig(guildId);
  const profile = getLevelProfile(guild, targetId);
  const users = Object.entries(guild.levelUsers).sort(([, left], [, right]) => right.xp - left.xp);
  const rank = Math.max(1, users.findIndex(([userId]) => userId === targetId) + 1);
  const user = await discordUser(targetId, targetId === message.author?.id ? message.author : undefined);
  const userName = user.global_name ?? user.username ?? targetId;
  const buffer = await rankCardBuffer(guild, userName, avatarUrl(targetId, user.avatar), profile, rank);
  const level = levelForXp(profile.xp);
  const currentLevelXp = xpForLevel(level);
  const xpToNext = Math.max(1, xpForLevel(level + 1) - currentLevelXp);
  const earnedThisLevel = Math.max(0, profile.xp - currentLevelXp);
  const form = new FormData();
  const payload = componentsV2Payload("", {
    accent_color: 0x8b5cf6,
    components: [],
    embeds: [{
      title: `🏆 ${userName}`,
      description: `**Level ${level}** • **${profile.xp} XP**\n${rank === 1 ? "🔥 Nummer één op deze server" : `Serverpositie: **#${rank}**`}`,
      color: 0x8b5cf6,
      thumbnail: { url: avatarUrl(targetId, user.avatar) },
      image: { url: "attachment://rank-card.png" },
      fields: [
        { name: "Serverrang", value: `#${rank}`, inline: true },
        { name: "Vooruitgang", value: `${earnedThisLevel} / ${xpToNext} XP`, inline: true },
        { name: "Berichten", value: `${profile.messages}`, inline: true },
      ],
      footer: { text: rank === 1 ? "Top performer • continues streak" : `Nog ${Math.max(0, xpForLevel(level + 1) - profile.xp)} XP tot level ${level + 1}` },
    }],
  });
  form.append("payload_json", JSON.stringify(payload));
  form.append("files[0]", new Blob([buffer as unknown as ArrayBuffer], { type: "image/png" }), "rank-card.png");
  const response = await fetch(`${DISCORD_API}/channels/${message.channel_id}/messages`, {
    method: "POST",
    headers: { Authorization: `Bot ${token()}`, "User-Agent": "ReplitCommunityBot/1.0" },
    body: form,
  });
  if (!response.ok) logger.warn({ status: response.status, response: (await response.text()).slice(0, 300) }, "Rankkaart versturen mislukt");
}

async function levelUpCardBuffer(
  guild: GuildConfig,
  userName: string,
  avatar: string,
  profile: LevelProfile,
  rank: number,
  level: number,
) {
  const canvas = createCanvas(1200, 520);
  const context = canvas.getContext("2d");
  const background = context.createLinearGradient(0, 0, 1200, 520);
  background.addColorStop(0, "#0f172a");
  background.addColorStop(0.35, "#1d4ed8");
  background.addColorStop(1, "#0f766e");
  context.fillStyle = background;
  context.fillRect(0, 0, 1200, 520);
  if (guild.ticketPanel.bannerUrl) {
    try {
      const banner = await loadImage(guild.ticketPanel.bannerUrl);
      const scale = Math.max(1200 / banner.width, 520 / banner.height);
      const width = banner.width * scale;
      const height = banner.height * scale;
      context.globalAlpha = 0.28;
      context.drawImage(banner, (1200 - width) / 2, (520 - height) / 2, width, height);
      context.globalAlpha = 1;
    } catch {
      // Keep the fallback background when the configured banner cannot be loaded.
    }
  }
  context.fillStyle = "rgba(15, 23, 42, 0.72)";
  context.fillRect(0, 0, 1200, 520);
  context.strokeStyle = "rgba(148, 163, 184, 0.25)";
  context.lineWidth = 2;
  context.strokeRect(28, 28, 1144, 464);
  context.fillStyle = "#7dd3fc";
  context.font = "bold 28px sans-serif";
  context.fillText("LEVEL UP", 70, 80);
  context.fillStyle = "#f8fafc";
  context.font = "bold 72px sans-serif";
  context.fillText(`LEVEL ${level}`, 70, 162);
  context.font = "bold 40px sans-serif";
  context.fillText(userName.slice(0, 26), 70, 222);
  context.fillStyle = "#e2e8f0";
  context.font = "28px sans-serif";
  context.fillText(`Serverrang #${rank}  •  ${profile.xp} XP`, 70, 272);
  context.fillStyle = "rgba(255,255,255,0.13)";
  context.beginPath();
  context.roundRect(70, 330, 1060, 32, 16);
  context.fill();
  context.fillStyle = "#7dd3fc";
  context.beginPath();
  context.roundRect(70, 330, 1060, 32, 16);
  context.fill();
  context.fillStyle = "#f8fafc";
  context.font = "22px sans-serif";
  context.fillText("Blijf actief en pak het volgende level!", 70, 435);
  try {
    const image = await loadImage(avatar);
    context.save();
    context.beginPath();
    context.arc(965, 180, 116, 0, Math.PI * 2);
    context.clip();
    context.drawImage(image, 849, 64, 232, 232);
    context.restore();
    context.strokeStyle = "#dbeafe";
    context.lineWidth = 6;
    context.beginPath();
    context.arc(965, 180, 116, 0, Math.PI * 2);
    context.stroke();
  } catch {
    context.fillStyle = "#7dd3fc";
    context.beginPath();
    context.arc(965, 180, 116, 0, Math.PI * 2);
    context.fill();
  }
  return canvas.toBuffer("image/png");
}

async function sendLevelUpAnnouncement(guild: GuildConfig, message: DiscordMessage, profile: LevelProfile, level: number) {
  const userId = message.author?.id;
  if (!userId) return;
  const users = Object.entries(guild.levelUsers).sort(([, left], [, right]) => right.xp - left.xp);
  const rank = Math.max(1, users.findIndex(([id]) => id === userId) + 1);
  const user = await discordUser(userId, message.author);
  const userName = user.global_name ?? user.username ?? userId;
  const buffer = await levelUpCardBuffer(guild, userName, avatarUrl(userId, user.avatar), profile, rank, level);
  const announcement = guild.leveling.announceMessage
    .replaceAll("{user}", `<@${userId}>`)
    .replaceAll("{level}", String(level))
    .replaceAll("{xp}", String(profile.xp));
  const form = new FormData();
  const payload = componentsV2Payload(announcement, {
    accent_color: 0x22c55e,
    allowed_mentions: { users: [userId] },
    components: [],
    embeds: [{
      title: `✨ Level ${level} bereikt`,
      description: `**${userName}** is gestegen naar level **${level}** met **${profile.xp} XP**.\nServerrang: **#${rank}**`,
      color: 0x22c55e,
      thumbnail: { url: avatarUrl(userId, user.avatar) },
      image: { url: "attachment://level-up.png" },
      footer: { text: "Blijf actief om meer XP te verzamelen!" },
    }],
  });
  form.append("payload_json", JSON.stringify(payload));
  form.append("files[0]", new Blob([buffer as unknown as ArrayBuffer], { type: "image/png" }), "level-up.png");
  const response = await fetch(`${DISCORD_API}/channels/${guild.leveling.announceChannelId || message.channel_id}/messages`, {
    method: "POST",
    headers: { Authorization: `Bot ${token()}`, "User-Agent": "ReplitCommunityBot/1.0" },
    body: form,
  });
  if (!response.ok) logger.warn({ status: response.status }, "Level-upkaart versturen mislukt");
}

async function sendLeaderboard(message: DiscordMessage) {
  if (!message.guild_id) return;
  const guild = getGuildConfig(message.guild_id);
  guild.levelLeaderboardChannelId = message.channel_id;
  const existing = guild.levelLeaderboardMessageId
    ? await discordRequest(`/channels/${message.channel_id}/messages/${guild.levelLeaderboardMessageId}`, {
        method: "PATCH",
        body: JSON.stringify(componentsV2Payload("", normalizeMessageOptions(levelLeaderboardPayload(guild)))),
      })
    : null;
  if (!existing) {
    const created = await sendMessage(message.channel_id, "", levelLeaderboardPayload(guild));
    guild.levelLeaderboardMessageId = String((created as { id?: string } | null)?.id ?? "");
  }
  await saveConfig();
}

async function refreshLevelLeaderboards() {
  for (const guild of Object.values(config.guilds)) {
    if (!guild.levelLeaderboardChannelId || !guild.levelLeaderboardMessageId) continue;
    const updated = await discordRequest(
      `/channels/${guild.levelLeaderboardChannelId}/messages/${guild.levelLeaderboardMessageId}`,
      { method: "PATCH", body: JSON.stringify(componentsV2Payload("", normalizeMessageOptions(levelLeaderboardPayload(guild)))) },
    );
    if (!updated) {
      const created = await sendMessage(guild.levelLeaderboardChannelId, "", levelLeaderboardPayload(guild));
      guild.levelLeaderboardMessageId = String((created as { id?: string } | null)?.id ?? "");
      await saveConfig();
    }
  }
}

async function refreshAllPanelsOnStartup() {
  for (const [guildId, guild] of Object.entries(config.guilds)) {
    try {
      await refreshConfiguredPanel(guild, "ticket");
      await refreshConfiguredPanel(guild, "application");
      await refreshInvitePanel(guildId);
      await refreshRoleDirectoryPanel(guildId);
    } catch (error) {
      logger.warn({ error, guildId }, "Panel bijwerken na botstart mislukt");
    }
  }
  await refreshLevelLeaderboards();
}

async function handleLevelCommand(message: DiscordMessage, name: string, args: string[]) {
  if (name === "leaderboard") {
    await sendLeaderboard(message);
    return;
  }
  const targetId = mentionId(args[0] ?? "") ?? message.author?.id;
  if (!targetId) return;
  await sendRankCard(message, targetId);
}

async function createTicket(
  interaction: DiscordInteraction,
  type: string,
  categoryId?: string,
  details?: { subject: string; description: string },
) {
  const guildId = interaction.guild_id;
  const userId = interaction.member?.user?.id ?? interaction.user?.id;
  if (!guildId || !userId) return;
  const guild = getGuildConfig(guildId);
  const category = categoryId
    ? ticketCategoriesForGuild(guild).find((entry) => entry.id === categoryId)
    : undefined;
  if (!category) {
    await sendInteractionResponse(
      interaction,
      "Deze ticketcategorie bestaat niet meer. Vraag een beheerder om het ticketpanel te vernieuwen.",
    );
    return;
  }
  const existing = [...tickets.values()].find(
    (ticket) =>
      ticket.guildId === guildId &&
      ticket.userId === userId &&
      ticket.categoryId === category.id &&
      ticket.status !== "closed",
  );
  if (existing) {
    await sendInteractionResponse(
      interaction,
      `Je hebt in deze categorie al een open ticket: <#${existing.channelId}>`,
    );
    return;
  }
  const permissionOverwrites = [
    {
      id: guildId,
      type: 0,
      deny: "1024",
    },
    {
      id: userId,
      type: 1,
      allow: "68608",
    },
  ];
  if (category?.supportRoleId) {
    permissionOverwrites.push({ id: category.supportRoleId, type: 0, allow: "68608" });
  }
  const created = await discordRequest<{ id: string }>(
    "/guilds/" + guildId + "/channels",
    {
      method: "POST",
      body: JSON.stringify({
        name: [
          channelNamePart(guild.ticketChannelPrefix, "ticket"),
          channelNamePart(category.name, "ticket"),
          channelNamePart(interaction.member?.user?.username ?? userId.slice(-6), userId.slice(-6)),
        ].join("-").slice(0, 100),
        type: 0,
        parent_id: category.id,
        permission_overwrites: permissionOverwrites,
      }),
    },
  );
  if (!created?.id) {
    await sendInteractionResponse(interaction, "Het ticket kon niet worden aangemaakt.");
    return;
  }
  const ticket: TicketRecord = {
    channelId: created.id,
    guildId,
    userId,
    categoryId: category.id,
    type,
    subject: details?.subject ?? category.name,
    description: details?.description ?? "",
    status: "open",
    priority: "normal",
    createdAt: new Date().toISOString(),
  };
  tickets.set(created.id, ticket);
  const ticketPing = await sendMessage(
    created.id,
    ticketPingContent(ticket, category),
    {
      allowed_mentions: {
        users: [ticket.userId],
        ...(category.supportRoleId ? { roles: [category.supportRoleId] } : {}),
      },
    },
  );
  if (ticketPing) {
    const pingMessageId = String((ticketPing as { id?: string }).id ?? "");
    if (pingMessageId) {
      setTimeout(() => {
        void discordRequest(`/channels/${created.id}/messages/${pingMessageId}`, {
          method: "DELETE",
        });
      }, 1500);
    }
  }
  const ticketMessage = await sendMessage(
    created.id,
    ticketNotificationContent(ticket, category),
    ticketMessageOptions(ticket),
  );
  ticket.messageId = String((ticketMessage as { id?: string } | null)?.id ?? "");
  if (category.protected) {
    await sendRobloxUnbanProfile(created.id, ticket.subject);
  }
  await saveConfig();
  void writeAuditLog(guildId, "ticket", "Ticket aangemaakt", `Ticket **${ticket.subject}** geopend door <@${userId}> in <#${created.id}>.`, 0x2dd4bf, { id: userId, name: userId });
  await sendInteractionResponse(
    interaction,
    `Ticket aangemaakt: <#${created.id}>`,
  );
}

async function submitTicketForm(interaction: DiscordInteraction) {
  const customId = interaction.data?.custom_id ?? "";
  const values = modalValues(interaction);
  const subject = values.ticket_subject?.trim();
  const description = values.ticket_description?.trim();
  const categoryId = customId.slice("ticket:form:category:".length);
  const category = getGuildConfig(interactionGuildId(interaction) ?? "").ticketCategories.find(
    (entry) => entry.id === categoryId,
  );
  if (!category) {
    await sendInteractionResponse(interaction, "Deze ticketcategorie bestaat niet meer.");
    return;
  }
  if ((category.subjectEnabled !== false && !subject) || (category.descriptionEnabled !== false && !description)) {
    await sendInteractionResponse(interaction, "Vul de ingeschakelde ticketvragen in.");
    return;
  }
  await createTicket(interaction, category.type, categoryId, {
    subject: subject?.slice(0, 200) || category.name,
    description: description?.slice(0, 1800) || "Geen extra uitleg opgegeven.",
  });
}

function ticketLabel(value: TicketRecord["status"] | TicketRecord["priority"]): string {
  const labels: Record<string, string> = {
    open: "Open",
    claimed: "Geclaimd",
    waiting: "Wacht op antwoord",
    closed: "Gesloten",
    low: "Laag",
    normal: "Normaal",
    high: "Hoog",
  };
  return labels[value] ?? value;
}

function ticketPayload(ticket: TicketRecord) {
  const guild = getGuildConfig(ticket.guildId);
  return {
    embeds: [
      {
          title: `Ticket • ${ticket.type}`,
        description: [
          `**Onderwerp:** ${ticket.subject}`,
          `**Status:** ${ticketLabel(ticket.status)}`,
          `**Prioriteit:** ${ticketLabel(ticket.priority)}`,
          `\n**Melding:** ${ticket.description}`,
        ].join("\n"),
        color: GREY_EMBED_COLOR,
        thumbnail: { url: guild.ticketPanel.thumbnailUrl || DEFAULT_PANEL_THUMBNAIL },
        ...(guild.ticketPanel.bannerUrl ? { image: { url: guild.ticketPanel.bannerUrl } } : {}),
      },
    ],
    ...(guild.ticketPanel.bannerUrl ? { mediaAfterText: true } : {}),
    components: [
      {
        type: 1,
        components: [
          { type: 2, style: 3, label: ticket.claimedBy ? "Opnieuw claimen" : "Claimen", custom_id: "ticket:claim", disabled: ticket.status === "closed" },
          { type: 2, style: 1, label: "Wacht op antwoord", custom_id: "ticket:waiting", disabled: ticket.status === "closed" },
        ],
      },
      {
        type: 1,
        components: [
          { type: 2, style: 1, label: "Gebruiker toevoegen", custom_id: "ticket:add-user", disabled: ticket.status === "closed" },
          { type: 2, style: 4, label: "Ticket verwijderen", custom_id: "ticket:delete" },
          ticket.status === "closed"
            ? { type: 2, style: 3, label: "Ticket heropenen", custom_id: "ticket:reopen" }
            : { type: 2, style: 4, label: "Ticket sluiten", custom_id: "ticket:close" },
        ],
      },
    ],
  };
}

function ticketMessageOptions(ticket: TicketRecord) {
  return {
    ...ticketPayload(ticket),
    mediaAfterText: true,
  };
}

function ticketNotificationContent(ticket: TicketRecord, category = getGuildConfig(ticket.guildId).ticketCategories.find((entry) => entry.id === ticket.categoryId)) {
  return [
    `## ${category?.name ?? "Ticket"}`,
    "Leg je vraag of melding duidelijk uit. Een teamlid helpt je zo snel mogelijk.",
  ].filter(Boolean).join("\n");
}

function ticketPingContent(ticket: TicketRecord, category = getGuildConfig(ticket.guildId).ticketCategories.find((entry) => entry.id === ticket.categoryId)) {
  return [
    category?.supportRoleId ? `<@&${category.supportRoleId}>` : "",
    `<@${ticket.userId}>`,
  ].filter(Boolean).join(" ");
}

async function addTicketUser(interaction: DiscordInteraction) {
  const channelId = interaction.channel_id;
  const ticket = channelId ? tickets.get(channelId) : undefined;
  if (!ticket || !(await interactionCanManageTicket(interaction, ticket))) {
    await sendInteractionResponse(interaction, "Alleen de ticket-support kan gebruikers toevoegen.");
    return;
  }
  const value = modalValues(interaction).ticket_user?.trim() ?? "";
  const userId = await resolveTargetUserId(ticket.guildId, value);
  if (!userId) {
    await sendInteractionResponse(interaction, "Gebruiker niet gevonden. Gebruik een mention, gebruikers-ID of naam.");
    return;
  }
  if (userId === ticket.userId) {
    await sendInteractionResponse(interaction, "Deze gebruiker heeft al toegang tot het ticket.");
    return;
  }
  const permission = await discordRequest(`/channels/${ticket.channelId}/permissions/${userId}`, {
    method: "PUT",
    body: JSON.stringify({ type: 1, allow: "68608", deny: "0" }),
  });
  if (permission === null) {
    await sendInteractionResponse(interaction, "De gebruiker kon niet aan het ticket worden toegevoegd.");
    return;
  }
  await sendInteractionResponse(interaction, `<@${userId}> heeft toegang gekregen tot dit ticket.`);
}

async function updateTicket(
  interaction: DiscordInteraction,
  action: "claim" | "waiting" | "reopen",
) {
  const channelId = interaction.channel_id;
  const ticket = channelId ? tickets.get(channelId) : undefined;
  const actorId = interactionUserId(interaction);
  if (!ticket || !channelId || !actorId) {
    await sendInteractionResponse(interaction, "Dit is geen actief ticket.");
    return;
  }
  const isTicketOwner = actorId === ticket.userId;
  if (action === "waiting" && isTicketOwner) {
    const lastStaffMessageAt = ticket.lastStaffMessageAt ?? new Date(ticket.createdAt).getTime();
    const quietSince = Math.max(lastStaffMessageAt, ticket.waitingNotifiedAt ?? 0);
    const cooldownRemaining = quietSince + 30 * 60_000 - Date.now();
    if (cooldownRemaining > 0) {
      await sendInteractionResponse(
        interaction,
        `Je kunt support opnieuw taggen over ${Math.ceil(cooldownRemaining / 60_000)} minuten stilte.`,
      );
      return;
    }
    ticket.waitingNotifiedAt = Date.now();
    ticket.status = "waiting";
    await notifyTicketSupport(ticket, "De melder wacht op antwoord.");
  } else if (isTicketOwner) {
    await sendInteractionResponse(interaction, "Als melder kun je alleen op Wacht op antwoord klikken.");
    return;
  } else if (!(await interactionCanManageTicket(interaction, ticket))) {
    await sendInteractionResponse(interaction, "Alleen de ticket-support kan dit ticket beheren.");
    return;
  } else if (action === "reopen") {
    ticket.status = "open";
  } else if (action === "claim") {
    ticket.claimedBy = actorId;
    ticket.claimedAt = Date.now();
    ticket.status = "claimed";
  } else if (action === "waiting") {
    ticket.status = "waiting";
  }
  await saveConfig();
  void writeAuditLog(ticket.guildId, "ticket", "Ticket bijgewerkt", `Ticket **${ticket.subject}**: status **${ticketLabel(ticket.status)}** door <@${actorId}>.`, 0xf59e0b, { id: actorId, name: actorId });
  const ownerWaiting = action === "waiting" && isTicketOwner;
  if (!ownerWaiting) {
    if (action === "claim") {
      await discordRequest(`/channels/${channelId}/messages`, {
        method: "POST",
        body: JSON.stringify({
          content: `<:Ticket:1541433216748101732> **Ticket geclaimd** door <@${actorId}>`,
          allowed_mentions: { users: [actorId] },
        }),
      });
    } else if (action === "reopen") {
      await sendMessage(channelId, "Ticket heropend door het team.");
    } else {
      await sendMessage(channelId, "Ticket bijgewerkt.");
    }
  }
  if (ticket.messageId) {
    await discordRequest(`/channels/${channelId}/messages/${ticket.messageId}`, {
      method: "PATCH",
      body: JSON.stringify(componentsV2Payload(ticketNotificationContent(ticket), normalizeMessageOptions(ticketMessageOptions(ticket)))),
    });
  }
  await sendInteractionResponse(interaction, ownerWaiting ? "Ticket-support is opnieuw gepingt." : "Ticket bijgewerkt.");
}

async function cycleTicketPriority(interaction: DiscordInteraction) {
  const channelId = interaction.channel_id;
  const ticket = channelId ? tickets.get(channelId) : undefined;
  if (!ticket || !(await interactionCanManageTicket(interaction, ticket))) {
    await sendInteractionResponse(interaction, "Alleen de ticket-support kan de prioriteit wijzigen.");
    return;
  }
  const priorities: TicketRecord["priority"][] = ["low", "normal", "high"];
  ticket.priority = priorities[(priorities.indexOf(ticket.priority) + 1) % priorities.length];
  await saveConfig();
  if (ticket.messageId) {
    await discordRequest(`/channels/${channelId}/messages/${ticket.messageId}`, {
      method: "PATCH",
      body: JSON.stringify(componentsV2Payload(ticketNotificationContent(ticket), normalizeMessageOptions(ticketMessageOptions(ticket)))),
    });
  }
  await sendInteractionResponse(interaction, `Ticketprioriteit ingesteld op **${ticketLabel(ticket.priority)}**.`);
}

type TicketTranscriptMessage = {
  id: string;
  author?: { username?: string; global_name?: string };
  content?: string;
  timestamp?: string;
  attachments?: Array<{ filename?: string; url?: string }>;
  embeds?: Array<{ title?: string; description?: string; url?: string }>;
};

async function fetchTicketTranscriptMessages(channelId: string) {
  const messages: TicketTranscriptMessage[] = [];
  let before: string | undefined;
  for (let page = 0; page < 10; page += 1) {
    const query = before ? `&before=${before}` : "";
    const batch = await discordRequest<TicketTranscriptMessage[]>(
      `/channels/${channelId}/messages?limit=100${query}`,
    );
    if (!batch) return null;
    messages.push(...batch);
    if (batch.length < 100) break;
    before = batch.at(-1)?.id;
    if (!before) break;
  }
  return messages.reverse();
}

function escapeHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function transcriptText(messages: TicketTranscriptMessage[]) {
  return messages.map((entry) => {
    const author = entry.author?.global_name ?? entry.author?.username ?? "Onbekend";
    const attachments = (entry.attachments ?? [])
      .map((attachment) => `Bijlage: ${attachment.filename ?? attachment.url ?? "onbekend"} ${attachment.url ?? ""}`)
      .join("\n");
    const embeds = (entry.embeds ?? [])
      .map((embed) => [embed.title, embed.description, embed.url].filter(Boolean).join("\n"))
      .filter(Boolean)
      .join("\n");
    return `[${entry.timestamp ?? "onbekende tijd"}] ${author}:\n${[entry.content, attachments, embeds].filter(Boolean).join("\n")}`;
  }).join("\n\n");
}

function transcriptHtml(messages: TicketTranscriptMessage[], ticket: TicketRecord) {
  const rows = messages.map((entry) => {
    const author = entry.author?.global_name ?? entry.author?.username ?? "Onbekend";
    const body = [
      entry.content,
      ...(entry.attachments ?? []).map((attachment) => `Bijlage: ${attachment.filename ?? attachment.url ?? "onbekend"} ${attachment.url ?? ""}`),
      ...(entry.embeds ?? []).flatMap((embed) => [embed.title, embed.description, embed.url].filter(Boolean)),
    ].filter(Boolean).join("\n");
    return `<article><time>${escapeHtml(entry.timestamp ?? "onbekende tijd")}</time><strong>${escapeHtml(author)}</strong><p>${escapeHtml(body).replaceAll("\n", "<br>") || "&nbsp;"}</p></article>`;
  }).join("\n");
  return `<!doctype html><html lang="nl"><head><meta charset="utf-8"><title>Transcript ${escapeHtml(ticket.subject)}</title><style>body{font:15px system-ui,sans-serif;background:#202225;color:#f2f3f5;max-width:900px;margin:0 auto;padding:32px}h1{font-size:24px}article{border-bottom:1px solid #4f545c;padding:16px 0}time{color:#b9bbbe;font-size:12px;display:block;margin-bottom:4px}strong{color:#57f287}p{white-space:normal;line-height:1.5;margin:6px 0 0}</style></head><body><h1>Transcript: ${escapeHtml(ticket.subject)}</h1><p>Kanaal: ${escapeHtml(ticket.channelId)}<br>Aangemaakt: ${escapeHtml(ticket.createdAt)}</p>${rows}</body></html>`;
}

async function ensureTicketLogChannel(guildId: string) {
  const guild = getGuildConfig(guildId);
  if (guild.ticketLogChannelId) return guild.ticketLogChannelId;
  const channels = await discordRequest<Array<{ id: string; name?: string; type?: number }>>(`/guilds/${guildId}/channels`);
  const existing = channels?.find((channel) => channel.type === 0 && channel.name === "ticket-logs");
  if (existing) {
    guild.ticketLogChannelId = existing.id;
    await saveConfig();
    return existing.id;
  }
  const supportRoleIds = guild.ticketCategories
    .map((category) => category.supportRoleId)
    .filter((roleId): roleId is string => Boolean(roleId));
  const adminRoleIds = await administratorRoleIds(guildId);
  const visibleRoleIds = [...new Set([...supportRoleIds, ...adminRoleIds])];
  const created = await discordRequest<{ id?: string }>(`/guilds/${guildId}/channels`, {
    method: "POST",
    body: JSON.stringify({
      name: "ticket-logs",
      type: 0,
      permission_overwrites: [
        { id: guildId, type: 0, deny: "1024" },
        ...visibleRoleIds.map((roleId) => ({ id: roleId, type: 0, allow: "1024" })),
      ],
    }),
  });
  if (!created?.id) return undefined;
  guild.ticketLogChannelId = created.id;
  await saveConfig();
  return created.id;
}

async function sendTicketTranscripts(ticket: TicketRecord, messages: TicketTranscriptMessage[]) {
  const logChannelId = await ensureTicketLogChannel(ticket.guildId);
  if (!logChannelId) return false;
  const text = transcriptText(messages);
  const html = transcriptHtml(messages, ticket);
  const form = new FormData();
  form.append("payload_json", JSON.stringify({
    content: `Transcript van **${ticket.subject}** (${messages.length} berichten).`,
  }));
  form.append("files[0]", new Blob([text], { type: "text/plain" }), `ticket-${ticket.channelId}.txt`);
  form.append("files[1]", new Blob([html], { type: "text/html" }), `ticket-${ticket.channelId}.html`);
  const response = await fetch(`${DISCORD_API}/channels/${logChannelId}/messages`, {
    method: "POST",
    headers: { Authorization: `Bot ${token()}`, "User-Agent": "ReplitCommunityBot/1.0" },
    body: form,
  });
  if (!response.ok) logger.warn({ status: response.status }, "Tickettranscript versturen mislukt");
  return response.ok;
}

async function closeTicketRecord(ticket: TicketRecord, actorId: string) {
  const channelId = ticket.channelId;
  const transcriptMessages = await fetchTicketTranscriptMessages(channelId);
  const guild = getGuildConfig(ticket.guildId);
  const category = guild.ticketCategories.find((entry) => entry.id === ticket.categoryId);
  const adminRoleIds = await administratorRoleIds(ticket.guildId);
  const supportRoleIds = new Set<string>([
    ...(category?.supportRoleId ? [category.supportRoleId] : []),
    ...adminRoleIds,
  ]);
  ticket.status = "closed";
  const channelPermissions = await discordRequest<Array<{ id: string; type: number; allow: string; deny: string }>>(`/channels/${channelId}/permissions`);
  for (const permission of channelPermissions ?? []) {
    if (permission.type !== 1 || supportRoleIds.has(permission.id)) continue;
    await discordRequest(`/channels/${channelId}/permissions/${permission.id}`, {
      method: "PUT",
      body: JSON.stringify({ type: 1, allow: "0", deny: "2048" }),
    });
  }
  for (const roleId of supportRoleIds) {
    await discordRequest(`/channels/${channelId}/permissions/${roleId}`, {
      method: "PUT",
      body: JSON.stringify({ type: 0, allow: "68608" }),
    });
  }
  if (guild.closedTicketCategoryId) {
    await discordRequest(`/channels/${channelId}`, {
      method: "PATCH",
      body: JSON.stringify({ parent_id: guild.closedTicketCategoryId }),
    });
  }
  await saveConfig();
  void writeAuditLog(ticket.guildId, "ticket", "Ticket gesloten", `Ticket **${ticket.subject}** gesloten door <@${actorId}>.`, 0xed4245, { id: actorId, name: actorId });
  const closeNotice = await sendMessage(
    channelId,
    `${adminRoleIds.map((roleId) => `<@&${roleId}>`).join(" ")} Ticket gesloten door <@${actorId}>.`,
    adminRoleIds.length ? { allowed_mentions: { roles: adminRoleIds, users: [actorId] } } : {},
  );
  if (closeNotice && adminRoleIds.length) {
    const noticeId = String((closeNotice as { id?: string }).id ?? "");
    if (noticeId) setTimeout(() => void discordRequest(`/channels/${channelId}/messages/${noticeId}`, { method: "DELETE" }), 1500);
  }
  if (ticket.messageId) {
    await discordRequest(`/channels/${channelId}/messages/${ticket.messageId}`, {
      method: "PATCH",
      body: JSON.stringify(componentsV2Payload(ticketNotificationContent(ticket), normalizeMessageOptions(ticketMessageOptions(ticket)))),
    });
  }
  const transcriptSaved = transcriptMessages
    ? await sendTicketTranscripts(ticket, transcriptMessages)
    : false;
  return `Ticket gesloten (${ticket.type}).${transcriptSaved ? " Transcript opgeslagen in het ticket-logkanaal." : " Het transcript kon niet worden opgeslagen."}`;
}

async function closeTicket(interaction: DiscordInteraction) {
  const channelId = interaction.channel_id;
  if (!channelId || !tickets.has(channelId)) {
    await sendInteractionResponse(interaction, "Dit is geen actief ticket.");
    return;
  }
  const ticket = tickets.get(channelId);
  const actorId = interactionUserId(interaction);
  const canManage = ticket ? await interactionCanManageTicket(interaction, ticket) : false;
  if (!ticket || !actorId || !canManage) {
    await sendInteractionResponse(interaction, "Alleen de ticket-support kan tickets sluiten.");
    return;
  }
  await sendInteractionResponse(
    interaction,
    await closeTicketRecord(ticket, actorId),
  );
}

async function deleteTicketRecord(ticket: TicketRecord, actorId: string) {
  tickets.delete(ticket.channelId);
  await saveConfig();
  void writeAuditLog(ticket.guildId, "ticket", "Ticket verwijderd", `Ticket **${ticket.subject}** verwijderd door <@${actorId}>.`, 0xed4245, { id: actorId, name: actorId });
  await discordRequest(`/channels/${ticket.channelId}`, { method: "DELETE" });
}

async function deleteTicket(interaction: DiscordInteraction) {
  const channelId = interaction.channel_id;
  const ticket = channelId ? tickets.get(channelId) : undefined;
  if (!channelId || !ticket) {
    await sendInteractionResponse(interaction, "Dit is geen actief ticket.");
    return;
  }
  const isAdmin = await interactionCanAdmin(interaction);
  if (!isAdmin && interactionUserId(interaction) === ticket.userId) {
    await sendInteractionResponse(interaction, "Als melder kun je alleen op Wacht op antwoord klikken.");
    return;
  }
  if (!isAdmin) {
    await sendInteractionResponse(interaction, "Alleen admins kunnen tickets verwijderen.");
    return;
  }
  await sendInteractionResponse(interaction, "Ticket wordt verwijderd.");
  await deleteTicketRecord(ticket, interactionUserId(interaction) ?? "onbekend");
}

async function messageCanManageTicket(message: DiscordMessage, ticket: TicketRecord) {
  const actorId = message.author?.id;
  if (!actorId) return false;
  if (await hasPermission(message, "admin")) return true;
  if (actorId === ticket.userId) return false;
  if (await hasPermission(message, "manage")) return true;
  const category = getGuildConfig(ticket.guildId).ticketCategories.find((entry) => entry.id === ticket.categoryId);
  return Boolean(category?.supportRoleId && message.member?.roles?.includes(category.supportRoleId));
}

async function handleTicketCommand(message: DiscordMessage, action: "close" | "delete") {
  const ticket = tickets.get(message.channel_id);
  const actorId = message.author?.id;
  if (!ticket || !actorId) {
    const response = await reply(message, "Dit command kan alleen in een actief ticket worden gebruikt.");
    deleteMessageLater(message.channel_id, String((response as { id?: string } | null)?.id ?? ""));
    return;
  }
  if (action === "close") {
    if (!(await messageCanManageTicket(message, ticket))) {
      const response = await reply(message, "Alleen de ticket-support kan tickets sluiten.");
      deleteMessageLater(message.channel_id, String((response as { id?: string } | null)?.id ?? ""));
      return;
    }
    const response = await reply(message, await closeTicketRecord(ticket, actorId));
    deleteMessageLater(message.channel_id, String((response as { id?: string } | null)?.id ?? ""));
    return;
  }
  if (!(await hasPermission(message, "admin"))) {
    const response = await reply(message, "Alleen admins kunnen tickets verwijderen.");
    deleteMessageLater(message.channel_id, String((response as { id?: string } | null)?.id ?? ""));
    return;
  }
  await reply(message, "Ticket wordt verwijderd.");
  await deleteTicketRecord(ticket, actorId);
}

async function deleteChannelCommand(message: DiscordMessage) {
  if (!message.guild_id || !(await hasPermission(message, "admin"))) {
    const response = await reply(message, "Alleen admins kunnen kanalen verwijderen.");
    deleteMessageLater(message.channel_id, String((response as { id?: string } | null)?.id ?? ""));
    return;
  }
  const deleted = await discordRequest(`/channels/${message.channel_id}`, { method: "DELETE" });
  if (!deleted) {
    const response = await reply(message, "Het kanaal kon niet worden verwijderd. Controleer mijn Manage Channels-permissie.");
    deleteMessageLater(message.channel_id, String((response as { id?: string } | null)?.id ?? ""));
  }
}

async function startApplication(interaction: DiscordInteraction) {
  const guildId = interaction.guild_id;
  const userId = interaction.member?.user?.id ?? interaction.user?.id;
  if (!guildId || !userId) return;
  const guild = getGuildConfig(guildId);
  if (!guild.applicationQuestions.length) {
    await sendInteractionResponse(
      interaction,
      "Er zijn nog geen sollicitatievragen ingesteld.",
    );
    return;
  }
  const dm = await discordRequest<{ id: string }>("/users/@me/channels", {
    method: "POST",
    body: JSON.stringify({ recipient_id: userId }),
  });
  if (!dm?.id) {
    await sendInteractionResponse(
      interaction,
      "Ik kan je geen DM sturen. Zet privéberichten van serverleden aan en probeer opnieuw.",
    );
    return;
  }
  applicationSessions.set(userId, {
    guildId,
    userId,
    questions: guild.applicationQuestions.slice(0, 20),
    answers: [],
    index: 0,
  });
  await sendMessage(
    dm.id,
    `## Sollicitatie gestart\nJe krijgt ${Math.min(
      guild.applicationQuestions.length,
      20,
    )} vragen. Antwoord per bericht. Typ \`annuleren\` om te stoppen.\n\n**Vraag 1:** ${guild.applicationQuestions[0]}`,
  );
  await sendInteractionResponse(
    interaction,
    "Ik heb je een DM gestuurd. Controleer je privéberichten.",
  );
}

async function finishApplication(session: ApplicationSession) {
  const guild = getGuildConfig(session.guildId);
  session.submittedAt = Date.now();
  session.status = "pending";
  const lines = session.questions.map(
    (question, index) =>
      `**${index + 1}. ${question}**\n${session.answers[index] ?? "Geen antwoord"}`,
  );
  const body = [
    `## Nieuwe Sollicitatie`,
    `**Kandidaat:** <@${session.userId}> (\`${session.userId}\`)`,
    `**Ingediend:** <t:${Math.floor(session.submittedAt / 1000)}:F>`,
    "",
    lines.join("\n\n"),
  ].join("\n");
  if (guild.applicationReviewChannelId) {
    const embed = {
      title: "✉️ Sollicitatie ter beoordeling",
      description: `Kandidaat: <@${session.userId}>`,
      fields: [
        { name: "Aantal vragen", value: String(session.questions.length), inline: true },
        { name: "Status", value: "🟡 Wachtend op beoordeling", inline: true },
      ],
      color: 0x3b82f6,
      thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
      timestamp: new Date().toISOString(),
    };
    await sendMessage(guild.applicationReviewChannelId, body, {
      embeds: [embed],
      components: [
        {
          type: 1,
          components: [
            {
              type: 2,
              style: 3,
              label: "✅ Goedkeuren",
              custom_id: `application:approve:${session.userId}`,
            },
            {
              type: 2,
              style: 4,
              label: "❌ Afwijzen",
              custom_id: `application:reject:${session.userId}`,
            },
            {
              type: 2,
              style: 2,
              label: "📋 Bekijk details",
              custom_id: `application:view:${session.userId}`,
            },
          ],
        },
      ],
    });
  }
}

async function handleApplicationAnswer(message: DiscordMessage) {
  const session = applicationSessions.get(message.author?.id ?? "");
  if (!session) return false;
  const userId = message.author?.id ?? "";
  if (message.content.trim().toLowerCase() === "annuleren") {
    applicationSessions.delete(userId);
    await reply(message, "Je sollicitatie is geannuleerd.");
    return true;
  }
  session.answers.push(message.content.trim().slice(0, 2000));
  session.index += 1;
  if (session.index >= session.questions.length) {
    applicationSessions.delete(userId);
    await finishApplication(session);
    await reply(message, "Bedankt. Je sollicitatie is ingediend bij het team.");
    return true;
  }
  await reply(
    message,
    `**Vraag ${session.index + 1}:** ${session.questions[session.index]}`,
  );
  return true;
}

async function approveApplication(interaction: DiscordInteraction, userId: string) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen sollicitaties goedkeuren.");
    return;
  }
  const session = [...applicationSessions.values()].find((s) => s.userId === userId);
  if (session) {
    session.status = "approved";
    session.reviewedBy = interactionUserId(interaction);
  }
  const guild = getGuildConfig(guildId);
  if (guild.applicationApprovedRoleId) {
    await discordRequest(`/guilds/${guildId}/members/${userId}/roles/${guild.applicationApprovedRoleId}`, {
      method: "PUT",
    });
  }
  const embed = {
    title: "✅ Sollicitatie Goedgekeurd",
    description: `Je bent goedgekeurd! Welkom in het team! <@${userId}>`,
    color: 0x22c55e,
    timestamp: new Date().toISOString(),
  };
  await sendMessage(interaction.channel_id ?? "", "", { embeds: [embed] });
  try {
    const dm = await discordRequest<{ id: string }>("/users/@me/channels", {
      method: "POST",
      body: JSON.stringify({ recipient_id: userId }),
    });
    if (dm?.id) {
      await sendMessage(dm.id, "✅ Je sollicitatie is goedgekeurd! Welkom in ons team!");
    }
  } catch {}
  await sendInteractionResponse(interaction, "Sollicitatie goedgekeurd!");
}

async function rejectApplication(interaction: DiscordInteraction, userId: string) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen sollicitaties afwijzen.");
    return;
  }
  const session = [...applicationSessions.values()].find((s) => s.userId === userId);
  if (session) {
    session.status = "rejected";
    session.reviewedBy = interactionUserId(interaction);
  }
  const embed = {
    title: "❌ Sollicitatie Afgewezen",
    description: `Je sollicitatie is helaas niet goedgekeurd. Probeer het later opnieuw! <@${userId}>`,
    color: 0xef4444,
    timestamp: new Date().toISOString(),
  };
  await sendMessage(interaction.channel_id ?? "", "", { embeds: [embed] });
  try {
    const dm = await discordRequest<{ id: string }>("/users/@me/channels", {
      method: "POST",
      body: JSON.stringify({ recipient_id: userId }),
    });
    if (dm?.id) {
      await sendMessage(dm.id, "❌ Je sollicitatie is helaas niet goedgekeurd. Je kunt het later opnieuw proberen!");
    }
  } catch {}
  await sendInteractionResponse(interaction, "Sollicitatie afgewezen!");
}

async function robloxLookup(username: string) {
  const response = await fetch("https://users.roblox.com/v1/usernames/users", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      usernames: [username],
      excludeBannedUsers: false,
    }),
  });
  if (!response.ok) return null;
  const data = (await response.json()) as {
    data?: Array<{ id: number; name: string; displayName: string }>;
  };
  return data.data?.[0] ?? null;
}

async function sendRobloxUnbanProfile(channelId: string, username: string) {
  try {
    const user = await robloxLookup(username);
    if (!user) {
      await sendMessage(channelId, `Roblox-gebruiker **${username}** kon niet worden gevonden. Controleer de gebruikersnaam in de aanvraag.`);
      return;
    }
    const [detailsResponse, avatarResponse] = await Promise.all([
      fetch(`https://users.roblox.com/v1/users/${user.id}`),
      fetch(`https://thumbnails.roblox.com/v1/users/avatar?userIds=${user.id}&size=720x720&format=Png&isCircular=false`),
    ]);
    const details = detailsResponse.ok
      ? await detailsResponse.json() as { created?: string; description?: string }
      : {};
    const avatar = avatarResponse.ok
      ? await avatarResponse.json() as { data?: Array<{ imageUrl?: string }> }
      : {};
    const outfitUrl = avatar.data?.[0]?.imageUrl;
    await sendMessage(channelId, "", {
      embeds: [{
        title: `Unban aanvraag • ${user.name}`,
        description: [
          `**Roblox username:** ${user.name}`,
          `**Display name:** ${user.displayName}`,
          `**User ID:** \`${user.id}\``,
          `**Profiel:** https://www.roblox.com/users/${user.id}/profile`,
          details.created ? `**Account aangemaakt:** <t:${Math.floor(new Date(details.created).getTime() / 1000)}:D>` : "",
          details.description ? `**Bio:** ${details.description.slice(0, 500)}` : "",
        ].filter(Boolean).join("\n"),
        color: 0x2dd4bf,
        ...(outfitUrl ? { image: { url: outfitUrl } } : {}),
        thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
        footer: { text: "Roblox-profiel automatisch opgehaald voor deze unban-aanvraag" },
      }],
    });
  } catch (error) {
    logger.warn({ error, username }, "Roblox-profiel kon niet worden opgehaald");
    await sendMessage(channelId, "De Roblox-profielinformatie kon tijdelijk niet worden opgehaald. Support kan de aanvraag handmatig controleren.");
  }
}

async function logModeration(
  guild: GuildConfig,
  title: string,
  description: string,
  color: number,
) {
  if (!guild.moderationLogChannelId) return;
  await sendMessage(guild.moderationLogChannelId, "", {
    embeds: [{
      title,
      description,
      color: GREY_EMBED_COLOR,
      thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
      timestamp: new Date().toISOString(),
    }],
  });
}

async function writeAuditLog(
  guildId: string,
  event: AuditLogType,
  title: string,
  description: string,
  color = GREY_EMBED_COLOR,
  actor?: { id?: string; name?: string; avatar?: string | null },
) {
  const guild = getGuildConfig(guildId);
  const channelId = guild.auditLogs.channels[event];
  if (!guild.auditLogs.enabled || !channelId || guild.auditLogs.events[event] === false) return;
  const actorName = actor?.name ?? "Systeem";
  await sendMessage(channelId, "", {
    embeds: [{
      title: `[${event.toUpperCase()}] ${title}`.slice(0, 256),
      description: description.slice(0, 4000),
      color,
      author: actor?.id ? { name: actorName, icon_url: avatarUrl(actor.id, actor.avatar) } : { name: actorName },
      thumbnail: actor?.id ? { url: avatarUrl(actor.id, actor.avatar) } : { url: DEFAULT_PANEL_THUMBNAIL },
      timestamp: new Date().toISOString(),
      footer: { text: `Auditlog • <t:${Math.floor(Date.now() / 1000)}:R> • ${guildId}` },
    }],
  });
}

function auditLogChannelPayload(guild: GuildConfig) {
  return {
    embeds: [{
      title: "Auditlogs instellen",
      description: "Kies een logtype. Het huidige kanaal wordt gekoppeld aan dat type. Herhaal `~logs kanaal` in een ander kanaal voor de volgende logcategorie.",
      color: 0x2dd4bf,
      thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
      footer: { text: "Per logtype kan een eigen kanaal worden ingesteld." },
    }],
    components: [{
      type: 1,
      components: [{
        type: 3,
        custom_id: "auditlog:channel:select",
        placeholder: "Kies welk logtype dit kanaal ontvangt",
        min_values: 1,
        max_values: 1,
        options: AUDIT_LOG_TYPES.map((event) => ({
          label: `${event[0].toUpperCase()}${event.slice(1)} logs`.slice(0, 100),
          value: event,
          description: `Alle ${event}-gebeurtenissen naar dit kanaal`.slice(0, 100),
          default: guild.auditLogs.channels[event] === undefined ? false : undefined,
        })),
      }],
    }],
  };
}

async function handleAuditLogsCommand(message: DiscordMessage, args: string[]) {
  if (!message.guild_id || !(await hasPermission(message, "manage"))) {
    await reply(message, "Alleen bevoegde teamleden kunnen auditlogs instellen.");
    return;
  }
  const guild = getGuildConfig(message.guild_id);
  const action = args.shift()?.toLowerCase();
  if (action === "kanaal" || action === "channel") {
    await sendMessage(message.channel_id, "", auditLogChannelPayload(guild));
    return;
  }
  if (action === "aan" || action === "on") {
    if (!Object.keys(guild.auditLogs.channels).length) {
      await reply(message, "Stel eerst kanalen in met `~logs kanaal`.");
      return;
    }
    guild.auditLogs.enabled = true;
    await saveConfig();
    await reply(message, "Auditlogs ingeschakeld.");
    return;
  }
  if (action === "uit" || action === "off") {
    guild.auditLogs.enabled = false;
    await saveConfig();
    await reply(message, "Auditlogs uitgeschakeld.");
    return;
  }
  if (action === "args") {
    const value = args[0]?.toLowerCase();
    if (!["aan", "uit", "on", "off"].includes(value ?? "")) {
      await reply(message, "Gebruik `~logs args aan` of `~logs args uit`.");
      return;
    }
    guild.auditLogs.includeCommandArgs = value === "aan" || value === "on";
    await saveConfig();
    await reply(message, `Command-argumenten worden ${guild.auditLogs.includeCommandArgs ? "wel" : "niet"} gelogd.`);
    return;
  }
  if (action === "event") {
    const event = args[0]?.toLowerCase();
    const value = args[1]?.toLowerCase();
    const supported = Object.keys(guild.auditLogs.events);
    if (event === "all") {
      if (!["aan", "uit", "on", "off"].includes(value ?? "")) {
        await reply(message, "Gebruik `~logs event all aan|uit`.");
        return;
      }
      for (const key of supported) guild.auditLogs.events[key] = value === "aan" || value === "on";
    } else if (event && supported.includes(event) && ["aan", "uit", "on", "off"].includes(value ?? "")) {
      guild.auditLogs.events[event] = value === "aan" || value === "on";
    } else {
      await reply(message, `Events: ${supported.join(", ")}. Gebruik bijvoorbeeld \`~logs event ticket aan\`.`);
      return;
    }
    await saveConfig();
    await reply(message, "Auditlog-events opgeslagen.");
    return;
  }
  await reply(message, [
    "Auditlogstatus:",
    `Aan: **${guild.auditLogs.enabled ? "ja" : "nee"}**`,
    `Kanalen: ${Object.entries(guild.auditLogs.channels).map(([event, channelId]) => `${event}: <#${channelId}>`).join(" • ") || "niet ingesteld"}`,
    `Events: ${Object.entries(guild.auditLogs.events).filter(([, enabled]) => enabled).map(([event]) => event).join(", ") || "geen"}`,
    "",
    "Gebruik: `~logs kanaal` in het gewenste kanaal, daarna `~logs aan|uit`, `~logs event command aan`, `~logs event all aan`, `~logs args aan|uit`.",
  ].join("\n"));
}

async function configureAuditLogChannel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const channelId = interaction.channel_id;
  const event = interaction.data?.values?.[0] as AuditLogType | undefined;
  if (!guildId || !channelId || !event || !AUDIT_LOG_TYPES.includes(event) || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen auditlogkanalen instellen.");
    return;
  }
  const guild = getGuildConfig(guildId);
  guild.auditLogs.channels[event] = channelId;
  guild.auditLogs.enabled = true;
  await saveConfig();
  await sendInteractionResponse(interaction, `Dit kanaal is ingesteld voor **${event} logs**. Gebruik opnieuw \`~logs kanaal\` in een ander kanaal voor een volgend logtype.`);
}

async function handleBanCommand(message: DiscordMessage, args: string[]) {
  if (!message.guild_id || !(await hasPermission(message, "ban"))) {
    await reply(message, "Je hebt geen toestemming om dit te doen.");
    return;
  }
  const targetId = await resolveTargetUserId(message.guild_id, args[0] ?? "");
  const robloxName = args[1];
  const reason = args.slice(2).join(" ") || "Geen reden opgegeven";
  if (!targetId || !robloxName) {
    await reply(message, "Gebruik: `~ban @DiscordGebruiker RobloxNaam reden`");
    return;
  }
  const robloxUser = await robloxLookup(robloxName);
  if (!robloxUser) {
    await reply(message, `Roblox-gebruiker \`${robloxName}\` is niet gevonden.`);
    return;
  }
  const banned = await discordRequest(
    `/guilds/${message.guild_id}/bans/${targetId}`,
    {
      method: "PUT",
      body: JSON.stringify({ delete_message_seconds: 86400 }),
    },
  );
  if (banned === null) {
    await reply(message, "De Discord-ban is mislukt. Controleer mijn permissies.");
    return;
  }
  const guild = getGuildConfig(message.guild_id);
  await logModeration(
    guild,
    "Gebruiker geband",
    [
      `Discord: <@${targetId}> (\`${targetId}\`)`,
      `Roblox: **${robloxUser.name}** (\`${robloxUser.id}\`)`,
      `Door: <@${message.author?.id ?? "onbekend"}>`,
      `Reden: ${reason}`,
    ].join("\n"),
    0xed4245,
  );
  await reply(
    message,
    `Geband: <@${targetId}>. Roblox-account herkend als **${robloxUser.name}** (\`${robloxUser.id}\`).`,
  );
}

async function answerWithAI(prompt: string, context = "", model = "openai/gpt-4o-mini") {
  const key =
    process.env.OPENROUTER_API_KEY?.trim() ??
    process.env.OPENROUTOR_API_KEY?.trim();
  if (!key) {
    return "AI-chat is nog niet geconfigureerd. Voeg `OPENROUTOR_API_KEY` toe in Secrets.";
  }
  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      "HTTP-Referer": "https://replit.com",
      "X-Title": "Community Discord Bot",
    },
    body: JSON.stringify({
      model,
      max_tokens: 8192,
      messages: [
        {
          role: "system",
          content:
            "Je bent een vriendelijke, enthousiaste Nederlandstalige community-assistent. Reageer warm, menselijk en behulpzaam. Gebruik regelmatig passende emoji's (meestal 2 tot 5 per antwoord, niet midden in elk woord), zoals 🙂, 👍, ✨, 🎉 of 💡. Houd antwoorden duidelijk, respectvol en veilig. Geef geen instructies voor misbruik. Pas je toon aan de vraag aan en overdrijf emoji's niet bij serieuze onderwerpen.",
        },
        ...(context ? [{ role: "user", content: context }] : []),
        { role: "user", content: prompt },
      ],
    }),
  });
  if (!response.ok) {
    logger.warn({ status: response.status }, "OpenRouter request failed");
    return "De AI-service reageert momenteel niet. Probeer het later opnieuw.";
  }
  const body = (await response.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  return (
    body.choices?.[0]?.message?.content ??
    "Ik kreeg geen bruikbaar antwoord van de AI-service."
  );
}

async function generateImage(prompt: string) {
  const key = process.env.OPENAI_API_KEY?.trim();
  if (!key) return undefined;
  const response = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "dall-e-3",
      prompt: prompt.slice(0, 4000),
      size: "1024x1024",
      response_format: "url",
    }),
  });
  if (!response.ok) {
    logger.warn({ status: response.status }, "Image generation failed");
    return undefined;
  }
  const body = (await response.json()) as {
    data?: Array<{ url?: string; b64_json?: string }>;
  };
  return body.data?.[0]?.url;
}

async function handleAIChatCommand(message: DiscordMessage, args: string[]) {
  if (!message.guild_id || !(await hasPermission(message, "manage"))) {
    await reply(message, "Je hebt geen beheerpermissie voor AI-chat.");
    return;
  }
  const guild = getGuildConfig(message.guild_id);
  const channelId = channelIdFromArg(args[0] ?? "");
  if (channelId) {
    guild.aiChatChannelId = channelId;
    await saveConfig();
    await reply(message, `AI-chat staat nu aan in <#${channelId}>. Gebruik daar gewone berichten of "afbeelding <prompt>".`);
    return;
  }
  await reply(message, guild.aiChatChannelId
    ? `AI-chat staat aan in <#${guild.aiChatChannelId}>. Gebruik "afbeelding <prompt>" voor een afbeelding.`
    : "Gebruik `~aichat #kanaal` om een AI-kanaal in te stellen.");
}

async function handleAIChatMessage(message: DiscordMessage) {
  if (!message.guild_id || message.content.startsWith(PREFIX)) return false;
  const guild = getGuildConfig(message.guild_id);
  if (guild.aiChatChannelId !== message.channel_id) return false;
  const content = message.content.trim();
  if (!content) return true;
  const contextKey = `${message.guild_id}:${message.channel_id}:${message.author?.id ?? "unknown"}`;
  const cooldownKey = `${contextKey}:ai`;
  const now = Date.now();
  if ((cooldowns.get(cooldownKey) ?? 0) > now) {
    await reply(message, `Wacht nog ${Math.ceil(((cooldowns.get(cooldownKey) ?? now) - now) / 1000)} seconden.`);
    return true;
  }
  cooldowns.set(cooldownKey, now + guild.aiChatCooldownSeconds * 1000);
  const imagePrompt = content.replace(/^(?:afbeelding|image)\s+/i, "");
  if (imagePrompt !== content) {
    if (!guild.aiChatImagesEnabled) {
      await reply(message, "Afbeeldingen zijn uitgeschakeld in de AI-instellingen.");
      return true;
    }
    const imageUrl = await generateImage(imagePrompt);
    if (imageUrl) {
      await sendMessage(message.channel_id, "", {
        message_reference: { message_id: message.id, channel_id: message.channel_id, guild_id: message.guild_id },
        allowed_mentions: { replied_user: true },
        embeds: [{
          title: "AI-afbeelding",
          description: imagePrompt.slice(0, 4000),
          color: GREY_EMBED_COLOR,
          image: { url: imageUrl },
          thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
        }],
      });
    } else {
      await reply(message, "Afbeeldingen zijn nog niet geconfigureerd. Voeg `OPENAI_API_KEY` toe.");
    }
    return true;
  }
  const context = aiContexts.get(contextKey) ?? [];
  const answer = await answerWithAI(
    content,
    context.map((entry) => `${entry.role}: ${entry.content}`).join("\n"),
    guild.aiChatModel,
  );
  const boundedAnswer = answer.slice(0, guild.aiChatMaxResponseLength);
  context.push({ role: "user", content: content.slice(0, 1200) });
  context.push({ role: "assistant", content: boundedAnswer });
  aiContexts.set(contextKey, context.slice(-guild.aiChatContextMessages));
  await reply(message, boundedAnswer);
  return true;
}

async function classifyWithAI(content: string) {
  const key =
    process.env.OPENROUTER_API_KEY?.trim() ??
    process.env.OPENROUTOR_API_KEY?.trim();
  if (!key) return false;
  try {
    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      signal: AbortSignal.timeout(2500),
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://replit.com",
        "X-Title": "Community Discord Bot Moderation",
      },
      body: JSON.stringify({
        model: "openai/gpt-4o-mini",
        max_tokens: 8192,
        messages: [
          {
            role: "system",
            content:
              'Beoordeel alleen de tekst. Antwoord uitsluitend met JSON in dit formaat: {"remove":true|false,"reason":"link"|"scheldwoord"|"ok"}. Verwijder reclame-links, phishing, bedreigingen, haat of ernstige beledigingen. Laat normale gesprekken staan.',
          },
          { role: "user", content: content.slice(0, 1200) },
        ],
      }),
    });
    if (!response.ok) return false;
    const body = (await response.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const raw = body.choices?.[0]?.message?.content ?? "";
    const parsed = JSON.parse(raw.replace(/```json|```/g, "").trim()) as {
      remove?: boolean;
    };
    return parsed.remove === true;
  } catch (error) {
    logger.debug({ error }, "AI moderation skipped");
    return false;
  }
}

async function handleGames(message: DiscordMessage, name: string, args: string[]) {
  const guildId = message.guild_id;
  if (!guildId) return;
  const guild = getGuildConfig(guildId);
  if (name === "tellen") {
    if (args[0] === "kanaal" && args[1]) {
      const channelId = channelIdFromArg(args[1]);
      if (!channelId) {
        await reply(message, "Gebruik een geldig kanaal, bijvoorbeeld `#tellen`.");
        return;
      }
      guild.countingChannelId = channelId;
      guild.countingNumber = 1;
      await saveConfig();
      await reply(message, `Tellen staat nu aan in <#${channelId}> vanaf 1.`);
      return;
    }
    await reply(
      message,
      guild.countingChannelId
        ? `Tellen staat aan in <#${guild.countingChannelId}>. Volgend getal: **${guild.countingNumber}**.`
        : "Stel eerst een telkanaal in met `~tellen kanaal #kanaal`.",
    );
    return;
  }
  if (name === "raad" || name === "raadhetgetal") {
    const min = Number.parseInt(args[0] ?? "", 10);
    const max = Number.parseInt(args[1] ?? "", 10);
    const explicitNumber = Number.parseInt(args[0] ?? "", 10);
    if (Number.isInteger(explicitNumber) && Number.isNaN(max) && explicitNumber >= 1 && explicitNumber <= 100) {
      guild.guessPanel.minNumber = 1;
      guild.guessPanel.maxNumber = 100;
      guild.guessNumber = explicitNumber;
      guild.guessChannelId = message.channel_id;
      await saveConfig();
      await reply(message, "Nieuw raad-het-getal-spel gestart tussen 1 en 100.");
      return;
    }
    if (Number.isInteger(min) && Number.isInteger(max) && min >= 1 && max >= min) {
      guild.guessPanel.minNumber = min;
      guild.guessPanel.maxNumber = max;
      guild.guessNumber = Math.min(max, Math.max(min, Math.floor(Math.random() * (max - min + 1)) + min));
      guild.guessChannelId = message.channel_id;
      await saveConfig();
      await reply(message, `Nieuw raad-het-getal-spel gestart tussen **${min}** en **${max}**.`);
      return;
    }
    await reply(message, "Gebruik `~raad [minimum maximum]` of `~raad [geheim getal 1-100]`.");
    return;
  }
  if (name === "spel") {
    const game = args[0]?.toLowerCase();
    if (game === "munt" || game === "coin") {
      await reply(message, Math.random() > 0.5 ? "Kop!" : "Munt!");
      return;
    }
    if (game === "dobbel" || game === "dice") {
      await reply(message, `Je gooide **${Math.floor(Math.random() * 6) + 1}**.`);
      return;
    }
    if (game === "steen" || game === "rps" || game === "sps") {
      const choices = ["steen", "papier", "schaar"];
      const choice = args[1]?.toLowerCase();
      if (!choices.includes(choice ?? "")) {
        await reply(message, "Gebruik `~spel steen steen|papier|schaar`.");
        return;
      }
      const botChoice = choices[Math.floor(Math.random() * choices.length)];
      const win = choice === botChoice || (choice === "steen" && botChoice === "schaar") || (choice === "papier" && botChoice === "steen") || (choice === "schaar" && botChoice === "papier");
      await reply(message, `Jij koos **${choice}**, ik koos **${botChoice}**. ${choice === botChoice ? "Gelijkspel." : win ? "Je wint!" : "Ik win!"}`);
      return;
    }
    if (game === "8ball" || game === "achtbal") {
      const answers = ["Zeker weten.", "De vooruitzichten zijn goed.", "Vraag het later opnieuw.", "Waarschijnlijk niet.", "Mijn antwoord is nee.", "Daar kan ik nu niets zinnigs over zeggen."];
      await reply(message, `🎱 ${answers[Math.floor(Math.random() * answers.length)]}`);
      return;
    }
    if (game === "casino" || game === "carino" || game === "slots") {
      const symbols = ["🍒", "🍋", "🔔", "💎", "7️⃣"];
      const result = Array.from({ length: 3 }, () => symbols[Math.floor(Math.random() * symbols.length)]);
      const win = result[0] === result[1] && result[1] === result[2];
      const pair = result[0] === result[1] || result[1] === result[2] || result[0] === result[2];
      await reply(message, `🎰 **[ ${result.join(" | ")} ]**\n${win ? "JACKPOT! Drie dezelfde!" : pair ? "Kleine winst: een paar!" : "Geen winst deze ronde."}`);
      return;
    }
    if (game === "roulette") {
      const number = Math.floor(Math.random() * 37);
      const color = number === 0 ? "groen" : number % 2 === 0 ? "zwart" : "rood";
      await reply(message, `🎡 Roulette valt op **${number}** (${color}).`);
      return;
    }
    if (game === "hogerlager" || game === "highlow") {
      const first = Math.floor(Math.random() * 13) + 1;
      const second = Math.floor(Math.random() * 13) + 1;
      await reply(message, `🃏 Eerste kaart: **${first}**\nTweede kaart: **${second}** — ${second === first ? "gelijk!" : second > first ? "hoger!" : "lager!"}`);
      return;
    }
    if (game === "blackjack") {
      const hand = () => Math.floor(Math.random() * 10) + 2;
      const player = hand() + hand();
      const dealer = hand() + hand();
      await reply(message, `♠️ Jij: **${player}** | Dealer: **${dealer}**\n${player > 21 ? "Bust!" : dealer > 21 || player > dealer ? "Je wint!" : player === dealer ? "Gelijkspel." : "Dealer wint."}`);
      return;
    }
    await reply(message, "Beschikbaar: `munt`, `dobbel`, `steen steen`, `8ball`, `casino`, `roulette`, `hogerlager` en `blackjack`.");
  }
}

async function handlePanelCommand(
  message: DiscordMessage,
  args: string[],
  publicPanel = false,
) {
  if (!message.guild_id) return;
  if (!args[0]) {
    const guild = getGuildConfig(message.guild_id);
    if (publicPanel) {
      const posted = await sendMessage(message.channel_id, "", managementPanelPayload(guild));
      if (!posted) await reply(message, "Het beheerpanel kon niet worden geplaatst. Controleer mijn Send Messages en Embed Links permissies.");
      return;
    }
    const confirmation = await reply(message, "Gebruik `/panel` voor het privébeheerpanel in deze server. Gebruik `~ppanel` om het panel publiek te plaatsen.");
    deleteMessageLater(message.channel_id, String((confirmation as { id?: string } | null)?.id ?? ""));
    return;
  }
  if (!(await hasPermission(message, "manage"))) return;
  const guild = getGuildConfig(message.guild_id);
  const panelKind = args.shift()?.toLowerCase();
  const action = args.shift()?.toLowerCase();

  const mapping: Record<string, { panel: PanelConfig; kind: "ticket" | "application" } | null> = {
    ticket: { panel: guild.ticketPanel, kind: "ticket" },
    sollicitatie: { panel: guild.applicationPanel, kind: "application" },
    sollicitatiepanel: { panel: guild.applicationPanel, kind: "application" },
    application: { panel: guild.applicationPanel, kind: "application" },
    tellen: { panel: guild.countingPanel, kind: "application" },
    counting: { panel: guild.countingPanel, kind: "application" },
    raad: { panel: guild.guessPanel, kind: "application" },
    raadhetgetal: { panel: guild.guessPanel, kind: "application" },
    guess: { panel: guild.guessPanel, kind: "application" },
  };

  const target = mapping[panelKind ?? ""] ?? null;
  if (!target && !["clock", "moderatie", "moderation", "giveaway", "welkom", "help", "hulp"].includes(panelKind ?? "")) {
    await reply(message, "Gebruik `~panel` of `~panel ticket|sollicitatie|tellen|raad|clock|giveaway|moderatie`.");
    return;
  }

  if (action === "show") {
    if (panelKind === "clock") {
      await sendMessage(message.channel_id, "", clockPanelPayload(guild));
      return;
    }
    if (panelKind === "moderatie" || panelKind === "moderation") {
      await sendMessage(message.channel_id, "", moderationPanelPayload(guild));
      return;
    }
    if (panelKind === "giveaway") {
      await sendMessage(message.channel_id, "", giveawayPanelPayload(guild));
      return;
    }
    if (panelKind === "welkom") {
      await sendMessage(message.channel_id, "", welcomePanelPayload(guild));
      return;
    }
    if (panelKind === "help" || panelKind === "hulp") {
      await sendMessage(message.channel_id, "", helpPayload());
      return;
    }
    if (target) {
      await sendPanel(message.channel_id, target.panel, target.kind);
      return;
    }
  }

  if (action && action !== "edit") {
    await reply(message, "Gebruik `~panel ... edit title ...`, `description ...`, `color #2f3136`, `button ...` of `show`.");
    return;
  }

  if (!action && target) {
    await sendPanel(message.channel_id, target.panel, target.kind);
    return;
  }

  if (!action || action === "edit") {
    if (panelKind === "clock") {
      const guildId = message.guild_id;
      if (!guildId) return;
      guild.clockChannelId = message.channel_id;
      await saveConfig();
      await sendMessage(message.channel_id, "", clockPanelPayload(guild));
      await reply(message, "Klokpanel geplaatst.");
      return;
    }
    if (panelKind === "moderatie" || panelKind === "moderation") {
      await sendMessage(message.channel_id, "", moderationPanelPayload(guild));
      return;
    }
    if (panelKind === "giveaway") {
      guild.giveawayChannelId = message.channel_id;
      await saveConfig();
      await sendMessage(message.channel_id, "", giveawayPanelPayload(guild));
      return;
    }
    if (panelKind === "tellen" || panelKind === "counting") {
      guild.countingChannelId = message.channel_id;
      guild.countingNumber = 1;
      await saveConfig();
      await sendMessage(message.channel_id, "", countingPanelPayload(guild));
      return;
    }
    if (panelKind === "raad" || panelKind === "guess" || panelKind === "raadhetgetal") {
      guild.guessChannelId = message.channel_id;
      await saveConfig();
      await sendMessage(message.channel_id, "", guessPanelPayload(guild));
      return;
    }
    if (!target) {
      await reply(message, "Gebruik `~panel ticket|sollicitatie|tellen|raad|clock|giveaway|moderatie`.");
      return;
    }
    const field = args.shift()?.toLowerCase();
    const value = args.join(" ").trim();
    if (!field || !value) {
      await reply(message, "Geef een veld en waarde op.");
      return;
    }
    if (field === "title") target.panel.title = value.slice(0, 256);
    else if (field === "description") target.panel.description = value.slice(0, 4000);
    else if (field === "button") target.panel.buttonLabel = value.slice(0, 80);
    else if (field === "color") {
      const color = colorValue(value);
      if (color === undefined) {
        await reply(message, "Gebruik een hexkleur zoals `#2f3136`.");
        return;
      }
      target.panel.color = color;
    } else {
      await reply(message, "Onbekend veld. Kies title, description, color of button.");
      return;
    }
    await saveConfig();
    await refreshConfiguredPanel(guild, target.kind);
    await reply(message, "Panel opgeslagen. Gebruik `~panel ... show` om het te plaatsen.");
  }
}

async function handleSetup(message: DiscordMessage, args: string[]) {
  if (!message.guild_id || !(await hasPermission(message, "manage"))) return;
  const kind = args[0]?.toLowerCase();
  const guild = getGuildConfig(message.guild_id);
  if (kind === "ticket" || kind === "tickets") {
    await ensureUnbanCategory(message.guild_id);
    guild.ticketPanelChannelId = message.channel_id;
    await saveConfig();
    const ticketPanelMessage = await sendPanel(message.channel_id, guild.ticketPanel, "ticket", false);
    guild.ticketPanelMessageId = String((ticketPanelMessage as { id?: string } | null)?.id ?? "");
    await saveConfig();
    await reply(message, "Ticketpanel geplaatst en categorieën voorbereid.");
    return;
  }
  if (kind === "sollicitatie" || kind === "solliciteer") {
    guild.applicationPanelChannelId = message.channel_id;
    guild.applicationReviewChannelId = message.channel_id;
    await saveConfig();
    const applicationPanelMessage = await sendPanel(message.channel_id, guild.applicationPanel, "application", false);
    guild.applicationPanelMessageId = String((applicationPanelMessage as { id?: string } | null)?.id ?? "");
    await saveConfig();
    await reply(
      message,
      "Sollicitatiepanel geplaatst. Review-antwoorden komen voorlopig in dit kanaal.",
    );
    return;
  }
  await reply(message, "Gebruik `~setup ticket` of `~setup sollicitatie`.");
}

async function handleApplicationQuestions(
  message: DiscordMessage,
  args: string[],
) {
  if (!message.guild_id || !(await hasPermission(message, "manage"))) return;
  const guild = getGuildConfig(message.guild_id);
  const action = args.shift()?.toLowerCase();
  if (action === "list") {
    await reply(
      message,
      guild.applicationQuestions.length
        ? guild.applicationQuestions
            .map((question, index) => `${index + 1}. ${question}`)
            .join("\n")
        : "Er zijn nog geen vragen.",
    );
    return;
  }
  if (action === "add") {
    const question = args.join(" ").trim();
    if (!question) {
      await reply(message, "Gebruik `~sollicitatie vraag add jouw vraag`.");
      return;
    }
    if (guild.applicationQuestions.length >= 20) {
      await reply(message, "Je kunt maximaal 20 vragen instellen.");
      return;
    }
    guild.applicationQuestions.push(question.slice(0, 500));
    await saveConfig();
    await reply(message, `Vraag ${guild.applicationQuestions.length} toegevoegd.`);
    return;
  }
  if (action === "remove") {
    const index = Number.parseInt(args[0] ?? "", 10) - 1;
    if (index < 0 || index >= guild.applicationQuestions.length) {
      await reply(message, "Geef een bestaand vraagnummer op.");
      return;
    }
    guild.applicationQuestions.splice(index, 1);
    await saveConfig();
    await reply(message, "Vraag verwijderd.");
    return;
  }
  if (action === "edit") {
    const index = Number.parseInt(args[0] ?? "", 10) - 1;
    const question = args.slice(1).join(" ").trim();
    if (index < 0 || index >= guild.applicationQuestions.length || !question) {
      await reply(message, "Gebruik `~sollicitatie vraag edit nummer nieuwe vraag`.");
      return;
    }
    guild.applicationQuestions[index] = question.slice(0, 500);
    await saveConfig();
    await reply(message, `Vraag ${index + 1} bijgewerkt.`);
    return;
  }
  await reply(message, "Gebruik `~sollicitatie vraag list|add|edit|remove`.");
}

async function handleConfig(message: DiscordMessage, args: string[]) {
  if (!message.guild_id || !(await hasPermission(message, "manage"))) return;
  const guild = getGuildConfig(message.guild_id);
  const area = args.shift()?.toLowerCase();
  const key = args.shift()?.toLowerCase();
  const value = args.join(" ").trim();
  if (area === "welcome") {
    if (key === "kanaal") guild.welcomeChannelId = channelIdFromArg(value);
    else if (key === "rol") guild.welcomeRoleId = mentionId(value) ?? value;
    else if (key === "tekst") guild.welcomeMessage = value.slice(0, 1000);
    else {
      await reply(message, "Gebruik `~config welcome kanaal|rol|tekst ...`.");
      return;
    }
    await saveConfig();
    await reply(message, "Welkominstelling opgeslagen.");
    return;
  }
  if (area === "moderatie") {
    if (key === "log") guild.moderationLogChannelId = channelIdFromArg(value);
    else if (key === "links") guild.linksEnabled = value.toLowerCase() !== "uit";
    else if (key === "schelden") guild.swearingEnabled = value.toLowerCase() !== "uit";
    else if (key === "ai") guild.aiModerationEnabled = value.toLowerCase() === "aan";
    else {
      await reply(message, "Gebruik `~config moderatie log|links|schelden|ai ...`.");
      return;
    }
    await saveConfig();
    await reply(message, "Moderatie-instelling opgeslagen.");
    return;
  }
  if (area === "sollicitatie" && key === "review") {
    guild.applicationReviewChannelId = channelIdFromArg(value);
    await saveConfig();
    await reply(message, "Reviewkanaal opgeslagen.");
    return;
  }
  if (area === "sollicitatie" && key === "rol") {
    guild.applicationApprovedRoleId = mentionId(value) ?? value;
    await saveConfig();
    await reply(message, "Goedkeuringsrol opgeslagen.");
    return;
  }
  if (area === "tellen" && key === "kanaal") {
    guild.countingChannelId = channelIdFromArg(value);
    guild.countingNumber = 1;
    await saveConfig();
    await reply(message, "Telkanaal opgeslagen.");
    return;
  }
  await reply(
    message,
    "Beschikbaar: `welcome`, `moderatie`, `sollicitatie review`, `tellen kanaal`.",
  );
}

async function handleClock(message: DiscordMessage, args: string[]) {
  if (!message.guild_id || !(await hasPermission(message, "manage"))) return;
  const guild = getGuildConfig(message.guild_id);
  const action = args.shift()?.toLowerCase();
  if (action === "list") {
    await reply(
      message,
      guild.clockRoles.length
        ? guild.clockRoles.map((entry) => `${entry.time} → <@&${entry.roleId}>`).join("\n")
        : "Nog geen klokrollen ingesteld.",
    );
    return;
  }
  if (action === "rol" && args[0] === "add") {
    const time = args[1];
    const roleId = mentionId(args[2] ?? "") ?? args[2];
    if (!time || !/^\d{2}:\d{2}$/.test(time) || !roleId) {
      await reply(message, "Gebruik `~klok rol add 09:00 @Rol`.");
      return;
    }
    guild.clockRoles.push({ time, roleId });
    await saveConfig();
    await reply(message, "Klokrol toegevoegd. De bot werkt deze automatisch bij.");
    return;
  }
  if (action === "rol" && args[0] === "remove") {
    const time = args[1];
    guild.clockRoles = guild.clockRoles.filter((entry) => entry.time !== time);
    await saveConfig();
    await reply(message, "Klokrol verwijderd.");
    return;
  }
  await reply(message, "Gebruik `~klok rol add HH:MM @Rol`, `remove HH:MM` of `list`.");
}

function interactionUserId(interaction: DiscordInteraction) {
  return interaction.member?.user?.id ?? interaction.user?.id;
}

function interactionGuildId(interaction: DiscordInteraction) {
  return interaction.guild_id;
}

async function interactionCanManageTicket(interaction: DiscordInteraction, ticket: TicketRecord) {
  if (await interactionCanAdmin(interaction)) return true;
  if (interactionUserId(interaction) === ticket.userId) return false;
  if (await interactionCanManage(interaction)) return true;
  const category = getGuildConfig(ticket.guildId).ticketCategories.find(
    (entry) => entry.id === ticket.categoryId,
  );
  const supportRoleId = category?.supportRoleId;
  return Boolean(supportRoleId && interaction.member?.roles?.includes(supportRoleId));
}

async function notifyTicketSupport(ticket: TicketRecord, message: string) {
  const category = getGuildConfig(ticket.guildId).ticketCategories.find(
    (entry) => entry.id === ticket.categoryId,
  );
  const supportRoleId = category?.supportRoleId;
  if (!supportRoleId) return;
  const notification = await sendMessage(ticket.channelId, `<@&${supportRoleId}> ${message}`, {
    allowed_mentions: { roles: [supportRoleId] },
  });
  const notificationId = String((notification as { id?: string } | null)?.id ?? "");
  if (notificationId) {
    setTimeout(() => {
      void discordRequest(`/channels/${ticket.channelId}/messages/${notificationId}`, {
        method: "DELETE",
      });
    }, 1500);
  }
}

async function interactionCanManage(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const userId = interactionUserId(interaction);
  if (!guildId || !userId) return false;
  return hasPermission(
    {
      id: interaction.id,
      channel_id: interaction.channel_id ?? "",
      guild_id: guildId,
      content: "",
      author: { id: userId, username: interaction.member?.user?.username ?? "" },
      member: interaction.member,
    },
    "manage",
  );
}

async function interactionCanAdmin(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const userId = interactionUserId(interaction);
  if (!guildId || !userId) return false;
  return hasPermission(
    {
      id: interaction.id,
      channel_id: interaction.channel_id ?? "",
      guild_id: guildId,
      content: "",
      author: { id: userId, username: interaction.member?.user?.username ?? "" },
      member: interaction.member,
    },
    "admin",
  );
}

async function administratorRoleIds(guildId: string) {
  const roles = await discordRequest<Array<{ id: string; permissions: string }>>(`/guilds/${guildId}/roles`);
  return (roles ?? [])
    .filter((role) => (BigInt(role.permissions) & 8n) === 8n)
    .map((role) => role.id);
}

async function clockInteraction(
  interaction: DiscordInteraction,
  action: string,
) {
  const guildId = interactionGuildId(interaction);
  const userId = interactionUserId(interaction);
  if (!guildId || !userId) return;
  const guild = getGuildConfig(guildId);
  const key = `${guildId}:${userId}`;
  if (action === "in") {
    if (clockSessions.has(key)) {
      await sendInteractionResponse(interaction, "⏱️ Je bent al ingeklokt! Klok uit voor je opnieuw in kunt klokken.");
      return;
    }
    let roleId = guild.clockRoles[0]?.roleId;
    if (guild.clockRoles.length > 1) {
      const embed = {
        title: "🕒 Selecteer je rol",
        description: "Wat is je huidige functie?",
        color: 0x3b82f6,
      };
      const components = [
        {
          type: 1,
          components: guild.clockRoles.slice(0, 5).map((role) => ({
            type: 2,
            style: 1,
            label: role.time.slice(0, 80),
            custom_id: `clock:in:role:${role.roleId}`,
          })),
        },
      ];
      if (guild.clockRoles.length > 5) {
        components.push({
          type: 1,
          components: [
            {
              type: 2,
              style: 2,
              label: "Meer opties",
              custom_id: "clock:in:more",
            },
          ],
        });
      }
      await sendInteractionResponse(interaction, "", true, { embeds: [embed], components });
      return;
    }
    clockSessions.set(key, { guildId, userId, startedAt: Date.now(), roleId });
    const embed = {
      title: "✅ Ingeklokt",
      description: `Je bent ingeklokt op **${new Date(Date.now()).toLocaleTimeString("nl-NL")}**`,
      color: 0x10b981,
      thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
      timestamp: new Date().toISOString(),
    };
    await sendInteractionResponse(interaction, "", true, { embeds: [embed] });
    if (guild.clockLogChannelId) {
      await sendMessage(guild.clockLogChannelId, "", {
        embeds: [
          {
            title: "✅ Ingeklokt",
            description: `<@${userId}> is ingeklokt.\n**Tijd:** <t:${Math.floor(Date.now() / 1000)}:T>`,
            color: 0x10b981,
            thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
            timestamp: new Date().toISOString(),
          },
        ],
      });
    }
    return;
  }
  if (action === "out") {
    const session = clockSessions.get(key);
    if (!session) {
      await sendInteractionResponse(interaction, "⏱️ Je bent momenteel niet ingeklokt. Klok eerst in!");
      return;
    }
    clockSessions.delete(key);
    const minutes = Math.max(1, Math.round((Date.now() - session.startedAt) / 60000));
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    const durationStr = hours > 0 ? `${hours}u ${mins}m` : `${mins}m`;
    const embed = {
      title: "👋 Uitgeklokt",
      description: `Dienst duurde **${durationStr}** (${minutes} minuten)`,
      color: 0xf59e0b,
      fields: [
        { name: "In-tijd", value: `<t:${Math.floor(session.startedAt / 1000)}:T>`, inline: true },
        { name: "Uit-tijd", value: `<t:${Math.floor(Date.now() / 1000)}:T>`, inline: true },
      ],
      thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
      timestamp: new Date().toISOString(),
    };
    await sendInteractionResponse(interaction, "", true, { embeds: [embed] });
    if (guild.clockLogChannelId) {
      await sendMessage(guild.clockLogChannelId, "", {
        embeds: [
          {
            title: "👋 Uitgeklokt",
            description: `<@${userId}> is uitgeklokt na **${durationStr}**.\n**Uit-tijd:** <t:${Math.floor(Date.now() / 1000)}:T>`,
            color: 0xf59e0b,
            thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
            timestamp: new Date().toISOString(),
          },
        ],
      });
    }
  }
}

async function updateClockPanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
    return;
  }
  const values = modalValues(interaction);
  const guild = getGuildConfig(guildId);
  const panel = guild.clockPanel;
  if (values.clock_title) panel.title = values.clock_title.slice(0, 256);
  if (values.clock_description) panel.description = values.clock_description.slice(0, 4000);
  if (values.clock_banner !== undefined) panel.bannerUrl = values.clock_banner.trim().slice(0, 1000);
  if (values.clock_thumbnail !== undefined)
    panel.thumbnailUrl = values.clock_thumbnail.trim().slice(0, 1000);
  if (values.clock_labels) {
    const [inLabel, outLabel] = values.clock_labels.split("|").map((value) => value.trim());
    if (inLabel) panel.inButtonLabel = inLabel.slice(0, 80);
    if (outLabel) panel.outButtonLabel = outLabel.slice(0, 80);
  }
  await saveConfig();
  await sendInteractionResponse(interaction, "Klokpanel opgeslagen. Plaats het met de knop in het beheerpanel.");
}

async function getClockStats(guildId: string, userId: string): Promise<{ totalToday: number; totalWeek: number; sessions: Array<{ in: number; out: number }> }> {
  const key = `${guildId}:${userId}`;
  const sessions = [...clockSessions.entries()]
    .filter(([sessionKey]) => sessionKey.startsWith(`${guildId}:`))
    .map(([, session]) => ({
      in: session.startedAt,
      out: session.startedAt,
    }));
  const today = sessions.filter((s) => {
    const inDate = new Date(s.in);
    const now = new Date();
    return inDate.toDateString() === now.toDateString();
  });
  const week = sessions.filter((s) => {
    const inDate = new Date(s.in);
    const now = new Date();
    const daysAgo = (now.getTime() - inDate.getTime()) / (1000 * 60 * 60 * 24);
    return daysAgo < 7;
  });
  const totalToday = today.reduce((sum, s) => sum + (s.out - s.in), 0) / (1000 * 60);
  const totalWeek = week.reduce((sum, s) => sum + (s.out - s.in), 0) / (1000 * 60);
  return {
    totalToday: Math.round(totalToday),
    totalWeek: Math.round(totalWeek),
    sessions,
  };
}

async function showClockStats(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const userId = interactionUserId(interaction);
  if (!guildId || !userId) return;
  const stats = await getClockStats(guildId, userId);
  const embed = {
    title: "📊 Mijn Urenregistratie",
    description: `Persoonlijke statistieken voor <@${userId}>`,
    fields: [
      { name: "🕐 Vandaag", value: `**${stats.totalToday}** minuten`, inline: true },
      { name: "📅 Deze week", value: `**${stats.totalWeek}** minuten`, inline: true },
      { name: "Sessions", value: `**${stats.sessions.length}** shift${stats.sessions.length === 1 ? "" : "s"}`, inline: true },
    ],
    color: 0x3b82f6,
    thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
    timestamp: new Date().toISOString(),
  };
  await sendInteractionResponse(interaction, "", true, { embeds: [embed] });
}

async function updateCountingPanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
    return;
  }
  const values = modalValues(interaction);
  const panel = getGuildConfig(guildId).countingPanel;
  if (values.counting_title) panel.title = values.counting_title.slice(0, 256);
  if (values.counting_description) panel.description = values.counting_description.slice(0, 4000);
  if (values.counting_banner !== undefined) panel.bannerUrl = values.counting_banner.trim().slice(0, 1000);
  if (values.counting_thumbnail !== undefined) panel.thumbnailUrl = values.counting_thumbnail.trim().slice(0, 1000);
  if (values.counting_success_text) panel.correctText = values.counting_success_text.slice(0, 4000);
  if (values.counting_incorrect_text) panel.incorrectText = values.counting_incorrect_text.slice(0, 4000);
  if (values.counting_next_text) panel.nextText = values.counting_next_text.slice(0, 4000);
  if (values.counting_success_emoji) panel.successEmoji = values.counting_success_emoji.slice(0, 10);
  if (values.counting_incorrect_emoji) panel.incorrectEmoji = values.counting_incorrect_emoji.slice(0, 10);
  await saveConfig();
  await sendInteractionResponse(interaction, "Tellenpanel opgeslagen.");
}

async function updateGuessPanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
    return;
  }
  const values = modalValues(interaction);
  const guild = getGuildConfig(guildId);
  const panel = guild.guessPanel;
  if (values.guess_title) panel.title = values.guess_title.slice(0, 256);
  if (values.guess_description) panel.description = values.guess_description.slice(0, 4000);
  if (values.guess_banner !== undefined) panel.bannerUrl = values.guess_banner.trim().slice(0, 1000);
  if (values.guess_thumbnail !== undefined) panel.thumbnailUrl = values.guess_thumbnail.trim().slice(0, 1000);
  if (values.guess_higher_text) panel.higherText = values.guess_higher_text.slice(0, 4000);
  if (values.guess_lower_text) panel.lowerText = values.guess_lower_text.slice(0, 4000);
  if (values.guess_winner_text) panel.winnerText = values.guess_winner_text.slice(0, 4000);
  if (values.guess_start_label) panel.startButtonLabel = values.guess_start_label.slice(0, 80);
  if (values.guess_min !== undefined || values.guess_max !== undefined) {
    const min = Number.parseInt(values.guess_min ?? String(panel.minNumber), 10);
    const max = Number.parseInt(values.guess_max ?? String(panel.maxNumber), 10);
    if (!Number.isInteger(min) || !Number.isInteger(max) || min < 1 || max < min) {
      await sendInteractionResponse(interaction, "Gebruik een geldig bereik, bijv. 1 en 100.");
      return;
    }
    panel.minNumber = min;
    panel.maxNumber = max;
  }
  if (values.guess_channel !== undefined) {
    const channelId = values.guess_channel.trim() ? channelIdFromArg(values.guess_channel.trim()) ?? interaction.channel_id : interaction.channel_id;
    if (channelId) guild.guessChannelId = channelId;
  }
  await saveConfig();
  await sendInteractionResponse(interaction, "Raad-het-getal-panel opgeslagen.");
}

async function updateTicketPanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
    return;
  }
  const values = modalValues(interaction);
  const guild = getGuildConfig(guildId);
  const panel = guild.ticketPanel;
  if (values.ticket_panel_title) panel.title = values.ticket_panel_title.slice(0, 256);
  if (values.ticket_panel_description) panel.description = values.ticket_panel_description.slice(0, 4000);
  if (values.ticket_panel_button) panel.buttonLabel = values.ticket_panel_button.slice(0, 80);
  if (values.ticket_panel_banner !== undefined) panel.bannerUrl = values.ticket_panel_banner.trim().slice(0, 1000);
  if (values.ticket_panel_thumbnail !== undefined) panel.thumbnailUrl = values.ticket_panel_thumbnail.trim().slice(0, 1000);
  if (values.ticket_panel_order) {
    panel.buttonOrder = panelButtonOrder(values.ticket_panel_order, ["categories", "edit", "settings", "rows"]);
  }
  if (values.ticket_channel_prefix !== undefined) {
    guild.ticketChannelPrefix = channelNamePart(values.ticket_channel_prefix, "ticket");
  }
  if (values.ticket_closed_category_id !== undefined) {
    const closedCategoryId = channelIdFromArg(values.ticket_closed_category_id.trim());
    if (closedCategoryId) {
      const closedCategory = await discordRequest<{ id?: string; type?: number }>(`/channels/${closedCategoryId}`);
      if (!closedCategory?.id || closedCategory.type !== 4) {
        await sendInteractionResponse(interaction, "De gesloten categorie-ID is geen geldige Discord-categorie.");
        return;
      }
      guild.closedTicketCategoryId = closedCategoryId;
    }
  }
  if (values.ticket_panel_rows) {
    panel.layoutRows = parsePanelLayout(values.ticket_panel_rows, defaultConfig().ticketPanel.layoutRows ?? []);
  }
  await saveConfig();
  await refreshConfiguredPanel(getGuildConfig(guildId), "ticket");
  await sendInteractionResponse(interaction, "Ticketpanel opgeslagen.");
}

async function updateApplicationPanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
    return;
  }
  const values = modalValues(interaction);
  const panel = getGuildConfig(guildId).applicationPanel;
  if (values.application_panel_title) panel.title = values.application_panel_title.slice(0, 256);
  if (values.application_panel_description) panel.description = values.application_panel_description.slice(0, 4000);
  if (values.application_panel_button) panel.buttonLabel = values.application_panel_button.slice(0, 80);
  if (values.application_panel_banner !== undefined) panel.bannerUrl = values.application_panel_banner.trim().slice(0, 1000);
  if (values.application_panel_thumbnail !== undefined) panel.thumbnailUrl = values.application_panel_thumbnail.trim().slice(0, 1000);
  if (values.application_panel_order) {
    panel.buttonOrder = panelButtonOrder(values.application_panel_order, ["start", "edit", "questions", "settings", "rows"]);
  }
  if (values.application_panel_rows) {
    panel.layoutRows = parsePanelLayout(values.application_panel_rows, defaultConfig().applicationPanel.layoutRows ?? []);
  }
  await saveConfig();
  await refreshConfiguredPanel(getGuildConfig(guildId), "application");
  await sendInteractionResponse(interaction, "Sollicitatiepanel opgeslagen.");
}

async function updateTicketRowsPanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen ticketrijen beheren.");
    return;
  }
  const guild = getGuildConfig(guildId);
  updatePanelRows(guild.ticketPanel, modalValues(interaction), "ticket", defaultConfig().ticketPanel.layoutRows ?? []);
  await saveConfig();
  await refreshConfiguredPanel(guild, "ticket");
  await sendInteractionResponse(interaction, "Ticketrijen opgeslagen. Plaats het panel opnieuw om de wijzigingen te zien.");
}

async function updateApplicationRowsPanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen sollicitatierijen beheren.");
    return;
  }
  const guild = getGuildConfig(guildId);
  updatePanelRows(guild.applicationPanel, modalValues(interaction), "application", defaultConfig().applicationPanel.layoutRows ?? []);
  await saveConfig();
  await refreshConfiguredPanel(guild, "application");
  await sendInteractionResponse(interaction, "Sollicitatierijen opgeslagen. Plaats het panel opnieuw om de wijzigingen te zien.");
}

async function createTicketCategoryFromModal(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen categorieën toevoegen.");
    return;
  }
  const values = modalValues(interaction);
  const name = values.ticket_category_name?.trim().slice(0, 100);
  const type = values.ticket_category_type?.trim().slice(0, 40) || "ticket";
  const supportRoleId = roleIdFromArg(values.ticket_category_role ?? "");
  const emoji = parseButtonEmoji(values.ticket_category_emoji ?? "");
  const existingId = channelIdFromArg(values.ticket_category_id ?? "");
  if (existingId) {
    const existing = await discordRequest<{ id?: string; name?: string; type?: number }>(`/channels/${existingId}`);
    if (!existing?.id || existing.type !== 4) {
      await sendInteractionResponse(interaction, "Dit ID is geen geldige Discord-categorie.");
      return;
    }
    const guild = getGuildConfig(guildId);
    const category = guild.ticketCategories.find((entry) => entry.id === existing.id)
      ?? {
        id: existing.id,
        name: existing.name ?? name ?? "Categorie",
        type,
        supportRoleId,
        emoji,
        subjectEnabled: true,
        descriptionEnabled: true,
      };
    if (!guild.ticketCategories.some((entry) => entry.id === existing.id)) guild.ticketCategories.push(category);
    addTicketCategoryRow(guild, category);
    await saveConfig();
    await refreshConfiguredPanel(guild, "ticket");
    await sendInteractionResponse(interaction, `Bestaande categorie **${existing.name ?? existing.id}** is toegevoegd aan ticketbeheer.`);
    return;
  }
  if (!name) {
    await sendInteractionResponse(interaction, "Geef een categorienaam op.");
    return;
  }
  const created = await discordRequest<{ id: string }>(`/guilds/${guildId}/channels`, {
    method: "POST",
    body: JSON.stringify({ name, type: 4 }),
  });
  if (!created?.id) {
    await sendInteractionResponse(interaction, "De Discord-categorie kon niet worden aangemaakt.");
    return;
  }
  const guild = getGuildConfig(guildId);
  const category = {
    id: created.id,
    name,
    type,
    supportRoleId,
    emoji,
    subjectEnabled: true,
    descriptionEnabled: true,
  };
  guild.ticketCategories.push(category);
  addTicketCategoryRow(guild, category);
  await saveConfig();
  await refreshConfiguredPanel(guild, "ticket");
  await sendInteractionResponse(interaction, `Categorie **${name}** toegevoegd als ${type}.`);
}

async function updateTicketCategoryFromModal(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const customId = interaction.data?.custom_id ?? "";
  const categoryId = customId.split(":")[3];
  if (!guildId || !categoryId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen categorieën bewerken.");
    return;
  }
  const guild = getGuildConfig(guildId);
  const category = ticketCategoriesForGuild(guild).find((entry) => entry.id === categoryId);
  const values = modalValues(interaction);
  const name = values.ticket_category_name?.trim().slice(0, 100);
  const description = values.ticket_category_description?.trim().slice(0, 300);
  const buttonLabel = values.ticket_category_button?.trim().slice(0, 80);
  const emoji = parseButtonEmoji(values.ticket_category_emoji ?? "");
  if (!category || !name) {
    await sendInteractionResponse(interaction, "Geef een geldige categorienaam op.");
    return;
  }
  const updated = await discordRequest(`/channels/${categoryId}`, {
    method: "PATCH",
    body: JSON.stringify({ name }),
  });
  if (updated === null) {
    await sendInteractionResponse(interaction, "De Discord-categorie kon niet worden bijgewerkt.");
    return;
  }
  category.name = name;
  category.supportRoleId = roleIdFromArg(values.ticket_category_role ?? "");
  category.emoji = emoji;
  const row = guild.ticketPanel.layoutRows?.find((entry) => entry.categoryId === categoryId);
  if (row) {
    row.title = name;
    row.description = description || row.description;
    row.buttonLabel = buttonLabel || name.slice(0, 80);
    row.emoji = emoji;
  }
  await saveConfig();
  await refreshConfiguredPanel(guild, "ticket");
  await sendInteractionResponse(interaction, `Categorie hernoemd naar **${name}**.`);
}

async function updateTicketCategoryFormSettings(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const categoryId = (interaction.data?.custom_id ?? "").split(":")[3];
  if (!guildId || !categoryId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen ticketvragen beheren.");
    return;
  }
  const category = getGuildConfig(guildId).ticketCategories.find((entry) => entry.id === categoryId);
  const values = modalValues(interaction);
  if (!category) {
    await sendInteractionResponse(interaction, "Deze categorie bestaat niet meer.");
    return;
  }
  if (category.protected) {
    await sendInteractionResponse(interaction, "De vragen van de ingebouwde unban-categorie staan vast.");
    return;
  }
  category.subjectLabel = values.ticket_subject_label?.trim().slice(0, 45) || "Onderwerp";
  category.descriptionLabel = values.ticket_description_label?.trim().slice(0, 45) || "Uitleg";
  category.subjectEnabled = (values.ticket_subject_enabled ?? "aan").trim().toLowerCase() !== "uit";
  category.descriptionEnabled = (values.ticket_description_enabled ?? "aan").trim().toLowerCase() !== "uit";
  if (!category.subjectEnabled && !category.descriptionEnabled) {
    await sendInteractionResponse(interaction, "Zet minstens één ticketvraag op aan.");
    return;
  }
  await saveConfig();
  await sendInteractionResponse(interaction, "Ticketvragen opgeslagen.");
}

async function deleteTicketCategoryFromModal(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const customId = interaction.data?.custom_id ?? "";
  const categoryId = customId.split(":")[3];
  if (!guildId || !categoryId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen categorieën verwijderen.");
    return;
  }
  if (modalValues(interaction).ticket_category_confirm?.trim().toUpperCase() !== "VERWIJDER") {
    await sendInteractionResponse(interaction, "Typ VERWIJDER om deze categorie te bevestigen.");
    return;
  }
  const guild = getGuildConfig(guildId);
  const category = ticketCategoriesForGuild(guild).find((entry) => entry.id === categoryId);
  if (!category) {
    await sendInteractionResponse(interaction, "Categorie niet gevonden.");
    return;
  }
  if (category.protected) {
    await sendInteractionResponse(interaction, "De ingebouwde unban-categorie kan niet worden verwijderd.");
    return;
  }
  const deleted = await discordRequest(`/channels/${categoryId}`, { method: "DELETE" });
  if (deleted === null) {
    await sendInteractionResponse(interaction, "Discord kon deze categorie niet verwijderen. Controleer mijn Manage Channels-permissie.");
    return;
  }
  guild.ticketCategories = guild.ticketCategories.filter((entry) => entry.id !== categoryId);
  guild.ticketPanel.layoutRows = (guild.ticketPanel.layoutRows ?? []).filter((row) => row.categoryId !== categoryId);
  guild.ticketPanel.buttonOrder = (guild.ticketPanel.buttonOrder ?? []).filter((id) => id !== `category_${categoryId}`);
  await saveConfig();
  await refreshConfiguredPanel(guild, "ticket");
  await sendInteractionResponse(interaction, `Categorie **${category.name}** verwijderd.`);
}

async function updateWelcomePanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
    return;
  }
  const values = modalValues(interaction);
  const guild = getGuildConfig(guildId);
  if (values.welcome_message !== undefined) {
    guild.welcomeMessage = values.welcome_message.slice(0, 1000);
    guild.welcomeDescription = guild.welcomeMessage;
  }
  if (values.welcome_title !== undefined) guild.welcomeTitle = values.welcome_title.slice(0, 256);
  if (values.welcome_description !== undefined) guild.welcomeDescription = values.welcome_description.slice(0, 2000);
  if (values.welcome_channel) guild.welcomeChannelId = channelIdFromArg(values.welcome_channel.trim());
  if (values.welcome_role) {
    const roleId = await resolveRoleId(guildId, values.welcome_role.trim());
    if (!roleId) {
      await sendInteractionResponse(interaction, "Die rol kon niet worden gevonden. Gebruik een rolmention, ID of exacte rolnaam.");
      return;
    }
    guild.welcomeRoleId = roleId;
  }
  await saveConfig();
  await sendInteractionResponse(interaction, "Welkominstellingen opgeslagen.");
}

async function updateWelcomeSettings(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen welkominstellingen beheren.");
    return;
  }
  const values = modalValues(interaction);
  const guild = getGuildConfig(guildId);
  if (values.welcome_banner !== undefined) guild.welcomeBannerUrl = values.welcome_banner.trim().slice(0, 1000);
  if (values.welcome_thumbnail !== undefined) guild.welcomeThumbnailUrl = values.welcome_thumbnail.trim().slice(0, 1000);
  if (values.welcome_color) {
    const color = colorValue(values.welcome_color.trim());
    if (color === undefined) {
      await sendInteractionResponse(interaction, "Gebruik een hexkleur zoals `#2dd4bf`.");
      return;
    }
    guild.welcomeColor = color;
  }
  await saveConfig();
  await sendInteractionResponse(interaction, "Welkommedia en kleur opgeslagen.");
}

async function updateLevelXpSettings(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen levelinstellingen beheren.");
    return;
  }
  const values = modalValues(interaction);
  const cooldownSeconds = Number.parseInt(values.level_cooldown ?? "", 10);
  const minimumXp = Number.parseInt(values.level_minimum ?? "", 10);
  const maximumXp = Number.parseInt(values.level_maximum ?? "", 10);
  if (!Number.isInteger(cooldownSeconds) || cooldownSeconds < 1 || cooldownSeconds > 86_400
    || !Number.isInteger(minimumXp) || minimumXp < 1 || minimumXp > 1000
    || !Number.isInteger(maximumXp) || maximumXp < minimumXp || maximumXp > 2000) {
    await sendInteractionResponse(interaction, "Gebruik cooldown 1-86400, minimum XP 1-1000 en maximum XP groter dan minimum tot 2000.");
    return;
  }
  const guild = getGuildConfig(guildId);
  guild.leveling.cooldownSeconds = cooldownSeconds;
  guild.leveling.minimumXp = minimumXp;
  guild.leveling.maximumXp = maximumXp;
  await saveConfig();
  await sendInteractionResponse(interaction, "XP- en cooldowninstellingen opgeslagen.", true, levelSettingsPayload(guild));
}

async function updateLevelAnnouncementSettings(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen levelmeldingen beheren.");
    return;
  }
  const values = modalValues(interaction);
  const guild = getGuildConfig(guildId);
  guild.leveling.announceLevelUps = (values.level_announce ?? "aan").trim().toLowerCase() !== "uit";
  guild.leveling.announceChannelId = values.level_channel?.trim() ? channelIdFromArg(values.level_channel.trim()) : undefined;
  if (values.level_message?.trim()) guild.leveling.announceMessage = values.level_message.trim().slice(0, 1000);
  await saveConfig();
  await sendInteractionResponse(interaction, "Level-upmeldingen opgeslagen.", true, levelSettingsPayload(guild));
}

async function updateLevelRoleSettings(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen levelrollen beheren.");
    return;
  }
  const guild = getGuildConfig(guildId);
  const raw = modalValues(interaction).level_roles ?? "";
  const parsed = raw
    .split(";")
    .map((entry) => entry.trim())
    .filter(Boolean)
    .map((entry) => {
      const [levelText, roleText] = entry.split("|").map((part) => part.trim());
      const level = Number.parseInt(levelText ?? "", 10);
      const roleId = roleIdFromArg(roleText ?? "") ?? roleIdFromArg(levelText ?? "");
      if (!Number.isInteger(level) || level < 1 || !roleId) return undefined;
      return { level, roleId } satisfies LevelRoleAssignment;
    })
    .filter((entry): entry is LevelRoleAssignment => Boolean(entry));
  guild.levelRoles = parsed;
  await saveConfig();
  await sendInteractionResponse(interaction, "Levelrollen opgeslagen.", true, levelSettingsPayload(guild));
}

async function updateRoleDirectoryPanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen de rollenlijst beheren.");
    return;
  }
  const values = modalValues(interaction);
  const guild = getGuildConfig(guildId);
  if (values.rolelist_title) guild.roleDirectoryTitle = values.rolelist_title.trim().slice(0, 256);
  if (values.rolelist_description !== undefined) guild.roleDirectoryDescription = values.rolelist_description.trim().slice(0, 1000);
  if (values.rolelist_update_text) guild.roleDirectoryUpdateText = values.rolelist_update_text.trim().slice(0, 100);
  await saveConfig();
  await refreshRoleDirectoryPanel(guildId);
  await sendInteractionResponse(interaction, "Rollenlijstteksten opgeslagen.", true, await roleDirectoryPayload(guildId, guild, 0, true));
}

function applicationQuestionsPayload(guild: GuildConfig, page: number) {
  const pageSize = 5;
  const pageCount = Math.max(1, Math.ceil(guild.applicationQuestions.length / pageSize));
  const currentPage = Math.min(Math.max(page, 0), pageCount - 1);
  const start = currentPage * pageSize;
  const questions = guild.applicationQuestions.slice(start, start + pageSize);
  const questionRows = questions.map((question, offset) => {
    const index = start + offset;
    return {
      type: 1,
      components: [
        { type: 2, style: 1, label: `Bewerk ${index + 1}`, custom_id: `application:question:edit:${index}` },
        { type: 2, style: 4, label: `Verwijder ${index + 1}`, custom_id: `application:question:delete:${index}` },
      ],
    };
  });
  return {
    embeds: [panelEmbed({
      title: `Sollicitatievragen (${currentPage + 1}/${pageCount})`,
      description: questions.length
        ? questions.map((question, offset) => `**${start + offset + 1}.** ${question}`).join("\n\n")
        : "Er zijn nog geen vragen ingesteld.",
      color: GREY_EMBED_COLOR,
      buttonLabel: "",
    }, "Beheer • Sollicitatievragen")],
    components: [
      ...questionRows,
      {
        type: 1,
        components: [
          { type: 2, style: 3, label: "Vraag toevoegen", custom_id: "application:question:add" },
          ...(currentPage > 0
            ? [{ type: 2, style: 2, label: "Vorige", custom_id: `application:questions:page:${currentPage - 1}` }]
            : []),
          ...(currentPage < pageCount - 1
            ? [{ type: 2, style: 2, label: "Volgende", custom_id: `application:questions:page:${currentPage + 1}` }]
            : []),
          { type: 2, style: 1, label: "Terug", custom_id: "nav:application" },
        ],
      },
    ],
  };
}

async function showApplicationQuestions(interaction: DiscordInteraction, page = 0) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen vragen beheren.");
    return;
  }
  await sendInteractionResponse(interaction, "", true, applicationQuestionsPayload(getGuildConfig(guildId), page));
}

async function saveApplicationQuestionFromModal(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen vragen beheren.");
    return;
  }
  const customId = interaction.data?.custom_id ?? "";
  const values = modalValues(interaction);
  const question = values.application_question?.trim().slice(0, 500);
  const guild = getGuildConfig(guildId);
  if (!question) {
    await sendInteractionResponse(interaction, "Vul een vraag in.");
    return;
  }
  if (customId === "application:question:add") {
    if (guild.applicationQuestions.length >= 20) {
      await sendInteractionResponse(interaction, "Je kunt maximaal 20 vragen instellen.");
      return;
    }
    guild.applicationQuestions.push(question);
  } else {
    const index = Number.parseInt(customId.split(":")[3] ?? "", 10);
    if (!Number.isInteger(index) || index < 0 || index >= guild.applicationQuestions.length) {
      await sendInteractionResponse(interaction, "Deze vraag bestaat niet meer.");
      return;
    }
    guild.applicationQuestions[index] = question;
  }
  await saveConfig();
  await sendInteractionResponse(interaction, "Vraag opgeslagen.", true, applicationQuestionsPayload(guild, 0));
}

async function deleteApplicationQuestion(interaction: DiscordInteraction, index: number) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen vragen beheren.");
    return;
  }
  const guild = getGuildConfig(guildId);
  if (index < 0 || index >= guild.applicationQuestions.length) {
    await sendInteractionResponse(interaction, "Deze vraag bestaat niet meer.");
    return;
  }
  guild.applicationQuestions.splice(index, 1);
  await saveConfig();
  await sendInteractionResponse(interaction, "Vraag verwijderd.", true, applicationQuestionsPayload(guild, Math.floor(index / 5)));
}

function parseDuration(input: string) {
  const match = input.trim().toLowerCase().match(/^(\d+)\s*(m|min|h|uur|d|dag|w|week)$/);
  if (!match) return undefined;
  const amount = Number.parseInt(match[1], 10);
  const unit = match[2];
  const multiplier =
    unit === "m" || unit === "min"
      ? 60_000
      : unit === "h" || unit === "uur"
        ? 3_600_000
        : unit === "d" || unit === "dag"
          ? 86_400_000
          : 604_800_000;
  return amount > 0 ? amount * multiplier : undefined;
}

function shortId() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

async function deliverReminder(reminder: ReminderRecord) {
  if (!reminders.has(reminder.id)) return;
  await sendMessage(reminder.channelId, `<@${reminder.userId}> herinnering: **${reminder.text}**`, {
    allowed_mentions: { users: [reminder.userId] },
  });
  reminders.delete(reminder.id);
  reminderTimers.delete(reminder.id);
  await saveConfig();
}

function scheduleReminder(reminder: ReminderRecord) {
  const existing = reminderTimers.get(reminder.id);
  if (existing) clearTimeout(existing);
  const wait = reminder.dueAt - Date.now();
  if (wait <= 0) {
    void deliverReminder(reminder);
    return;
  }
  reminderTimers.set(reminder.id, setTimeout(() => scheduleReminder(reminder), Math.min(wait, 2_147_000_000)));
}

async function handleReminderCommand(message: DiscordMessage, args: string[]) {
  const action = args[0]?.toLowerCase();
  if (action === "list") {
    const own = [...reminders.values()].filter((reminder) => reminder.userId === message.author?.id);
    await reply(message, own.length
      ? own.map((reminder) => `\`${reminder.id}\` • <t:${Math.floor(reminder.dueAt / 1000)}:R> • ${reminder.text}`).join("\n")
      : "Je hebt geen actieve herinneringen.");
    return;
  }
  if (action === "cancel") {
    const reminder = reminders.get(args[1] ?? "");
    if (!reminder || reminder.userId !== message.author?.id) {
      await reply(message, "Die herinnering bestaat niet of is niet van jou.");
      return;
    }
    const timer = reminderTimers.get(reminder.id);
    if (timer) clearTimeout(timer);
    reminderTimers.delete(reminder.id);
    reminders.delete(reminder.id);
    await saveConfig();
    await reply(message, "Herinnering geannuleerd.");
    return;
  }
  const duration = parseDuration(args[0] ?? "");
  const text = args.slice(1).join(" ").trim();
  if (!duration || !text || duration > 30 * 86_400_000) {
    await reply(message, "Gebruik `~remind 30m tekst`, `~remind list` of `~remind cancel ID` (maximaal 30 dagen).");
    return;
  }
  const reminder: ReminderRecord = {
    id: shortId(),
    userId: message.author?.id ?? "",
    channelId: message.channel_id,
    guildId: message.guild_id,
    text: text.slice(0, 500),
    dueAt: Date.now() + duration,
  };
  reminders.set(reminder.id, reminder);
  await saveConfig();
  scheduleReminder(reminder);
  await reply(message, `Herinnering ingesteld voor <t:${Math.floor(reminder.dueAt / 1000)}:R>. ID: \`${reminder.id}\``);
}

function pollPayload(poll: PollRecord) {
  const counts = poll.options.map((option, index) => `${index + 1}. ${option} — **${poll.votes[index] ?? 0}**`).join("\n");
  return {
    embeds: [{
      title: poll.question,
      description: `${counts}\n\n${poll.closed ? "Deze poll is gesloten." : "Kies één antwoord hieronder."}`,
      color: GREY_EMBED_COLOR,
      thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
    }],
    components: [{
      type: 1,
      components: poll.options.map((option, index) => ({
        type: 2,
        style: 1,
        label: `${index + 1}. ${option}`.slice(0, 80),
        custom_id: `poll:vote:${poll.id}:${index}`,
        disabled: poll.closed,
      })),
    }],
  };
}

async function handlePollCommand(message: DiscordMessage, args: string[]) {
  if (args[0]?.toLowerCase() === "close") {
    const poll = polls.get(args[1] ?? "");
    if (!poll || !(await hasPermission(message, "manage"))) {
      await reply(message, "Poll niet gevonden of je hebt geen beheerpermissie.");
      return;
    }
    poll.closed = true;
    await saveConfig();
    if (poll.messageId) await discordRequest(`/channels/${poll.channelId}/messages/${poll.messageId}`, { method: "PATCH", body: JSON.stringify(pollPayload(poll)) });
    await reply(message, "Poll gesloten.");
    return;
  }
  const parts = args.join(" ").split("|").map((part) => part.trim()).filter(Boolean);
  const question = parts.shift();
  if (!question || parts.length < 2 || parts.length > 5) {
    await reply(message, "Gebruik `~poll Vraag | Optie 1 | Optie 2` (2 tot 5 opties) of `~poll close ID`.");
    return;
  }
  const poll: PollRecord = {
    id: shortId(),
    question: question.slice(0, 256),
    options: parts.map((option) => option.slice(0, 70)),
    votes: {},
    voters: {},
    channelId: message.channel_id,
    guildId: message.guild_id,
    closed: false,
  };
  polls.set(poll.id, poll);
  const created = await sendMessage(message.channel_id, "", pollPayload(poll));
  poll.messageId = String((created as { id?: string } | null)?.id ?? "");
  await saveConfig();
  await reply(message, `Poll aangemaakt. Beheer-ID: \`${poll.id}\``);
}

async function votePoll(interaction: DiscordInteraction, pollId: string, optionIndex: number) {
  const poll = polls.get(pollId);
  const userId = interactionUserId(interaction);
  if (!poll || poll.closed || !userId || optionIndex < 0 || optionIndex >= poll.options.length) {
    await sendInteractionResponse(interaction, "Deze poll is niet beschikbaar.");
    return;
  }
  if (poll.voters[userId] !== undefined) {
    await sendInteractionResponse(interaction, "Je hebt al gestemd in deze poll.");
    return;
  }
  poll.voters[userId] = optionIndex;
  poll.votes[optionIndex] = (poll.votes[optionIndex] ?? 0) + 1;
  await saveConfig();
  if (poll.messageId) await discordRequest(`/channels/${poll.channelId}/messages/${poll.messageId}`, { method: "PATCH", body: JSON.stringify(pollPayload(poll)) });
  await sendInteractionResponse(interaction, `Stem opgeslagen: **${poll.options[optionIndex]}**.`);
}

async function handleInfoCommand(message: DiscordMessage, name: string, args: string[]) {
  if (name === "serverinfo") {
    if (!message.guild_id) return;
    const guild = await discordRequest<{ name?: string; id?: string; member_count?: number; owner_id?: string; description?: string }>(`/guilds/${message.guild_id}?with_counts=true`);
    await reply(message, `**${guild?.name ?? "Server"}**\nID: \`${guild?.id ?? message.guild_id}\`\nLeden: **${guild?.member_count ?? "onbekend"}**\nEigenaar: <@${guild?.owner_id ?? "onbekend"}>${guild?.description ? `\n${guild.description}` : ""}`);
    return;
  }
  const targetId = await resolveTargetUserId(message.guild_id ?? "", args[0] ?? "") || message.author?.id;
  if (!targetId || !message.guild_id) return;
  const member = await discordRequest<{ user?: { id?: string; username?: string; global_name?: string; avatar?: string }; nick?: string; joined_at?: string; roles?: string[] }>(`/guilds/${message.guild_id}/members/${targetId}`);
  if (!member?.user) {
    await reply(message, "Lid niet gevonden.");
    return;
  }
  await reply(message, `**${member.user.global_name ?? member.user.username ?? targetId}**${member.nick ? ` (${member.nick})` : ""}\nGebruikersnaam: \`${member.user.username ?? "onbekend"}\`\nID: \`${targetId}\`\nLid sinds: ${member.joined_at ? `<t:${Math.floor(new Date(member.joined_at).getTime() / 1000)}:D>` : "onbekend"}\nRollen: **${member.roles?.length ?? 0}**`);
}

function formatDuration(ms: number) {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (days > 0) return `${days}d ${hours}h ${minutes}m`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  if (minutes > 0) return `${minutes}m ${seconds}s`;
  return `${seconds}s`;
}

function averageClaimTime() {
  const claims = [...tickets.values()].filter((ticket) => ticket.claimedAt && ticket.createdAt);
  if (!claims.length) return null;
  const averageMs = claims.reduce((sum, ticket) => sum + (ticket.claimedAt! - new Date(ticket.createdAt).getTime()), 0) / claims.length;
  return formatDuration(averageMs);
}

function giveawayMessagePayload(giveaway: GiveawayRecord, guild: GuildConfig) {
  const panel = guild.giveawayPanel;
  const entrantsList = giveaway.entrants.length
    ? giveaway.entrants.slice(0, 15).map((userId) => `<@${userId}>`).join(", ")
    : "Nog niemand heeft meegedaan.";
  const participantLabel = giveaway.entrants.length === 1 ? "persoon" : "personen";
  const timeLeft = giveaway.endsAt - Date.now();
  const isActive = !giveaway.ended && timeLeft > 0;
  const endTimestamp = Math.floor(giveaway.endsAt / 1000);
  const description = [
    giveaway.description?.trim(),
    isActive
      ? "Klik op **Meedoen** om kans te maken. De winnaar(s) verschijnen hier na afloop."
      : giveaway.ended
        ? "Deze giveaway is gesloten. Bekijk hierboven de uitslag."
        : "De inschrijving is gesloten; de uitslag wordt verwerkt.",
    giveaway.entrants.length
      ? `**Deelnemers:** ${entrantsList}${giveaway.entrants.length > 15 ? `\n... en ${giveaway.entrants.length - 15} anderen` : ""}`
      : "**Deelnemers:** Nog niemand heeft meegedaan.",
  ].filter(Boolean).join("\n\n");
  const fields = [
    { name: "🎁 Prijs", value: giveaway.prize, inline: true },
    { name: "🏆 Winnaars", value: String(giveaway.winners), inline: true },
    { name: "⏱️ Eindigt", value: `<t:${endTimestamp}:R>`, inline: true },
    { name: "👥 Deelnemers", value: `**${giveaway.entrants.length}** ${participantLabel}`, inline: true },
  ];
  if (giveaway.requirements?.minRole) {
    fields.push({ name: "✅ Vereiste Rol", value: `<@&${giveaway.requirements.minRole}>`, inline: true });
  }
  if (giveaway.requirements?.maxPerUser) {
    fields.push({ name: "📋 Max per persoon", value: String(giveaway.requirements.maxPerUser), inline: true });
  }
  if (giveaway.ended && giveaway.winnerIds?.length) {
    fields.push({ 
      name: "🎉 Winnaars", 
      value: giveaway.winnerIds.map((id) => `<@${id}>`).join(", "), 
      inline: false 
    });
  }
  const embed = {
    title: `🎊 ${panel.title}`,
    description,
    color: isActive ? 0x3b82f6 : 0x8b5cf6,
    fields,
    footer: {
      text: giveaway.ended
        ? `Gesloten • geëindigd <t:${endTimestamp}:R>`
        : `Eindigt <t:${endTimestamp}:R>`,
    },
    ...(giveaway.image || panel.bannerUrl || guild.ticketPanel.bannerUrl ? { image: { url: giveaway.image || panel.bannerUrl || guild.ticketPanel.bannerUrl } } : {}),
    thumbnail: { url: panel.thumbnailUrl || guild.ticketPanel.thumbnailUrl || DEFAULT_PANEL_THUMBNAIL },
  };
  return {
    embeds: [embed],
    accent_color: embed.color,
    components: giveaway.ended
      ? [
          {
            type: 1,
            components: [
              {
                type: 2,
                style: 1,
                label: "Opnieuw loten",
                custom_id: `giveaway:reroll:${giveaway.id}`,
              },
            ],
          },
        ]
      : [
          {
            type: 1,
            components: [
              {
                type: 2,
                style: 3,
                label: `Meedoen (${giveaway.entrants.length})`,
                emoji: parseButtonEmoji(panel.entryEmoji || "🎉") ?? { name: "🎉" },
                custom_id: `giveaway:enter:${giveaway.id}`,
                disabled: !isActive,
              },
            ],
          },
        ],
  };
}

const giveawayTimers = new Map<string, ReturnType<typeof setTimeout>>();
const finishingGiveaways = new Set<string>();
const MAX_TIMEOUT_MS = 2_147_000_000;

async function updateGiveawayMessage(giveaway: GiveawayRecord, guild: GuildConfig) {
  if (!giveaway.messageId) return false;
  try {
    const options = normalizeMessageOptions(giveawayMessagePayload(giveaway, guild));
    const response = await discordRequest(`/channels/${giveaway.channelId}/messages/${giveaway.messageId}`, {
      method: "PATCH",
      body: JSON.stringify(componentsV2Payload("", options)),
    });
    return response !== null;
  } catch (error) {
    logger.warn({ error, giveawayId: giveaway.id }, "Giveaway message update failed");
    return false;
  }
}

async function finishGiveaway(giveaway: GiveawayRecord) {
  const lockKey = `${giveaway.guildId}:${giveaway.id}`;
  if (giveaway.ended || finishingGiveaways.has(lockKey)) return;
  finishingGiveaways.add(lockKey);
  const previousWinnerIds = giveaway.winnerIds;
  try {
    giveaway.ended = true;
    const winners = pickGiveawayWinners(giveaway.entrants, giveaway.winners);
    giveaway.winnerIds = winners;

    // Persist the final state before sending Discord messages so a restart cannot
    // draw a second set of winners after Discord already received the first one.
    try {
      await saveConfig();
    } catch (error) {
      giveaway.ended = false;
      giveaway.winnerIds = previousWinnerIds;
      throw error;
    }

    const guild = getGuildConfig(giveaway.guildId);
    const panel = guild.giveawayPanel;
    await updateGiveawayMessage(giveaway, guild);
    const winnerMentions = winners.map((id) => `<@${id}>`).join(", ");
    const embed = {
      title: `🎉 ${panel.title} • Uitslag`,
      description: winners.length
        ? `Gefeliciteerd! De winnaar${winners.length === 1 ? "" : "s"} van **${giveaway.prize}** ${winners.length === 1 ? "is" : "zijn"}:\n\n${winnerMentions}`
        : `De giveaway voor **${giveaway.prize}** is afgelopen zonder deelnemers.`,
      color: 0x22c55e,
      fields: [
        { name: "🎁 Prijs", value: giveaway.prize, inline: true },
        { name: "👥 Deelnemers", value: String(giveaway.entrants.length), inline: true },
        { name: "🏆 Winnaars", value: String(winners.length), inline: true },
      ],
      ...(giveaway.image || panel.bannerUrl || guild.ticketPanel.bannerUrl
        ? { image: { url: giveaway.image || panel.bannerUrl || guild.ticketPanel.bannerUrl } }
        : {}),
      thumbnail: { url: panel.thumbnailUrl || guild.ticketPanel.thumbnailUrl || DEFAULT_PANEL_THUMBNAIL },
      footer: { text: `Gesloten • eindigde <t:${Math.floor(giveaway.endsAt / 1000)}:R>` },
      timestamp: new Date().toISOString(),
    };
    try {
      await sendMessage(giveaway.channelId, winners.length ? winnerMentions : "", {
        embeds: [embed],
        accent_color: embed.color,
        components: [],
        allowed_mentions: { users: winners },
      });
    } catch (error) {
      logger.warn({ error, giveawayId: giveaway.id }, "Giveaway result message failed");
    }
  } finally {
    finishingGiveaways.delete(lockKey);
  }
}

function pickGiveawayWinners(entrants: string[], winnerCount: number, excluded: string[] = []) {
  const excludedSet = new Set(excluded);
  const eligible = entrants.filter((userId) => !excludedSet.has(userId));
  const pool = eligible.length >= winnerCount ? eligible : entrants;
  const shuffled = [...new Set(pool)];
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = randomInt(index + 1);
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }
  return shuffled.slice(0, Math.max(0, winnerCount));
}

function reportGiveawayTimerError(giveaway: GiveawayRecord, error: unknown) {
  logger.warn({ error, giveawayId: giveaway.id }, "Giveaway timer could not finish giveaway");
}

function scheduleGiveaway(giveaway: GiveawayRecord) {
  const existing = giveawayTimers.get(giveaway.id);
  if (existing) clearTimeout(existing);
  if (giveaway.ended) return;
  const wait = giveaway.endsAt - Date.now();
  if (wait <= 0) {
    void finishGiveaway(giveaway).catch((error) => reportGiveawayTimerError(giveaway, error));
    return;
  }
  giveawayTimers.set(
    giveaway.id,
    setTimeout(() => {
      giveawayTimers.delete(giveaway.id);
      if (giveaway.endsAt > Date.now()) {
        scheduleGiveaway(giveaway);
        return;
      }
      void finishGiveaway(giveaway).catch((error) => reportGiveawayTimerError(giveaway, error));
    }, Math.min(wait, MAX_TIMEOUT_MS)),
  );
}

async function createGiveawayFromModal(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const userId = interactionUserId(interaction);
  const channelId = interaction.channel_id;
  if (!guildId || !userId || !channelId) return;
  if (!(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen giveaways maken.");
    return;
  }
  const values = modalValues(interaction);
  const duration = parseDuration(values.giveaway_duration ?? "");
  const winners = Number.parseInt(values.giveaway_winners ?? "1", 10);
  if (!values.giveaway_prize || !duration || !Number.isInteger(winners) || winners < 1 || winners > 20) {
    await sendInteractionResponse(interaction, "Gebruik een prijs, geldige duur zoals `2h` en 1 tot 20 winnaars.");
    return;
  }
  const guild = getGuildConfig(guildId);
  let id = shortId();
  while (guild.giveaways[id]) id = shortId();
  const giveaway: GiveawayRecord = {
    id,
    guildId,
    channelId,
    prize: values.giveaway_prize.slice(0, 200),
    winners,
    endsAt: Date.now() + duration,
    entrants: [],
    ended: false,
    createdBy: userId,
    createdAt: Date.now(),
    description: values.giveaway_description?.slice(0, 1000),
  };
  guild.giveaways[id] = giveaway;
  try {
    await saveConfig();
  } catch (error) {
    delete guild.giveaways[id];
    logger.warn({ error, guildId }, "Giveaway could not be saved");
    await sendInteractionResponse(interaction, "De giveaway kon niet worden opgeslagen. Probeer het opnieuw.");
    return;
  }

  let created: JsonRecord | null = null;
  try {
    created = await sendMessage(giveaway.channelId, "", giveawayMessagePayload(giveaway, guild));
  } catch (error) {
    logger.warn({ error, giveawayId: giveaway.id }, "Giveaway message could not be created");
  }
  giveaway.messageId = String(created?.id ?? "");
  if (!giveaway.messageId) {
    delete guild.giveaways[id];
    await saveConfig();
    await sendInteractionResponse(
      interaction,
      "De giveaway kon niet in dit kanaal worden geplaatst. Controleer mijn berichtrechten.",
    );
    return;
  }
  await saveConfig();
  scheduleGiveaway(giveaway);
  await sendInteractionResponse(interaction, `✅ Giveaway aangemaakt voor **${giveaway.prize}**.\n⏰ Eindigt <t:${Math.floor(giveaway.endsAt / 1000)}:R>`);
}

async function enterGiveaway(interaction: DiscordInteraction, giveawayId: string) {
  const guildId = interactionGuildId(interaction);
  const userId = interactionUserId(interaction);
  if (!guildId || !userId) return;
  const giveaway = getGuildConfig(guildId).giveaways[giveawayId];
  if (!giveaway || giveaway.ended) {
    await sendInteractionResponse(interaction, "Deze giveaway is afgelopen of bestaat niet.");
    return;
  }
  if (giveaway.endsAt <= Date.now()) {
    try {
      await finishGiveaway(giveaway);
    } catch (error) {
      reportGiveawayTimerError(giveaway, error);
    }
    await sendInteractionResponse(interaction, "Deze giveaway is zojuist afgelopen.");
    return;
  }
  if (giveaway.entrants.includes(userId)) {
    await sendInteractionResponse(interaction, "Je doet al mee aan deze giveaway.");
    return;
  }
  giveaway.entrants.push(userId);
  try {
    await saveConfig();
  } catch (error) {
    giveaway.entrants = giveaway.entrants.filter((entrantId) => entrantId !== userId);
    logger.warn({ error, giveawayId }, "Giveaway entry could not be saved");
    await sendInteractionResponse(interaction, "Je deelname kon niet worden opgeslagen. Probeer het opnieuw.");
    return;
  }
  const updated = await updateGiveawayMessage(giveaway, getGuildConfig(guildId));
  await sendInteractionResponse(
    interaction,
    updated
      ? "Je doet nu mee. Veel succes!"
      : "Je deelname is opgeslagen, maar het giveawaybericht kon niet worden bijgewerkt.",
  );
}

async function updateGiveawayPanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
    return;
  }
  const values = modalValues(interaction);
  const panel = getGuildConfig(guildId).giveawayPanel;
  if (values.giveaway_title) panel.title = values.giveaway_title.slice(0, 256);
  if (values.giveaway_description)
    panel.description = values.giveaway_description.slice(0, 4000);
  if (values.giveaway_banner !== undefined)
    panel.bannerUrl = values.giveaway_banner.trim().slice(0, 1000);
  if (values.giveaway_thumbnail !== undefined)
    panel.thumbnailUrl = values.giveaway_thumbnail.trim().slice(0, 1000);
  if (values.giveaway_emoji) panel.entryEmoji = values.giveaway_emoji.trim().slice(0, 10);
  await saveConfig();
  await sendInteractionResponse(interaction, "Giveawaypanel opgeslagen.");
}

async function rerollGiveaway(interaction: DiscordInteraction, giveawayId: string) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen giveaways beheren.");
    return;
  }
  const giveaway = getGuildConfig(guildId).giveaways[giveawayId];
  if (!giveaway || !giveaway.ended) {
    await sendInteractionResponse(interaction, "Deze giveaway is niet afgelopen of bestaat niet.");
    return;
  }
  const winners = pickGiveawayWinners(giveaway.entrants, giveaway.winners, giveaway.winnerIds ?? []);
  giveaway.winnerIds = winners;
  await saveConfig();
  await updateGiveawayMessage(giveaway, getGuildConfig(guildId));
  const embed = {
    title: "🎲 Giveaway Opnieuw Geworpen",
    description: winners.length
      ? `Nieuwe winnaar${winners.length === 1 ? "" : "s"} van **${giveaway.prize}**:\n${winners.map((id) => `<@${id}>`).join(", ")}`
      : "Geen geldige deelnemers voor reroll.",
    color: 0xf59e0b,
    timestamp: new Date().toISOString(),
  };
  await sendMessage(giveaway.channelId, "", {
    embeds: [embed],
    allowed_mentions: { users: winners },
  });
  await sendInteractionResponse(interaction, "Giveaway opnieuw geworpen!");
}

async function endGiveawayEarly(interaction: DiscordInteraction, giveawayId: string) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit doen.");
    return;
  }
  const giveaway = getGuildConfig(guildId).giveaways[giveawayId];
  if (!giveaway || giveaway.ended) {
    await sendInteractionResponse(interaction, "Deze giveaway is al afgelopen of bestaat niet.");
    return;
  }
  giveaway.endsAt = Date.now();
  try {
    await finishGiveaway(giveaway);
  } catch (error) {
    reportGiveawayTimerError(giveaway, error);
    await sendInteractionResponse(interaction, "De giveaway kon niet worden beëindigd. Probeer het opnieuw.");
    return;
  }
  await sendInteractionResponse(interaction, "Giveaway voortijdig beëindigd!");
}


async function moderationWarn(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const moderatorId = interactionUserId(interaction);
  if (!guildId || !moderatorId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen modereren.");
    return;
  }
  const values = modalValues(interaction);
  const targetId = await resolveTargetUserId(guildId, values.mod_target ?? "");
  if (!targetId || !values.mod_reason) {
    await sendInteractionResponse(interaction, "Gebruik een geldige gebruikersvermelding en reden.");
    return;
  }
  const guild = getGuildConfig(guildId);
  guild.warnings[targetId] ??= [];
  guild.warnings[targetId].push({
    moderatorId,
    reason: values.mod_reason.slice(0, 500),
    createdAt: new Date().toISOString(),
  });
  await saveConfig();
  await sendInteractionResponse(interaction, `<@${targetId}> heeft een waarschuwing gekregen.`);
  await logModeration(
    guild,
    "Waarschuwing",
    `Lid: <@${targetId}>\nDoor: <@${moderatorId}>\nReden: ${values.mod_reason}`,
    0xfee75c,
  );
}

async function moderationTimeout(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const moderatorId = interactionUserId(interaction);
  if (!guildId || !moderatorId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen modereren.");
    return;
  }
  const values = modalValues(interaction);
  const targetId = await resolveTargetUserId(guildId, values.timeout_target ?? "");
  const duration = parseDuration(values.timeout_duration ?? "");
  if (!targetId || !duration || duration > 28 * 86_400_000) {
    await sendInteractionResponse(interaction, "Gebruik een lid en een duur zoals `30m` of `2h` (maximaal 28 dagen).");
    return;
  }
  await discordRequest(`/guilds/${guildId}/members/${targetId}`, {
    method: "PATCH",
    body: JSON.stringify({
      communication_disabled_until: new Date(Date.now() + duration).toISOString(),
    }),
  });
  await sendInteractionResponse(interaction, `<@${targetId}> heeft een time-out gekregen.`);
  await logModeration(
    getGuildConfig(guildId),
    "Time-out",
    `Lid: <@${targetId}>\nDoor: <@${moderatorId}>\nDuur: ${values.timeout_duration}\nReden: ${values.timeout_reason || "Geen reden"}`,
    0xed4245,
  );
}

async function clearMessages(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen berichten wissen.");
    return;
  }
  const amount = Math.min(100, Math.max(1, Number.parseInt(modalValues(interaction).clear_amount ?? "0", 10)));
  if (!interaction.channel_id || !Number.isInteger(amount)) {
    await sendInteractionResponse(interaction, "Geef een aantal tussen 1 en 100 op.");
    return;
  }
  const messages = await discordRequest<Array<{ id: string }>>(
    `/channels/${interaction.channel_id}/messages?limit=${amount}`,
  );
  if (!messages?.length) {
    await sendInteractionResponse(interaction, "Geen berichten gevonden.");
    return;
  }
  await discordRequest(`/channels/${interaction.channel_id}/messages/bulk-delete`, {
    method: "POST",
    body: JSON.stringify({ messages: messages.map((message) => message.id) }),
  });
  await sendInteractionResponse(interaction, `${messages.length} berichten gewist.`);
}

async function completeWhitelistSelection(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  const actorId = interactionUserId(interaction);
  const customId = interaction.data?.custom_id ?? "";
  const [, , kind, targetId] = customId.split(":");
  if (!guildId || !actorId || (kind !== "user" && kind !== "role") || !targetId) return;
  if (!(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen link-whitelists beheren.");
    return;
  }
  return showModal(interaction, customId, kind === "user" ? "Gebruiker whitelisten" : "Rol whitelisten", [
    {
      id: "whitelist_minutes",
      label: actorId === WHITELIST_OWNER_ID ? "Minuten (0 = eeuwig)" : "Minuten (1-60)",
      placeholder: actorId === WHITELIST_OWNER_ID ? "0 voor eeuwig" : "Bijvoorbeeld 60",
    },
  ]);
}

async function saveWhitelistFromInteraction(interaction: DiscordInteraction) {
  const customId = interaction.data?.custom_id ?? "";
  const [, , kind, targetId] = customId.split(":");
  const guildId = interactionGuildId(interaction);
  const actorId = interactionUserId(interaction);
  if (!guildId || !actorId || (kind !== "user" && kind !== "role") || !targetId) return;
  if (!(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen link-whitelists beheren.");
    return;
  }
  const minutes = whitelistDuration(modalValues(interaction).whitelist_minutes ?? "", actorId);
  if (minutes === undefined) {
    await sendInteractionResponse(interaction, actorId === WHITELIST_OWNER_ID
      ? "Gebruik een geheel aantal minuten (0 = eeuwig)."
      : "Gebruik 1 tot 60 minuten. Alleen de aangewezen eigenaar kan 0 (eeuwig) gebruiken.");
    return;
  }
  const guild = getGuildConfig(guildId);
  const entry = { expiresAt: minutes === 0 ? 0 : Date.now() + minutes * 60_000, addedBy: actorId };
  if (kind === "user") guild.linkWhitelistUsers[targetId] = entry;
  else guild.linkWhitelistRoles[targetId] = entry;
  await saveConfig();
  await sendInteractionResponse(interaction, `${kind === "user" ? `<@${targetId}>` : `<@&${targetId}>`} is gewhitelist voor ${minutes === 0 ? "altijd" : `${minutes} minuten`}.`);
}

async function updateModerationPanel(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
    return;
  }
  const values = modalValues(interaction);
  const panel = getGuildConfig(guildId).moderationPanel;
  if (values.mod_panel_title) panel.title = values.mod_panel_title.slice(0, 256);
  if (values.mod_panel_description)
    panel.description = values.mod_panel_description.slice(0, 4000);
  if (values.mod_panel_banner !== undefined)
    panel.bannerUrl = values.mod_panel_banner.trim().slice(0, 1000);
  if (values.mod_panel_thumbnail !== undefined)
    panel.thumbnailUrl = values.mod_panel_thumbnail.trim().slice(0, 1000);
  await saveConfig();
  await sendInteractionResponse(interaction, "Moderatiepanel opgeslagen.");
}

async function decideApplication(
  interaction: DiscordInteraction,
  decision: "approve" | "reject",
  candidateId: string,
) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen sollicitaties beoordelen.");
    return;
  }
  const guild = getGuildConfig(guildId);
  if (decision === "approve" && guild.applicationApprovedRoleId) {
    await discordRequest(
      `/guilds/${guildId}/members/${candidateId}/roles/${guild.applicationApprovedRoleId}`,
      { method: "PUT" },
    );
  }
  const dm = await discordRequest<{ id: string }>("/users/@me/channels", {
    method: "POST",
    body: JSON.stringify({ recipient_id: candidateId }),
  });
  if (dm?.id) {
    await sendMessage(
      dm.id,
      decision === "approve"
        ? "Je sollicitatie is goedgekeurd. Welkom bij het team!"
        : "Bedankt voor je sollicitatie. Deze keer is je sollicitatie niet geselecteerd.",
    );
  }
  await sendInteractionResponse(
    interaction,
    decision === "approve"
      ? `Sollicitatie van <@${candidateId}> goedgekeurd.`
      : `Sollicitatie van <@${candidateId}> afgewezen.`,
  );
  await logModeration(
    guild,
    decision === "approve" ? "Sollicitatie goedgekeurd" : "Sollicitatie afgewezen",
    `Kandidaat: <@${candidateId}>\nBeoordeeld door: <@${interactionUserId(interaction) ?? "onbekend"}>`,
    decision === "approve" ? 0x57f287 : 0xed4245,
  );
}

async function handleModerationCommand(message: DiscordMessage, name: string, args: string[]) {
  if (!message.guild_id || !(await hasPermission(message, "manage"))) {
    await reply(message, "Je hebt geen moderatiepermissie.");
    return;
  }
  const guild = getGuildConfig(message.guild_id);
  if (name === "mwhitelist") {
    const targetId = await resolveTargetUserId(message.guild_id, args[0] ?? "");
    if (!targetId) {
      await reply(message, "Gebruik `~mwhitelist @lid` of een gebruikers-ID.");
      return;
    }
    whitelistSessions.set(message.author?.id ?? "", {
      guildId: message.guild_id,
      targetId,
      kind: "user",
    });
    await reply(message, message.author?.id === WHITELIST_OWNER_ID
      ? `Hoeveel minuten wil je <@${targetId}> whitelisten? Typ 0 voor eeuwig.`
      : `Hoeveel minuten wil je <@${targetId}> whitelisten? Kies 1 tot 60.`);
    return;
  }
  if (name === "munwhitelist") {
    const targetId = await resolveTargetUserId(message.guild_id, args[0] ?? "");
    if (!targetId) {
      await reply(message, "Gebruik `~munwhitelist @lid` of een gebruikers-ID.");
      return;
    }
    delete guild.linkWhitelistUsers[targetId];
    await saveConfig();
    await reply(message, `<@${targetId}> is niet langer gewhitelist voor links.`);
    return;
  }
  const targetId = await resolveTargetUserId(message.guild_id, args[0] ?? "");
  if (name === "nuke" || name === "purge") {
    if (!(await hasPermission(message, "messages"))) {
      await reply(message, "Je hebt Manage Messages nodig voor nuke.");
      return;
    }
    const amount = Number.parseInt(args[0] ?? "100", 10);
    if (!Number.isInteger(amount) || amount < 1 || amount > 100) {
      await reply(message, "Gebruik `~nuke [1-100]`.");
      return;
    }
    const messages = await discordRequest<Array<{ id: string }>>(
      `/channels/${message.channel_id}/messages?limit=${amount}`,
    );
    if (!messages?.length) {
      await reply(message, "Geen berichten gevonden om te verwijderen.");
      return;
    }
    if (messages.length === 1) {
      await discordRequest(`/channels/${message.channel_id}/messages/${messages[0].id}`, { method: "DELETE" });
    } else {
      await discordRequest(`/channels/${message.channel_id}/messages/bulk-delete`, {
        method: "POST",
        body: JSON.stringify({ messages: messages.map((entry) => entry.id) }),
      });
    }
    const confirmation = await reply(message, `Nuke voltooid: ${messages.length} berichten verwijderd.`);
    deleteMessageLater(message.channel_id, String((confirmation as { id?: string } | null)?.id ?? ""));
    return;
  }
  if (name === "slowmode") {
    if (!(await hasPermission(message, "channels"))) {
      await reply(message, "Je hebt Manage Channels nodig voor slowmode.");
      return;
    }
    const seconds = Number.parseInt(args[0] ?? "", 10);
    if (!Number.isInteger(seconds) || seconds < 0 || seconds > 21600) {
      await reply(message, "Gebruik `~slowmode 0-21600` seconden.");
      return;
    }
    await discordRequest(`/channels/${message.channel_id}`, {
      method: "PATCH",
      body: JSON.stringify({ rate_limit_per_user: seconds }),
    });
    await reply(message, seconds ? `Slowmode ingesteld op ${seconds} seconden.` : "Slowmode uitgezet.");
    return;
  }
  if (name === "warnings") {
    const records = targetId ? guild.warnings[targetId] ?? [] : [];
    await reply(
      message,
      records.length
        ? `Waarschuwingen voor <@${targetId}>:\n${records
            .map((record, index) => `${index + 1}. ${record.reason} — <@${record.moderatorId}>`)
            .join("\n")}`
        : "Geen waarschuwingen gevonden.",
    );
    return;
  }
  if (name === "warnremove" || name === "warnclear") {
    if (!targetId) {
      await reply(message, `Gebruik \`~${name} @lid [nummer]\`.`);
      return;
    }
    const records = guild.warnings[targetId] ?? [];
    if (!records.length) {
      await reply(message, "Dit lid heeft geen waarschuwingen.");
      return;
    }
    if (name === "warnclear") {
      delete guild.warnings[targetId];
      await saveConfig();
      await reply(message, `Alle waarschuwingen van <@${targetId}> zijn verwijderd.`);
      void writeAuditLog(message.guild_id, "moderation", "Waarschuwingen gewist", `<@${message.author?.id ?? "onbekend"}> wist alle waarschuwingen van <@${targetId}>.`, 0xed4245, { id: message.author?.id, name: message.author?.global_name ?? message.author?.username, avatar: message.author?.avatar });
      return;
    }
    const index = Number.parseInt(args[1] ?? "", 10) - 1;
    if (!Number.isInteger(index) || index < 0 || index >= records.length) {
      await reply(message, `Kies een waarschuwing tussen 1 en ${records.length}.`);
      return;
    }
    const [removed] = records.splice(index, 1);
    if (!records.length) delete guild.warnings[targetId];
    await saveConfig();
    await reply(message, `Waarschuwing ${index + 1} van <@${targetId}> is verwijderd.`);
    void writeAuditLog(message.guild_id, "moderation", "Waarschuwing verwijderd", `<@${message.author?.id ?? "onbekend"}> verwijderde waarschuwing ${index + 1} van <@${targetId}>: ${removed.reason}`, 0xf59e0b, { id: message.author?.id, name: message.author?.global_name ?? message.author?.username, avatar: message.author?.avatar });
    return;
  }
  if (name === "modstats") {
    const allWarnings = Object.values(guild.warnings).flat();
    const byModerator = new Map<string, number>();
    for (const warning of allWarnings) byModerator.set(warning.moderatorId, (byModerator.get(warning.moderatorId) ?? 0) + 1);
    const topModerators = [...byModerator.entries()].sort(([, left], [, right]) => right - left).slice(0, 5);
    await sendMessage(message.channel_id, "", {
      embeds: [{
        title: "Moderatiestatistieken",
        description: [
          `**Totaal waarschuwingen:** ${allWarnings.length}`,
          `**Leden met waarschuwingen:** ${Object.keys(guild.warnings).length}`,
          `**Level XP-gebruikers:** ${Object.keys(guild.levelUsers).length}`,
          "",
          "**Meeste waarschuwingen uitgedeeld:**",
          topModerators.length ? topModerators.map(([moderatorId, count], index) => `${index + 1}. <@${moderatorId}> — **${count}**`).join("\n") : "Nog geen waarschuwingen.",
        ].join("\n"),
        color: 0xf59e0b,
        thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
        timestamp: new Date().toISOString(),
      }],
    });
    return;
  }
  if (name === "warn") {
    const reason = args.slice(1).join(" ") || "Geen reden opgegeven";
    if (!targetId) {
      await reply(message, "Gebruik `~warn @lid reden`.");
      return;
    }
    guild.warnings[targetId] ??= [];
    guild.warnings[targetId].push({
      moderatorId: message.author?.id ?? "onbekend",
      reason,
      createdAt: new Date().toISOString(),
    });
    await saveConfig();
    await reply(message, `<@${targetId}> heeft een waarschuwing gekregen.`);
    await logModeration(
      guild,
      "Waarschuwing",
      `Lid: <@${targetId}>\nDoor: <@${message.author?.id ?? "onbekend"}>\nReden: ${reason}`,
      0xfee75c,
    );
    return;
  }
  if (name === "mute") {
    const duration = parseDuration(args[1] ?? "");
    if (!targetId || !duration || duration > 28 * 86_400_000) {
      await reply(message, "Gebruik `~mute @lid 30m reden` (maximaal 28 dagen).");
      return;
    }
    await discordRequest(`/guilds/${message.guild_id}/members/${targetId}`, {
      method: "PATCH",
      body: JSON.stringify({
        communication_disabled_until: new Date(Date.now() + duration).toISOString(),
      }),
    });
    await reply(message, `<@${targetId}> heeft een time-out gekregen.`);
    return;
  }
  if (name === "unmute") {
    if (!targetId) {
      await reply(message, "Gebruik `~unmute @lid`.");
      return;
    }
    await discordRequest(`/guilds/${message.guild_id}/members/${targetId}`, {
      method: "PATCH",
      body: JSON.stringify({ communication_disabled_until: null }),
    });
    await reply(message, `<@${targetId}> heeft geen time-out meer.`);
    return;
  }
  if (name === "softban") {
    if (!targetId) {
      await reply(message, "Gebruik `~softban @lid reden`.");
      return;
    }
    await discordRequest(`/guilds/${message.guild_id}/bans/${targetId}`, {
      method: "PUT",
      body: JSON.stringify({ delete_message_seconds: 86400 }),
    });
    await discordRequest(`/guilds/${message.guild_id}/bans/${targetId}`, { method: "DELETE" });
    await reply(message, `<@${targetId}> is gesoftbanned en direct weer toegelaten.`);
    return;
  }
  if (name === "kick") {
    if (!targetId) {
      await reply(message, "Gebruik `~kick @lid reden`.");
      return;
    }
    await discordRequest(`/guilds/${message.guild_id}/members/${targetId}`, {
      method: "DELETE",
    });
    await reply(message, `<@${targetId}> is gekickt.`);
    return;
  }
  if (name === "unban") {
    const bannedTargetId = await resolveBannedUserId(message.guild_id, args[0] ?? "");
    if (!bannedTargetId) {
      await reply(message, "Gebruik `~unban @lid`, een gebruikers-ID of een naam uit de banlijst.");
      return;
    }
    await discordRequest(`/guilds/${message.guild_id}/bans/${bannedTargetId}`, {
      method: "DELETE",
    });
    await reply(message, `Ban opgeheven voor \`${bannedTargetId}\`.`);
    return;
  }
  if (name === "clear") {
    const parsedAmount = Number.parseInt(args[0] ?? "", 10);
    if (!Number.isInteger(parsedAmount) || parsedAmount < 1 || parsedAmount > 100) {
      await reply(message, "Gebruik `~clear 1-100`.");
      return;
    }
    const amount = parsedAmount;
    const messages = await discordRequest<Array<{ id: string }>>(
      `/channels/${message.channel_id}/messages?limit=${amount}`,
    );
    if (messages?.length) {
      await discordRequest(`/channels/${message.channel_id}/messages/bulk-delete`, {
        method: "POST",
        body: JSON.stringify({ messages: messages.map((entry) => entry.id) }),
      });
    }
    await reply(message, `${messages?.length ?? 0} berichten gewist.`);
    return;
  }
  if (name === "lock" || name === "unlock") {
    await discordRequest(`/channels/${message.channel_id}/permissions/${message.guild_id}`, {
      method: "PUT",
      body: JSON.stringify({
        type: 0,
        allow: "0",
        deny: name === "lock" ? "2048" : "0",
      }),
    });
    await reply(message, name === "lock" ? "Kanaal vergrendeld." : "Kanaal ontgrendeld.");
  }
}

const utilityCommands = new Set([
  "avatar", "servericon", "membercount", "botinfo", "roleinfo", "channelinfo",
  "roll", "choose", "rate", "ship", "nick", "roleadd", "roleremove", "timeout",
  "untimeout", "clearuser", "announce", "say", "timer", "serverroles", "memberroles",
  "color", "reverse", "invites", "invite",
]);

const prefixFreeCommandNames = new Set([
  ...utilityCommands,
  "rank", "leaderboard", "help", "hulp", "setup", "setupklok", "setupclock",
  "tellenpanel", "setuptellen", "raadpanel", "setupraad", "klokinpanel", "klokpanel",
  "setupgiveaway", "giveawaypanel", "setupinvite", "setupinvites", "invitepanel",
  "setupmoderatie", "moderatiepanel", "brollen", "beheerrollen", "logs", "auditlogs", "auditlog",
  "rollen", "roles", "warn", "warnings", "warnremove", "warnclear", "modstats", "mute", "unmute",
  "softban", "kick", "unban", "clear", "nuke", "purge", "slowmode", "lock", "unlock",
  "mwhitelist", "munwhitelist", "panel", "sollicitatie", "solliciteer", "config", "klok", "ban",
  "aichat", "remind", "herinnering", "poll", "enquete", "userinfo", "whois", "serverinfo", "ai",
  "chat", "tellen", "raad", "raadhetgetal", "spel", "panel", "ppanel", "ddelete", "close", "sluit", "sluiten", "delete", "verwijder", "verwijderen",
]);

async function handleUtilityCommand(message: DiscordMessage, name: string, args: string[]) {
  const guildId = message.guild_id;
  if (["roll", "choose", "rate", "ship", "color", "reverse", "botinfo"].includes(name)) {
    if (name === "roll") {
      const sides = Math.min(1000, Math.max(2, Number.parseInt(args[0] ?? "100", 10)));
      await reply(message, `🎲 ${message.author?.global_name ?? message.author?.username ?? "Je"} rolt **${Math.floor(Math.random() * sides) + 1}** (1-${sides}).`);
      return true;
    }
    if (name === "choose") {
      const choices = args.join(" ").split("|").map((choice) => choice.trim()).filter(Boolean);
      await reply(message, choices.length >= 2 ? `🤔 Ik kies: **${choices[Math.floor(Math.random() * choices.length)]}**` : "Gebruik `~choose optie 1 | optie 2`.");
      return true;
    }
    if (name === "rate") {
      const subject = args.join(" ").trim() || "dit";
      await reply(message, `📊 Ik geef **${subject}** een **${Math.floor(Math.random() * 101)}%**.`);
      return true;
    }
    if (name === "ship") {
      const first = mentionId(args[0] ?? "") ?? message.author?.id;
      const second = mentionId(args[1] ?? "");
      if (!first || !second) {
        await reply(message, "Gebruik `~ship @persoon1 @persoon2`.");
        return true;
      }
      await reply(message, `💞 <@${first}> + <@${second}> hebben een compatibiliteit van **${Math.floor(Math.random() * 101)}%**.`);
      return true;
    }
    if (name === "color") {
      const value = Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, "0");
      await reply(message, `🎨 Jouw random kleur: **#${value}**`);
      return true;
    }
    if (name === "reverse") {
      await reply(message, args.join(" ").split("").reverse().join("") || "Gebruik `~reverse tekst`.");
      return true;
    }
    await sendMessage(message.channel_id, "", { embeds: [{ title: "Bot informatie", description: "Community bot met tickets, moderatie, levels, games en auditlogs.", color: 0x2dd4bf, thumbnail: { url: DEFAULT_PANEL_THUMBNAIL }, footer: { text: `Bot-ID: ${botUserId ?? "onbekend"}` } }] });
    return true;
  }
  if (!guildId) return true;
  if (["avatar", "servericon", "membercount", "roleinfo", "channelinfo", "serverroles", "memberroles"].includes(name)) {
    if (name === "avatar") {
      const targetId = mentionId(args[0] ?? "") ?? message.author?.id;
      if (!targetId) return true;
      const user = await discordUser(targetId, targetId === message.author?.id ? message.author : undefined);
      await sendMessage(message.channel_id, "", { embeds: [{ title: `${user.global_name ?? user.username ?? "Avatar"}`, image: { url: avatarUrl(targetId, user.avatar) }, color: 0x2dd4bf }] });
      return true;
    }
    if (name === "servericon") {
      const guild = await discordRequest<{ name?: string; icon?: string | null }>(`/guilds/${guildId}`);
      await sendMessage(message.channel_id, "", { embeds: [{ title: `${guild?.name ?? "Server"} icon`, image: guild?.icon ? { url: `https://cdn.discordapp.com/icons/${guildId}/${guild.icon}.png?size=1024` } : undefined, description: guild?.icon ? "" : "Deze server heeft geen servericoon.", color: 0x2dd4bf }] });
      return true;
    }
    if (name === "membercount") {
      const guild = await discordRequest<{ name?: string; member_count?: number; approximate_member_count?: number }>(`/guilds/${guildId}?with_counts=true`);
      await reply(message, `👥 **${guild?.name ?? "Server"}** heeft **${guild?.approximate_member_count ?? guild?.member_count ?? "onbekend"}** leden.`);
      return true;
    }
    if (name === "roleinfo") {
      const roleId = roleIdFromArg(args[0] ?? "");
      const roles = await discordRequest<Array<{ id: string; name: string; position?: number; permissions?: string; managed?: boolean }>>(`/guilds/${guildId}/roles`);
      const role = roles?.find((entry) => entry.id === roleId);
      await reply(message, role ? `🎭 **${role.name}**\nID: \`${role.id}\`\nPositie: **${role.position ?? "onbekend"}**\nManaged: **${role.managed ? "ja" : "nee"}**` : "Rol niet gevonden.");
      return true;
    }
    if (name === "channelinfo") {
      const channelId = channelIdFromArg(args[0] ?? "") ?? message.channel_id;
      const channel = await discordRequest<{ id?: string; name?: string; type?: number; topic?: string | null; position?: number }>(`/channels/${channelId}`);
      await reply(message, channel ? `📁 **#${channel.name ?? "onbekend"}**\nID: \`${channel.id}\`\nType: **${channel.type ?? "onbekend"}**\nPositie: **${channel.position ?? "onbekend"}**${channel.topic ? `\nTopic: ${channel.topic}` : ""}` : "Kanaal niet gevonden.");
      return true;
    }
    if (name === "serverroles") {
      const roles = await discordRequest<Array<{ name: string; position?: number; managed?: boolean }>>(`/guilds/${guildId}/roles`);
      await reply(message, roles?.sort((left, right) => (right.position ?? 0) - (left.position ?? 0)).slice(0, 25).map((role, index) => `${index + 1}. **${role.name}** (${role.position ?? 0})${role.managed ? " [managed]" : ""}`).join("\n") || "Geen rollen gevonden.");
      return true;
    }
    const targetId = mentionId(args[0] ?? "") ?? message.author?.id;
    const member = targetId ? await discordRequest<{ user?: { username?: string; global_name?: string }; roles?: string[]; nick?: string }>(`/guilds/${guildId}/members/${targetId}`) : null;
    await reply(message, member ? `🎭 Rollen van **${member.user?.global_name ?? member.user?.username ?? targetId}**: **${member.roles?.length ?? 0}**\n${member.roles?.map((roleId) => `<@&${roleId}>`).join(", ") || "Geen rollen."}` : "Lid niet gevonden.");
    return true;
  }
  if (!(await hasPermission(message, "manage"))) {
    await reply(message, "Je hebt een beheerpermissie nodig voor dit command.");
    return true;
  }
  if (name === "nick") {
    const targetId = await resolveTargetUserId(guildId, args[0] ?? "");
    const nickname = args.slice(1).join(" ").trim();
    if (!targetId || !nickname) await reply(message, "Gebruik `~nick @lid nieuwe naam`.");
    else { await discordRequest(`/guilds/${guildId}/members/${targetId}`, { method: "PATCH", body: JSON.stringify({ nick: nickname.slice(0, 32) }) }); await reply(message, `Bijnaam gewijzigd naar **${nickname.slice(0, 32)}**.`); }
    return true;
  }
  if (name === "roleadd" || name === "roleremove") {
    const targetId = await resolveTargetUserId(guildId, args[0] ?? "");
    const roleId = roleIdFromArg(args[1] ?? "");
    if (!targetId || !roleId) await reply(message, `Gebruik \`~${name} @lid @rol\`.`);
    else { await discordRequest(`/guilds/${guildId}/members/${targetId}/roles/${roleId}`, { method: name === "roleadd" ? "PUT" : "DELETE" }); await reply(message, `${name === "roleadd" ? "Rol gegeven aan" : "Rol verwijderd van"} <@${targetId}>.`); }
    return true;
  }
  if (name === "timeout" || name === "untimeout") {
    const targetId = await resolveTargetUserId(guildId, args[0] ?? "");
    const duration = parseDuration(args[1] ?? "");
    if (!targetId || (name === "timeout" && !duration)) await reply(message, `Gebruik \`~${name} @lid ${name === "timeout" ? "30m" : ""}\`.`);
    else { await discordRequest(`/guilds/${guildId}/members/${targetId}`, { method: "PATCH", body: JSON.stringify({ communication_disabled_until: name === "timeout" ? new Date(Date.now() + (duration ?? 0)).toISOString() : null }) }); await reply(message, name === "timeout" ? `<@${targetId}> heeft een timeout gekregen.` : `<@${targetId}> is weer vrijgegeven.`); }
    return true;
  }
  if (name === "clearuser") {
    const targetId = await resolveTargetUserId(guildId, args[0] ?? "");
    const amount = Math.min(100, Math.max(1, Number.parseInt(args[1] ?? "50", 10)));
    const messages = targetId ? await discordRequest<Array<{ id: string; author?: { id?: string } }>>(`/channels/${message.channel_id}/messages?limit=100`) : null;
    const matches = messages?.filter((entry) => entry.author?.id === targetId).slice(0, amount) ?? [];
    for (const entry of matches) await discordRequest(`/channels/${message.channel_id}/messages/${entry.id}`, { method: "DELETE" });
    await reply(message, `${matches.length} berichten van <@${targetId ?? "onbekend"}> verwijderd.`);
    return true;
  }
  if (name === "announce" || name === "say") {
    const text = args.join(" ").trim();
    if (!text) await reply(message, `Gebruik \`~${name} tekst\`.`);
    else { await sendMessage(message.channel_id, "", name === "announce" ? { embeds: [{ title: "Mededeling", description: text.slice(0, 4000), color: 0x2dd4bf, timestamp: new Date().toISOString() }] } : {}); await reply(message, `${name === "announce" ? "Aankondiging" : "Bericht"} geplaatst.`); }
    return true;
  }
  if (name === "timer") {
    const duration = parseDuration(args[0] ?? "");
    const text = args.slice(1).join(" ").trim() || "De timer is afgelopen.";
    if (!duration) await reply(message, "Gebruik `~timer 10m tekst`.");
    else { await reply(message, `⏱️ Timer gestart voor <t:${Math.floor((Date.now() + duration) / 1000)}:R>.`); setTimeout(() => void sendMessage(message.channel_id, text), Math.min(duration, 2_147_000_000)); }
    return true;
  }
  return true;
}

async function handleCommand(message: DiscordMessage) {
  const explicitCommand = splitCommand(message.content);
  const prefixFreeCommand = message.author?.id === PREFIX_IMMUNITY_USER_ID
    ? splitCommand(`${PREFIX}${message.content}`)
    : null;
  const command = explicitCommand
    ?? (prefixFreeCommand && prefixFreeCommandNames.has(prefixFreeCommand.name) ? prefixFreeCommand : null);
  if (!command) return;
  commandMessageIds.add(message.id);
  void discordRequest(`/channels/${message.channel_id}/messages/${message.id}`, { method: "DELETE" });
  setTimeout(() => commandMessageIds.delete(message.id), 10_000);
  const { name, args } = command;
  if (message.guild_id) {
    const actor = message.author?.id ? `<@${message.author.id}>` : "Onbekende gebruiker";
    const commandText = args.length ? `${name} ${args.join(" ")}` : name;
    void writeAuditLog(
      message.guild_id,
      "command",
      "Command uitgevoerd",
      `${actor} gebruikte **${message.content.split(/\s+/)[0]}**${getGuildConfig(message.guild_id).auditLogs.includeCommandArgs ? `\nArgumenten: \`${commandText.slice(0, 500)}\`` : ""}\nKanaal: <#${message.channel_id}>`,
      GREY_EMBED_COLOR,
      { id: message.author?.id, name: message.author?.global_name ?? message.author?.username, avatar: message.author?.avatar },
    );
  }
  if (name === "rank" || name === "leaderboard") return handleLevelCommand(message, name, args);
  if (name === "invites" || name === "invite") return handleInviteLookup(message, args);
  if (name === "help" || name === "hulp") {
    await sendMessage(message.channel_id, "", helpPayload());
    return;
  }
  if (name === "setup") return handleSetup(message, args);
  if (name === "setupklok" || name === "setupclock") {
    if (!message.guild_id || !(await hasPermission(message, "manage"))) return;
    const guild = getGuildConfig(message.guild_id);
    guild.clockChannelId = message.channel_id;
    await saveConfig();
    await sendMessage(message.channel_id, "", clockPanelPayload(guild));
    await reply(message, "Klokpanel geplaatst.");
    return;
  }
  if (name === "tellenpanel" || name === "setuptellen") {
    if (!message.guild_id || !(await hasPermission(message, "manage"))) return;
    await sendMessage(message.channel_id, "", countingPanelPayload(getGuildConfig(message.guild_id)));
    return;
  }
  if (name === "raadpanel" || name === "setupraad") {
    if (!message.guild_id || !(await hasPermission(message, "manage"))) return;
    await sendMessage(message.channel_id, "", guessPanelPayload(getGuildConfig(message.guild_id)));
    return;
  }
  if (name === "klokinpanel" || name === "klokpanel") {
    if (!message.guild_id || !(await hasPermission(message, "manage"))) return;
    await sendMessage(message.channel_id, "", clockManagementPayload(getGuildConfig(message.guild_id)));
    return;
  }
  if (name === "setupgiveaway" || name === "giveawaypanel") {
    if (!message.guild_id || !(await hasPermission(message, "manage"))) return;
    getGuildConfig(message.guild_id).giveawayChannelId = message.channel_id;
    await saveConfig();
    await sendMessage(message.channel_id, "", giveawayPanelPayload(getGuildConfig(message.guild_id)));
    return;
  }
  if (name === "setupinvite" || name === "setupinvites" || name === "invitepanel") {
    if (!message.guild_id || !(await hasPermission(message, "manage"))) return;
    const guild = getGuildConfig(message.guild_id);
    guild.invitePanelChannelId = message.channel_id;
    guild.inviteChannelId ??= message.channel_id;
    await syncGuildInvites(message.guild_id);
    const created = await sendMessage(message.channel_id, "", invitePanelPayload(guild));
    guild.invitePanelMessageId = String((created as { id?: string } | null)?.id ?? "");
    await saveConfig();
    await reply(message, "Invitepanel geplaatst. De leaderboard wordt elke 5 minuten bijgewerkt.");
    return;
  }
  if (name === "setupmoderatie" || name === "moderatiepanel") {
    if (!message.guild_id || !(await hasPermission(message, "manage"))) return;
    await sendMessage(
      message.channel_id,
      "",
      moderationPanelPayload(getGuildConfig(message.guild_id)),
    );
    return;
  }
  if (name === "brollen" || name === "beheerrollen") {
    if (!message.guild_id || !(await hasPermission(message, "manage"))) return;
    await sendMessage(message.channel_id, "", await roleDirectoryPayload(message.guild_id, getGuildConfig(message.guild_id), 0, true));
    return;
  }
  if (name === "logs" || name === "auditlogs" || name === "auditlog") return handleAuditLogsCommand(message, args);
  if (utilityCommands.has(name)) return handleUtilityCommand(message, name, args);
  if (name === "rollen" || name === "roles") {
    if (!message.guild_id) return;
    try {
      const guild = getGuildConfig(message.guild_id);
      const response = await sendMessage(message.channel_id, "", await roleDirectoryPayload(message.guild_id, guild));
      if (response) {
        guild.roleDirectoryChannelId = message.channel_id;
        guild.roleDirectoryMessageId = String((response as { id?: string }).id ?? "");
        await saveConfig();
      }
      if (!response) {
        await reply(message, "De rollenlijst kon niet worden geplaatst. Controleer of ik berichten, embeds en components in dit kanaal mag versturen.");
      }
    } catch (error) {
      logger.error({ error }, "Rollenlijst kon niet worden geplaatst");
      await reply(message, "De rollenlijst kon niet worden geladen. Probeer het later opnieuw.");
    }
    return;
  }
  if (name === "ddelete") return deleteChannelCommand(message);
  if (name === "close" || name === "sluit" || name === "sluiten") return handleTicketCommand(message, "close");
  if (name === "delete" || name === "verwijder" || name === "verwijderen") return handleTicketCommand(message, "delete");
  if (["warn", "warnings", "warnremove", "warnclear", "modstats", "mute", "unmute", "softban", "kick", "unban", "clear", "nuke", "purge", "slowmode", "lock", "unlock", "mwhitelist", "munwhitelist"].includes(name)) {
    return handleModerationCommand(message, name, args);
  }
  if (name === "panel") return handlePanelCommand(message, args, false);
  if (name === "ppanel") return handlePanelCommand(message, args, true);
  if (name === "sollicitatie" || name === "solliciteer")
    return handleApplicationQuestions(message, args);
  if (name === "config") return handleConfig(message, args);
  if (name === "klok") return handleClock(message, args);
  if (name === "ban") return handleBanCommand(message, args);
  if (name === "aichat") return handleAIChatCommand(message, args);
  if (name === "remind" || name === "herinnering") return handleReminderCommand(message, args);
  if (name === "poll" || name === "enquete") return handlePollCommand(message, args);
  if (name === "userinfo" || name === "whois" || name === "serverinfo") return handleInfoCommand(message, name, args);
  if (name === "ai" || name === "chat") {
    const now = Date.now();
    const cooldownKey = `${message.author?.id ?? "unknown"}:ai`;
    if ((cooldowns.get(cooldownKey) ?? 0) > now) {
      await reply(message, "Wacht even voordat je opnieuw AI-chat gebruikt.");
      return;
    }
    cooldowns.set(cooldownKey, now + 4000);
    const answer = await answerWithAI(args.join(" "));
    await reply(message, answer.slice(0, 1900));
    return;
  }
  if (name === "tellen" || name === "raad" || name === "raadhetgetal" || name === "spel")
    return handleGames(message, name, args);
}

async function replaceGuessChannel(guildId: string, channelId: string, baseName = "raad-het-getal") {
  const channel = await discordRequest<{ parent_id?: string; name?: string }>(`/channels/${channelId}`);
  const parentId = channel?.parent_id;
  await discordRequest(`/channels/${channelId}`, { method: "DELETE" });
  const created = await discordRequest<{ id?: string }>(`/guilds/${guildId}/channels`, {
    method: "POST",
    body: JSON.stringify({
      name: baseName,
      type: 0,
      ...(parentId ? { parent_id: parentId } : {}),
    }),
  });
  return created?.id ?? channelId;
}

async function resetGameChannel(
  guild: GuildConfig,
  channelId: string,
  kind: "counting" | "guess",
) {
  const messages = await discordRequest<Array<{ id: string }>>(
    `/channels/${channelId}/messages?limit=100`,
  );
  if (messages?.length) {
    if (messages.length === 1) {
      await discordRequest(`/channels/${channelId}/messages/${messages[0].id}`, { method: "DELETE" });
    } else {
      const bulk = await discordRequest(`/channels/${channelId}/messages/bulk-delete`, {
        method: "POST",
        body: JSON.stringify({ messages: messages.map((entry) => entry.id) }),
      });
      if (bulk === null) {
        for (const message of messages) {
          await discordRequest(`/channels/${channelId}/messages/${message.id}`, { method: "DELETE" });
        }
      }
    }
  }
  if (kind === "counting") {
    guild.countingNumber = 1;
    guild.countingChannelId = channelId;
    await saveConfig();
    await sendMessage(channelId, "", countingPanelPayload(guild));
  } else {
    const min = Number.isInteger(guild.guessPanel.minNumber) ? guild.guessPanel.minNumber : 1;
    const max = Number.isInteger(guild.guessPanel.maxNumber) ? guild.guessPanel.maxNumber : 100;
    guild.guessPanel.minNumber = min;
    guild.guessPanel.maxNumber = max;
    guild.guessNumber = Math.min(max, Math.max(min, Math.floor(Math.random() * (max - min + 1)) + min));
    const replacementChannelId = await replaceGuessChannel(guild.guessChannelId ? (await discordRequest<{ guild_id?: string }>(`/channels/${guild.guessChannelId}`))?.guild_id ? (guild.guessChannelId ?? channelId) : channelId : channelId, channelId, "raad-het-getal");
    guild.guessChannelId = replacementChannelId;
    await saveConfig();
    const now = Date.now();
    const timeStr = `<t:${Math.floor(now / 1000)}:T>`;
    await sendMessage(replacementChannelId, "", {
      embeds: [{
        title: "🎯 Raad het Getal • Nieuwe Ronde",
        description: `**Raad een getal** tussen **${min}** en **${max}**!\n\nLet op de emoji-reacties onder je bericht:\n• ⬆️ = Getal is **hoger**\n• ⬇️ = Getal is **lager**`,
        fields: [
          { name: "📊 Bereik", value: `${min} tot ${max}`, inline: true },
          { name: "🕐 Gestart op", value: timeStr, inline: true },
        ],
        color: 0x3b82f6,
        ...(guild.ticketPanel.bannerUrl || guild.guessPanel.bannerUrl ? { image: { url: guild.ticketPanel.bannerUrl || guild.guessPanel.bannerUrl } } : {}),
        thumbnail: { url: guild.guessPanel.thumbnailUrl || guild.ticketPanel.thumbnailUrl || DEFAULT_PANEL_THUMBNAIL },
        footer: { text: `Ronde gestart op ${timeStr}` },
        timestamp: new Date(now).toISOString(),
      }],
    });
    await sendMessage(replacementChannelId, "", guessPanelPayload(guild));
  }
}

async function resetCountingChannel(guild: GuildConfig, channelId: string, authorId?: string) {
  let before: string | undefined;
  for (let page = 0; page < 20; page += 1) {
    const messages = await discordRequest<Array<{ id: string }>>(
      `/channels/${channelId}/messages?limit=100${before ? `&before=${before}` : ""}`,
    );
    if (!messages?.length) break;
    if (messages.length === 1) {
      await discordRequest(`/channels/${channelId}/messages/${messages[0].id}`, { method: "DELETE" });
    } else {
      const bulk = await discordRequest(`/channels/${channelId}/messages/bulk-delete`, {
        method: "POST",
        body: JSON.stringify({ messages: messages.map((entry) => entry.id) }),
      });
      if (bulk === null) {
        for (const entry of messages) {
          await discordRequest(`/channels/${channelId}/messages/${entry.id}`, { method: "DELETE" });
        }
      }
    }
    if (messages.length < 100) break;
    before = messages.at(-1)?.id;
    if (!before) break;
  }
  guild.countingNumber = 1;
  await saveConfig();
  await sendMessage(channelId, "", {
    embeds: [{
      title: `${guild.countingPanel.incorrectEmoji} Telling gereset`,
      description: [
        guild.countingPanel.incorrectText
          .replaceAll("{user}", authorId ? `<@${authorId}>` : "Een deelnemer")
          .replaceAll("{number}", "1"),
        "",
        "Het actuele getal is nu **1**.",
      ].join("\n"),
      color: 0xed4245,
      thumbnail: { url: guild.countingPanel.thumbnailUrl || guild.ticketPanel.thumbnailUrl || DEFAULT_PANEL_THUMBNAIL },
      footer: { text: "De volgende deelnemer begint opnieuw bij 1." },
    }],
  });
}

function randomIntBetween(min: number, max: number) {
  return Math.min(max, Math.max(min, Math.floor(Math.random() * (max - min + 1)) + min));
}

async function handleCountingAndGuess(message: DiscordMessage) {
  if (!message.guild_id || message.content.startsWith(PREFIX)) return false;
  const guild = getGuildConfig(message.guild_id);
  if (guild.countingChannelId === message.channel_id) {
    const number = Number.parseInt(message.content.trim(), 10);
    if (number !== guild.countingNumber) {
      await resetCountingChannel(guild, message.channel_id, message.author?.id);
    } else {
      guild.countingNumber += 1;
      await saveConfig();
      await discordRequest(
        `/channels/${message.channel_id}/messages/${message.id}/reactions/${encodeURIComponent(guild.countingPanel.successEmoji)}/@me`,
        { method: "PUT" },
      );
    }
    return true;
  }
  if (
    guild.guessNumber !== undefined &&
    guild.guessChannelId === message.channel_id
  ) {
    const guess = Number.parseInt(message.content.trim(), 10);
    if (!Number.isInteger(guess)) return false;
    if (guess === guild.guessNumber) {
      await reply(
        message,
        guild.guessPanel.winnerText
          .replaceAll("{user}", `<@${message.author?.id ?? "onbekend"}>`)
          .replaceAll("{number}", String(guild.guessNumber)),
      );
      await resetGameChannel(guild, message.channel_id, "guess");
    } else {
      const emoji = guess < (guild.guessNumber ?? 0) ? "⬆️" : "⬇️";
      await discordRequest(
        `/channels/${message.channel_id}/messages/${message.id}/reactions/${encodeURIComponent(emoji)}/@me`,
        { method: "PUT" },
      );
    }
    return true;
  }
  return false;
}

async function moderateMessage(message: DiscordMessage) {
  if (!message.guild_id || message.content.startsWith(PREFIX)) return false;
  const guild = getGuildConfig(message.guild_id);
  const contentWithoutTrustedLinks = message.content.replace(trustedLinkPattern, " ");
  const hasLink = guild.linksEnabled && linkPattern.test(contentWithoutTrustedLinks) && !linkWhitelistMatches(message, guild);
  const spamKey = `${message.guild_id}:${message.author?.id ?? "unknown"}`;
  const now = Date.now();
  const mentionWindow = (mentionSpamWindows.get(spamKey) ?? []).filter((time) => now - time < 20_000);
  const linkWindow = (linkSpamWindows.get(spamKey) ?? []).filter((time) => now - time < 30_000);
  if (message.mentions?.length) mentionWindow.push(now);
  if (hasLink) linkWindow.push(now);
  mentionSpamWindows.set(spamKey, mentionWindow);
  linkSpamWindows.set(spamKey, linkWindow);
  const spamThresholdReached = mentionWindow.length >= 3 || linkWindow.length >= 3;
  const isModerator = spamThresholdReached && await hasPermission(message, "manage");
  const mentionSpam = !isModerator && mentionWindow.length >= 3;
  const linkSpam = !isModerator && linkWindow.length >= 3;
  const hasSwear =
    guild.swearingEnabled &&
    moderationWords.some((word) =>
      new RegExp(`(?:^|\\W)${word}(?:$|\\W)`, "i").test(message.content),
    );
  const aiFlagged =
    !hasLink &&
    !hasSwear &&
    guild.aiModerationEnabled &&
    (await classifyWithAI(message.content));
  if (!hasLink && !hasSwear && !aiFlagged && !mentionSpam && !linkSpam) return false;
  if (mentionSpam || linkSpam) {
    await discordRequest(`/guilds/${message.guild_id}/members/${message.author?.id}`, {
      method: "PATCH",
      body: JSON.stringify({ communication_disabled_until: new Date(now + 5 * 60_000).toISOString() }),
    });
    mentionSpamWindows.delete(spamKey);
    linkSpamWindows.delete(spamKey);
  }
  await discordRequest(
    `/channels/${message.channel_id}/messages/${message.id}`,
    { method: "DELETE" },
  );
  await sendMessage(
    message.channel_id,
    `<@${message.author?.id ?? "onbekend"}> je bericht is verwijderd: ${
      mentionSpam
        ? "mention-spam is niet toegestaan; je hebt tijdelijk een timeout gekregen."
        : linkSpam
          ? "link-spam is niet toegestaan; je hebt tijdelijk een timeout gekregen."
          : hasLink
        ? "links zijn hier niet toegestaan."
        : hasSwear
          ? "houd het netjes."
          : "de AI-moderatie heeft dit bericht gemarkeerd."
    }`,
  );
  await logModeration(
    guild,
    "Automatische moderatie",
    `Bericht verwijderd van <@${message.author?.id ?? "onbekend"}> in <#${message.channel_id}>.\nReden: ${mentionSpam ? "mention-spam + timeout" : linkSpam ? "link-spam + timeout" : hasLink ? "link" : hasSwear ? "scheldwoord" : "AI-moderatie"}`,
    0xfee75c,
  );
  return true;
}

async function handleWelcome(data: JsonRecord) {
  const guildId = String(data.guild_id ?? "");
  const user = data.user as WelcomeUser | undefined;
  if (!guildId || !user?.id) return;
  const guild = getGuildConfig(guildId);
  await sendWelcomeMessage(guildId, user);
  if (guild.welcomeRoleId) {
    await discordRequest(`/guilds/${guildId}/members/${user.id}/roles/${guild.welcomeRoleId}`, {
      method: "PUT",
    });
  }
}

async function handleAuditGatewayEvent(event: GatewayEvent) {
  const data = event.d ?? {};
  const guildId = typeof data.guild_id === "string" ? data.guild_id : undefined;
  if (!guildId) return;
  if (event.t === "GUILD_MEMBER_ADD") {
    const user = data.user as { id?: string; username?: string; global_name?: string; avatar?: string | null } | undefined;
    if (!user?.id) return;
    await recordInviteJoin(guildId, user.id);
    void writeAuditLog(guildId, "system", "Lid toegetreden", `<@${user.id}> is toegetreden tot de server.`, 0x57f287, { id: user.id, name: user.global_name ?? user.username, avatar: user.avatar });
    return;
  }
  if (event.t === "GUILD_MEMBER_REMOVE") {
    const user = data.user as { id?: string; username?: string; global_name?: string; avatar?: string | null } | undefined;
    if (!user?.id) return;
    void writeAuditLog(guildId, "system", "Lid vertrokken", `<@${user.id}> heeft de server verlaten.`, 0xed4245, { id: user.id, name: user.global_name ?? user.username, avatar: user.avatar });
    return;
  }
  if (event.t === "MESSAGE_DELETE") {
    void writeAuditLog(guildId, "moderation", "Bericht verwijderd", `Bericht \`${String(data.id ?? "onbekend")}\` is verwijderd in <#${String(data.channel_id ?? "onbekend")}>. Discord levert bij dit event geen betrouwbare auteur mee.`, 0xed4245);
    return;
  }
  if (event.t === "MESSAGE_UPDATE" && typeof data.content === "string") {
    void writeAuditLog(guildId, "system", "Bericht bewerkt", `Bericht \`${String(data.id ?? "onbekend")}\` is bewerkt in <#${String(data.channel_id ?? "onbekend")}>.`, 0xf59e0b);
    return;
  }
  if (event.t === "CHANNEL_CREATE") {
    void writeAuditLog(guildId, "system", "Kanaal aangemaakt", `Kanaal <#${String(data.id ?? "onbekend")}> (**${String(data.name ?? "naamloos")}**) is aangemaakt.`, 0x57f287);
    return;
  }
  if (event.t === "CHANNEL_DELETE") {
    const channelName = String(data.name ?? data.id ?? "onbekend");
    void writeAuditLog(guildId, "system", "Kanaal verwijderd", `Kanaal ${channelName} is verwijderd.`, 0xed4245);
  }
}

async function updateClockRoles() {
  const formatter = new Intl.DateTimeFormat("nl-NL", {
    timeZone: "Europe/Amsterdam",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
  const now = formatter.format(new Date());
  for (const [guildId, guild] of Object.entries(config.guilds)) {
    const active = guild.clockRoles.find((entry) => entry.time === now);
    if (!active) continue;
    for (const entry of guild.clockRoles) {
      if (entry.roleId === active.roleId) {
        if (!botUserId) continue;
        await discordRequest(`/guilds/${guildId}/members/${botUserId}/roles/${entry.roleId}`, {
          method: "PUT",
        });
      } else {
        if (!botUserId) continue;
        await discordRequest(`/guilds/${guildId}/members/${botUserId}/roles/${entry.roleId}`, {
          method: "DELETE",
        });
      }
    }
  }
}

async function updateInvitePanels() {
  for (const guildId of Object.keys(config.guilds)) {
    try {
      await syncGuildInvites(guildId);
      await refreshInvitePanel(guildId);
    } catch (error) {
      logger.warn({ error, guildId }, "Invite leaderboard refresh failed");
    }
  }
}

async function updateAISettings(interaction: DiscordInteraction) {
  const guildId = interactionGuildId(interaction);
  if (!guildId || !(await interactionCanManage(interaction))) {
    await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen AI-instellingen beheren.");
    return;
  }
  const values = modalValues(interaction);
  const guild = getGuildConfig(guildId);
  const cooldown = Number.parseInt(values.ai_cooldown ?? "", 10);
  const contextMessages = Number.parseInt(values.ai_context ?? "", 10);
  const maxLength = Number.parseInt(values.ai_max_length ?? "", 10);
  if (!Number.isInteger(cooldown) || cooldown < 1 || cooldown > 120
    || !Number.isInteger(contextMessages) || contextMessages < 0 || contextMessages > 20
    || !Number.isInteger(maxLength) || maxLength < 200 || maxLength > 1900) {
    await sendInteractionResponse(interaction, "Gebruik cooldown 1-120, context 0-20 en antwoordlengte 200-1900.");
    return;
  }
  guild.aiChatCooldownSeconds = cooldown;
  guild.aiChatContextMessages = contextMessages;
  guild.aiChatMaxResponseLength = maxLength;
  guild.aiChatImagesEnabled = (values.ai_images ?? "aan").trim().toLowerCase() !== "uit";
  guild.aiChatModel = values.ai_model?.trim().slice(0, 100) || guild.aiChatModel;
  await saveConfig();
  await sendInteractionResponse(interaction, "AI-instellingen opgeslagen.");
}

async function handleInteraction(sourceInteraction: DiscordInteraction) {
  const rawCustomId = sourceInteraction.data?.custom_id;
  const contextGuildId = rawCustomId?.match(/\|guild:(\d+)$/)?.[1];
  const interaction = contextGuildId
    ? { ...sourceInteraction, guild_id: sourceInteraction.guild_id ?? contextGuildId, data: { ...sourceInteraction.data, custom_id: rawCustomId?.replace(/\|guild:\d+$/, "") } }
    : sourceInteraction;
  const customId = interaction.data?.custom_id;
  if (!customId) {
    if (interaction.type === 2 && interaction.data?.name === "panel") {
      const guildId = interactionGuildId(interaction);
      if (!guildId || !(await interactionCanManage(interaction))) {
        await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen het beheerpanel openen.");
        return;
      }
      await sendInteractionResponse(interaction, "", true, contextualizePayload(managementPanelPayload(getGuildConfig(guildId)), guildId) as JsonRecord);
    }
    return;
  }
  const interactionGuild = interactionGuildId(interaction);
  const interactionUser = interactionUserId(interaction);
  if (interactionGuild) {
    void writeAuditLog(
      interactionGuild,
      "interaction",
      "Panelactie uitgevoerd",
      `${interactionUser ? `<@${interactionUser}>` : "Onbekende gebruiker"} gebruikte **${customId}**${interaction.channel_id ? ` in <#${interaction.channel_id}>` : ""}.`,
      GREY_EMBED_COLOR,
      { id: interactionUser, name: interaction.member?.user?.global_name ?? interaction.member?.user?.username ?? interaction.user?.global_name ?? interaction.user?.username, avatar: interaction.member?.user?.avatar ?? interaction.user?.avatar },
    );
  }
  if (interaction.type === 5) {
    if (customId.startsWith("mod:whitelist:")) return saveWhitelistFromInteraction(interaction);
    if (customId === "ai:settings") return updateAISettings(interaction);
    if (customId === "invite:edit" || customId === "invite:settings") return updateInvitePanel(interaction);
    if (customId === "ticket:category:add") return createTicketCategoryFromModal(interaction);
    if (customId.startsWith("ticket:category:form:")) return updateTicketCategoryFormSettings(interaction);
    if (customId.startsWith("ticket:category:edit:")) return updateTicketCategoryFromModal(interaction);
    if (customId.startsWith("ticket:category:delete:")) return deleteTicketCategoryFromModal(interaction);
    if (customId.startsWith("ticket:form:category:")) return submitTicketForm(interaction);
    if (customId === "ticket:add-user") return addTicketUser(interaction);
    if (customId === "application:question:add" || customId.startsWith("application:question:edit:")) {
      const guildId = interactionGuildId(interaction);
      if (!guildId || !(await interactionCanManage(interaction))) {
        await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen vragen beheren.");
        return;
      }
      const index = Number.parseInt(customId.split(":")[3] ?? "", 10);
      const guild = getGuildConfig(guildId);
      const value = customId === "application:question:add"
        ? ""
        : guild.applicationQuestions[index] ?? "";
      return showModal(interaction, customId, customId === "application:question:add" ? "Vraag toevoegen" : "Vraag bewerken", [
        { id: "application_question", label: "Vraag", placeholder: "Typ hier de sollicitatievraag", value, paragraph: true },
      ]);
    }
    if (customId === "ticket:rows") return updateTicketRowsPanel(interaction);
    if (customId === "application:rows") return updateApplicationRowsPanel(interaction);
    if (customId === "ticket:edit") return updateTicketPanel(interaction);
    if (customId === "ticket:settings") return updateTicketPanel(interaction);
    if (customId === "application:edit") return updateApplicationPanel(interaction);
    if (customId === "application:settings") return updateApplicationPanel(interaction);
    if (customId === "welcome:edit") return updateWelcomePanel(interaction);
    if (customId === "welcome:settings") return updateWelcomeSettings(interaction);
    if (customId === "levels:xp") return updateLevelXpSettings(interaction);
    if (customId === "levels:announcements") return updateLevelAnnouncementSettings(interaction);
    if (customId === "levels:roles") return updateLevelRoleSettings(interaction);
    if (customId === "rolelist:edit") return updateRoleDirectoryPanel(interaction);
    if (customId === "clock:edit") return updateClockPanel(interaction);
    if (customId === "counting:edit:visual") return updateCountingPanel(interaction);
    if (customId === "counting:edit:text") return updateCountingPanel(interaction);
    if (customId === "counting:edit:emoji") return updateCountingPanel(interaction);
    if (customId === "guess:edit:visual") return updateGuessPanel(interaction);
    if (customId === "guess:edit:text") return updateGuessPanel(interaction);
    if (customId === "giveaway:create") return createGiveawayFromModal(interaction);
    if (customId === "giveaway:edit") return updateGiveawayPanel(interaction);
    if (customId === "mod:warn") return moderationWarn(interaction);
    if (customId === "mod:timeout") return moderationTimeout(interaction);
    if (customId === "mod:clear") return clearMessages(interaction);
    if (customId === "mod:edit") return updateModerationPanel(interaction);
    if (customId === "guess:start") {
      const guildId = interactionGuildId(interaction);
      const values = modalValues(interaction);
      const min = Number.parseInt(values.guess_min ?? "", 10);
      const max = Number.parseInt(values.guess_max ?? "", 10);
      if (!guildId || !(await interactionCanManage(interaction))) {
        await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen een ronde starten.");
        return;
      }
      if (!Number.isInteger(min) || !Number.isInteger(max) || min < 1 || max < min) {
        await sendInteractionResponse(interaction, "Gebruik een geldig bereik, bijvoorbeeld 1 en 100.");
        return;
      }
      const guild = getGuildConfig(guildId);
      const channelId = values.guess_channel?.trim() ? channelIdFromArg(values.guess_channel.trim()) ?? interaction.channel_id : interaction.channel_id;
      if (!channelId) {
        await sendInteractionResponse(interaction, "Kies een geldig kanaal voor de raadronde.");
        return;
      }
      const targetChannelId = await replaceGuessChannel(guildId, channelId, "raad-het-getal");
      guild.guessPanel.minNumber = min;
      guild.guessPanel.maxNumber = max;
      guild.guessChannelId = targetChannelId;
      guild.guessNumber = randomIntBetween(min, max);
      await saveConfig();
      const now = Date.now();
      const timeStr = `<t:${Math.floor(now / 1000)}:T>`;
      await sendMessage(targetChannelId, "", {
        embeds: [{
          title: "🎯 Raad het Getal • Nieuwe Ronde",
          description: `**Raad een getal** tussen **${min}** en **${max}**!\n\nLet op de emoji-reacties onder je bericht:\n• ⬆️ = Getal is **hoger**\n• ⬇️ = Getal is **lager**`,
          fields: [
            { name: "📊 Bereik", value: `${min} tot ${max}`, inline: true },
            { name: "🕐 Gestart op", value: timeStr, inline: true },
          ],
          color: 0x3b82f6,
          ...(guild.ticketPanel.bannerUrl || guild.guessPanel.bannerUrl ? { image: { url: guild.ticketPanel.bannerUrl || guild.guessPanel.bannerUrl } } : {}),
          thumbnail: { url: guild.guessPanel.thumbnailUrl || guild.ticketPanel.thumbnailUrl || DEFAULT_PANEL_THUMBNAIL },
          footer: { text: `Ronde gestart op ${timeStr}` },
          timestamp: new Date(now).toISOString(),
        }],
      });
      await sendMessage(targetChannelId, "", guessPanelPayload(guild));
      await sendInteractionResponse(interaction, `✅ Nieuwe raadronde gestart in <#${targetChannelId}> tussen **${min}** en **${max}**.`);
    }
    return;
  }
  if (interaction.type === 3 && (customId === "mod:whitelist:user" || customId === "mod:whitelist:role")) {
    const selectedId = interaction.data?.values?.[0];
    if (!selectedId) {
      await sendInteractionResponse(interaction, "Selecteer precies één gebruiker of rol.");
      return;
    }
    return completeWhitelistSelection({
      ...interaction,
      data: { ...interaction.data, values: [selectedId], custom_id: `${customId}:${selectedId}` },
    });
  }
  if (interaction.type === 3 && customId === "auditlog:channel:select") {
    return configureAuditLogChannel(interaction);
  }
  if (interaction.type === 3 && customId === "rolelist:edit") {
    const guildId = interactionGuildId(interaction);
    if (!guildId || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen de rollenlijst beheren.");
      return;
    }
    const guild = getGuildConfig(guildId);
    return showModal(interaction, "rolelist:edit", "Rollenlijstteksten bewerken", [
      { id: "rolelist_title", label: "Titel", placeholder: guild.roleDirectoryTitle, value: guild.roleDirectoryTitle },
      { id: "rolelist_description", label: "Introductietekst", placeholder: "Tekst boven de rollen", value: guild.roleDirectoryDescription, paragraph: true, required: false },
      { id: "rolelist_update_text", label: "Timertekst", placeholder: "Update over {timer}", value: guild.roleDirectoryUpdateText },
    ]);
  }
  if (interaction.type === 3 && customId === "rolelist:add") {
    const guildId = interactionGuildId(interaction);
    const roleId = interaction.data?.values?.[0];
    if (!guildId || !roleId || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen de rollenlijst beheren.");
      return;
    }
    const roles = await discordRequest<GuildRole[]>(`/guilds/${guildId}/roles`);
    const role = roles?.find((entry) => entry.id === roleId);
    if (!role || role.managed) {
      await sendInteractionResponse(interaction, "Deze rol kan niet aan de rollenlijst worden toegevoegd.");
      return;
    }
    const guild = getGuildConfig(guildId);
    if (!guild.roleDirectoryRoleIds.includes(roleId)) guild.roleDirectoryRoleIds.push(roleId);
    await saveConfig();
    await refreshRoleDirectoryPanel(guildId);
    await sendInteractionResponse(interaction, "Rol toegevoegd aan de rollenlijst.", true, await roleDirectoryPayload(guildId, guild, 0, true));
    return;
  }
  if (interaction.type === 3 && (customId === "rolelist:remove" || customId.startsWith("rolelist:remove:"))) {
    const guildId = interactionGuildId(interaction);
    const roleId = interaction.data?.values?.[0];
    if (!guildId || !roleId || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen de rollenlijst beheren.");
      return;
    }
    const guild = getGuildConfig(guildId);
    guild.roleDirectoryRoleIds = guild.roleDirectoryRoleIds.filter((id) => id !== roleId);
    await saveConfig();
    await refreshRoleDirectoryPanel(guildId);
    await sendInteractionResponse(interaction, "Rol verwijderd uit de rollenlijst.", true, await roleDirectoryPayload(guildId, guild, 0, true));
    return;
  }
  if (interaction.type === 3 && (customId === "rolelist:page" || customId.startsWith("rolelist:page:"))) {
    const guildId = interactionGuildId(interaction);
    if (!guildId) return;
    const page = Number.parseInt(customId.split(":")[2] ?? "0", 10);
    await sendInteractionResponse(interaction, "", false, await roleDirectoryPayload(guildId, getGuildConfig(guildId), page));
    return;
  }
  if (customId === "rolelist:public" || customId.startsWith("rolelist:public:")) {
    const guildId = interactionGuildId(interaction);
    if (!guildId) return;
    const page = Number.parseInt(customId.split(":")[2] ?? "0", 10);
    await sendInteractionResponse(interaction, "", false, await roleDirectoryPayload(guildId, getGuildConfig(guildId), page));
    return;
  }
  if (customId === "rolelist:manage" || customId.startsWith("rolelist:manage:")) {
    const guildId = interactionGuildId(interaction);
    const page = Number.parseInt(customId.split(":")[2] ?? "0", 10);
    if (!guildId || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen de rollenlijst beheren.");
      return;
    }
    await sendInteractionResponse(interaction, "", true, await roleDirectoryPayload(guildId, getGuildConfig(guildId), page, true));
    return;
  }
  if (interaction.type === 3 && (customId === "ticket:category:edit:select" || customId === "ticket:category:delete:select" || customId === "ticket:category:form:select")) {
    const categoryId = interaction.data?.values?.[0];
    if (!categoryId) {
      await sendInteractionResponse(interaction, "Selecteer één categorie.");
      return;
    }
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    const category = ticketCategoriesForGuild(guild).find((entry) => entry.id === categoryId);
    const row = guild.ticketPanel.layoutRows?.find((entry) => entry.categoryId === categoryId);
    const editing = customId === "ticket:category:edit:select";
    const formSettings = customId === "ticket:category:form:select";
    const roleValue = category?.supportRoleId ? `<@&${category.supportRoleId}>` : "";
    const emojiValue = category?.emoji?.id
      ? category.emoji.animated
        ? `<a:${category.emoji.name ?? "emoji"}:${category.emoji.id}>`
        : `<:${category.emoji.name ?? "emoji"}:${category.emoji.id}>`
      : category?.emoji?.name ?? "";
    return showModal(
      interaction,
      `ticket:category:${formSettings ? "form" : editing ? "edit" : "delete"}:${categoryId}`,
      formSettings ? "Ticketvragen instellen" : editing ? "Categorie bewerken" : "Categorie verwijderen",
      formSettings
        ? [
            { id: "ticket_subject_label", label: "Onderwerp-vraag", placeholder: "Onderwerp", required: false, value: category?.subjectLabel ?? "Onderwerp" },
            { id: "ticket_subject_enabled", label: "Onderwerp aan/uit", placeholder: "aan of uit", value: category?.subjectEnabled === false ? "uit" : "aan" },
            { id: "ticket_description_label", label: "Uitleg-vraag", placeholder: "Uitleg", required: false, value: category?.descriptionLabel ?? "Uitleg" },
            { id: "ticket_description_enabled", label: "Uitleg aan/uit", placeholder: "aan of uit", value: category?.descriptionEnabled === false ? "uit" : "aan" },
          ]
        : editing
        ? [
            { id: "ticket_category_name", label: "Nieuwe naam", placeholder: "Bijvoorbeeld Aankopen", value: category?.name ?? row?.title ?? "" },
            { id: "ticket_category_description", label: "Beschrijving", placeholder: "Waarvoor is deze categorie?", paragraph: true, value: row?.description ?? "" },
            { id: "ticket_category_button", label: "Knoptekst", placeholder: "Aankopen", value: row?.buttonLabel ?? category?.name ?? "" },
            { id: "ticket_category_role", label: "Supportrol", placeholder: "@Rol of rol-ID", required: false, value: roleValue },
            { id: "ticket_category_emoji", label: "Emoji", placeholder: "🎫 of <:naam:123456789>", required: false, value: emojiValue },
          ]
        : [{ id: "ticket_category_confirm", label: "Bevestiging", placeholder: "Typ VERWIJDER" }],
    );
  }
  if (interaction.type === 3 && customId === "application:questions") {
    return showApplicationQuestions(interaction, 0);
  }
  if (interaction.type === 3 && customId.startsWith("application:questions:page:")) {
    return showApplicationQuestions(interaction, Number.parseInt(customId.split(":")[3] ?? "0", 10));
  }
  if (interaction.type === 3 && customId.startsWith("application:question:delete:")) {
    return deleteApplicationQuestion(interaction, Number.parseInt(customId.split(":")[3] ?? "-1", 10));
  }
  if (interaction.type === 3 && customId.startsWith("application:question:edit:")) {
    const guildId = interactionGuildId(interaction);
    const index = Number.parseInt(customId.split(":")[3] ?? "-1", 10);
    const question = guildId ? getGuildConfig(guildId).applicationQuestions[index] : undefined;
    if (question === undefined) {
      await sendInteractionResponse(interaction, "Deze vraag bestaat niet meer.");
      return;
    }
    return showModal(interaction, customId, "Vraag bewerken", [
      { id: "application_question", label: "Vraag", placeholder: "Typ hier de sollicitatievraag", value: question, paragraph: true },
    ]);
  }
  if (customId === "ai:settings") {
    const guildId = interactionGuildId(interaction);
    if (!guildId || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen AI-instellingen beheren.");
      return;
    }
    const guild = getGuildConfig(guildId);
    return showModal(interaction, "ai:settings", "AI-instellingen", [
      { id: "ai_cooldown", label: "Cooldown seconden", placeholder: String(guild.aiChatCooldownSeconds) },
      { id: "ai_context", label: "Contextberichten (0-20)", placeholder: String(guild.aiChatContextMessages) },
      { id: "ai_max_length", label: "Max antwoordlengte", placeholder: String(guild.aiChatMaxResponseLength) },
      { id: "ai_images", label: "Afbeeldingen", placeholder: guild.aiChatImagesEnabled ? "aan" : "uit" },
      { id: "ai_model", label: "Model", placeholder: guild.aiChatModel },
    ]);
  }
  if (customId === "ai:context:clear") {
    const guildId = interactionGuildId(interaction);
    const userId = interactionUserId(interaction);
    if (!guildId || !userId) return;
    aiContexts.delete(`${guildId}:${interaction.channel_id ?? ""}:${userId}`);
    await sendInteractionResponse(interaction, "Jouw AI-context in dit kanaal is gewist.");
    return;
  }
  if (customId.startsWith("nav:")) {
    const guildId = interactionGuildId(interaction);
    if (!guildId) return;
    const nav = customId.slice(4);
    const payload = await panelForNav(guildId, getGuildConfig(guildId), nav);
    if (!payload) return;
    return sendInteractionResponse(interaction, "", true, contextualizePayload(payload, guildId) as JsonRecord);
  }
  if (customId.startsWith("ticket:create:category:")) {
    const categoryId = customId.slice("ticket:create:category:".length);
    const category = getGuildConfig(interactionGuildId(interaction) ?? "").ticketCategories.find((entry) => entry.id === categoryId);
    if (!category) return sendInteractionResponse(interaction, "Deze ticketcategorie bestaat niet meer.");
    const fields = ticketFormFields(category);
    if (!fields.length) return createTicket(interaction, category.type, categoryId);
    return showModal(interaction, `ticket:form:category:${categoryId}`, "Ticket openen", fields);
  }
  if (customId === "ticket:categories") {
    const guildId = interactionGuildId(interaction);
    if (!guildId || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen categorieën beheren.");
      return;
    }
    await ensureUnbanCategory(guildId);
    return sendInteractionResponse(interaction, "", true, ticketCategoryManagerPayload(getGuildConfig(guildId)));
  }
  if (customId === "ticket:category:add") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen categorieën toevoegen.");
      return;
    }
    return showModal(interaction, "ticket:category:add", "Categorie toevoegen", [
      { id: "ticket_category_name", label: "Naam", placeholder: "Bijvoorbeeld Support" },
      { id: "ticket_category_type", label: "Type", placeholder: "bijv. hulp, aankoop of melding" },
      { id: "ticket_category_id", label: "Bestaand category-ID", placeholder: "Optioneel: 123456789012345678", required: false },
      { id: "ticket_category_role", label: "Supportrol", placeholder: "@Rol of rol-ID", required: false },
      { id: "ticket_category_emoji", label: "Emoji", placeholder: "🎫 of <:naam:123456789>", required: false },
    ]);
  }
  if (customId === "ticket:edit") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
      return;
    }
    const panel = getGuildConfig(interactionGuildId(interaction) ?? "").ticketPanel;
    return showModal(interaction, "ticket:edit", "Ticketpanel bewerken", [
      { id: "ticket_panel_title", label: "Titel", placeholder: panel.title, value: panel.title },
      { id: "ticket_panel_description", label: "Beschrijving", placeholder: panel.description.slice(0, 100), value: panel.description, paragraph: true },
      { id: "ticket_panel_banner", label: "Banner URL", placeholder: "https://...", value: panel.bannerUrl ?? "", required: false },
      { id: "ticket_panel_thumbnail", label: "Thumbnail URL", placeholder: "https://...", value: panel.thumbnailUrl ?? "", required: false },
    ]);
  }
  if (customId === "ticket:settings") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen ticketinstellingen beheren.");
      return;
    }
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    const panel = guild.ticketPanel;
    return showModal(interaction, "ticket:settings", "Ticketinstellingen", [
      { id: "ticket_panel_order", label: "Knopvolgorde", placeholder: "categories, edit, settings, rows", value: (panel.buttonOrder ?? ["categories", "edit", "settings", "rows"]).join(", ") },
      { id: "ticket_panel_banner", label: "Banner URL", placeholder: "https://...", value: panel.bannerUrl ?? "", required: false },
      { id: "ticket_panel_thumbnail", label: "Thumbnail URL", placeholder: "https://...", value: panel.thumbnailUrl ?? "", required: false },
      { id: "ticket_channel_prefix", label: "Kanaalnaam-prefix", placeholder: guild.ticketChannelPrefix, value: guild.ticketChannelPrefix },
      { id: "ticket_closed_category_id", label: "Gesloten categorie-ID", placeholder: "ID van de categorie voor gesloten tickets", value: guild.closedTicketCategoryId ?? "", required: false },
      { id: "ticket_panel_rows", label: "Rijen", placeholder: "id|titel|tekst|knop; ...", value: (panel.layoutRows ?? []).map((row) => `${row.id}|${row.title}|${row.description}|${row.buttonLabel}`).join("; "), paragraph: true, required: false },
    ]);
  }
  if (customId === "ticket:rows") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen ticketrijen beheren.");
      return;
    }
    const rows = getGuildConfig(interactionGuildId(interaction) ?? "").ticketPanel.layoutRows ?? [];
    return showModal(interaction, "ticket:rows", "Ticketrijen bewerken", rows.slice(0, 5).map((row) => ({
      id: `ticket_row_${row.id}`,
      label: row.title,
      placeholder: "titel | beschrijving | knop | emoji | category-ID",
      value: panelRowValue(row),
      paragraph: true,
    })));
  }
  if (customId === "ticket:add-user") {
    const channelId = interaction.channel_id;
    const ticket = channelId ? tickets.get(channelId) : undefined;
    if (!ticket || !(await interactionCanManageTicket(interaction, ticket))) {
      await sendInteractionResponse(interaction, "Alleen de ticket-support kan gebruikers toevoegen.");
      return;
    }
    return showModal(interaction, "ticket:add-user", "Gebruiker toevoegen", [
      { id: "ticket_user", label: "Gebruiker", placeholder: "@Gebruiker, naam of gebruikers-ID" },
    ]);
  }
  if (customId === "ticket:close") return closeTicket(interaction);
  if (customId === "ticket:delete") return deleteTicket(interaction);
  if (customId === "ticket:priority") return cycleTicketPriority(interaction);
  if (customId === "ticket:claim") return updateTicket(interaction, "claim");
  if (customId === "ticket:waiting") return updateTicket(interaction, "waiting");
  if (customId === "ticket:reopen") return updateTicket(interaction, "reopen");
  if (customId === "application:start") return startApplication(interaction);
  if (customId === "application:edit") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
      return;
    }
    const panel = getGuildConfig(interactionGuildId(interaction) ?? "").applicationPanel;
    return showModal(interaction, "application:edit", "Sollicitatiepanel bewerken", [
      { id: "application_panel_title", label: "Titel", placeholder: panel.title, value: panel.title },
      { id: "application_panel_description", label: "Beschrijving", placeholder: panel.description.slice(0, 100), value: panel.description, paragraph: true },
      { id: "application_panel_button", label: "Knoplabel", placeholder: panel.buttonLabel, value: panel.buttonLabel },
      { id: "application_panel_banner", label: "Banner URL", placeholder: "https://...", value: panel.bannerUrl ?? "", required: false },
      { id: "application_panel_thumbnail", label: "Thumbnail URL", placeholder: "https://...", value: panel.thumbnailUrl ?? "", required: false },
      { id: "application_panel_rows", label: "Rijen", placeholder: "id|titel|tekst|knop; ...", value: (panel.layoutRows ?? []).map((row) => `${row.id}|${row.title}|${row.description}|${row.buttonLabel}`).join("; "), paragraph: true, required: false },
    ]);
  }
  if (customId === "application:rows") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen sollicitatierijen beheren.");
      return;
    }
    const rows = getGuildConfig(interactionGuildId(interaction) ?? "").applicationPanel.layoutRows ?? [];
    return showModal(interaction, "application:rows", "Sollicitatierijen bewerken", rows.slice(0, 5).map((row) => ({
      id: `application_row_${row.id}`,
      label: row.title,
      placeholder: "titel | beschrijving | knop | emoji | category-ID",
      value: panelRowValue(row),
      paragraph: true,
    })));
  }
  if (customId === "application:settings") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen sollicitatie-instellingen beheren.");
      return;
    }
    const panel = getGuildConfig(interactionGuildId(interaction) ?? "").applicationPanel;
    return showModal(interaction, "application:settings", "Sollicitatie-instellingen", [
      { id: "application_panel_order", label: "Knopvolgorde", placeholder: "start, edit, questions, settings", value: (panel.buttonOrder ?? ["start", "edit", "questions", "settings", "rows"]).join(", ") },
      { id: "application_panel_button", label: "Knoplabel", placeholder: panel.buttonLabel, value: panel.buttonLabel },
      { id: "application_panel_banner", label: "Banner URL", placeholder: "https://...", value: panel.bannerUrl ?? "", required: false },
      { id: "application_panel_thumbnail", label: "Thumbnail URL", placeholder: "https://...", value: panel.thumbnailUrl ?? "", required: false },
    ]);
  }
  if (customId === "welcome:edit") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
      return;
    }
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    return showModal(interaction, "welcome:edit", "Welkom beheren", [
      { id: "welcome_message", label: "Losse tekst (optioneel)", placeholder: "Leeg laten voor alleen de embed", value: guild.welcomeMessage, paragraph: true, required: false },
      { id: "welcome_title", label: "Embedtitel (optioneel)", placeholder: guild.welcomeTitle, value: guild.welcomeTitle, required: false },
      { id: "welcome_description", label: "Embedbeschrijving", placeholder: guild.welcomeDescription, value: guild.welcomeDescription, paragraph: true, required: false },
      { id: "welcome_channel", label: "Kanaal", placeholder: "#welkom of kanaal-ID", required: false },
      { id: "welcome_role", label: "Rol", placeholder: "@Nieuwe leden of rol-ID", required: false },
    ]);
  }
  if (customId === "levels:xp") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen levelinstellingen beheren.");
      return;
    }
    const settings = getGuildConfig(interactionGuildId(interaction) ?? "").leveling;
    return showModal(interaction, "levels:xp", "XP-instellingen", [
      { id: "level_cooldown", label: "Cooldown seconden", placeholder: String(settings.cooldownSeconds), value: String(settings.cooldownSeconds) },
      { id: "level_minimum", label: "Minimum XP", placeholder: String(settings.minimumXp), value: String(settings.minimumXp) },
      { id: "level_maximum", label: "Maximum XP", placeholder: String(settings.maximumXp), value: String(settings.maximumXp) },
    ]);
  }
  if (customId === "levels:roles") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen levelrollen beheren.");
      return;
    }
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    return showModal(interaction, "levels:roles", "Levelrollen", [
      { id: "level_roles", label: "Level | rol", placeholder: "5 | @rol; 10 | @rol2", value: guild.levelRoles.slice().sort((left, right) => left.level - right.level).map((assignment) => `${assignment.level} | <@&${assignment.roleId}>`).join("; "), paragraph: true },
    ]);
  }
  if (customId === "levels:announcements") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen levelmeldingen beheren.");
      return;
    }
    const settings = getGuildConfig(interactionGuildId(interaction) ?? "").leveling;
    return showModal(interaction, "levels:announcements", "Level-upmeldingen", [
      { id: "level_announce", label: "Meldingen aan/uit", placeholder: settings.announceLevelUps ? "aan" : "uit", value: settings.announceLevelUps ? "aan" : "uit" },
      { id: "level_channel", label: "Meldingskanaal", placeholder: "#kanaal of kanaal-ID", value: settings.announceChannelId ? `<#${settings.announceChannelId}>` : "", required: false },
      { id: "level_message", label: "Berichttemplate", placeholder: "{user}, {level}, {xp}", value: settings.announceMessage, paragraph: true },
    ]);
  }
  if (customId === "levels:toggle") {
    const guildId = interactionGuildId(interaction);
    if (!guildId || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen levels beheren.");
      return;
    }
    const guild = getGuildConfig(guildId);
    guild.leveling.enabled = !guild.leveling.enabled;
    await saveConfig();
    await sendInteractionResponse(interaction, `Levels zijn nu **${guild.leveling.enabled ? "ingeschakeld" : "uitgeschakeld"}**.`, true, levelSettingsPayload(guild));
    return;
  }
  if (customId === "welcome:settings") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen welkominstellingen beheren.");
      return;
    }
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    return showModal(interaction, "welcome:settings", "Welkommedia instellen", [
      { id: "welcome_banner", label: "Banner URL", placeholder: "https://...", value: guild.welcomeBannerUrl, required: false },
      { id: "welcome_thumbnail", label: "Thumbnail URL", placeholder: "https://...", value: guild.welcomeThumbnailUrl, required: false },
      { id: "welcome_color", label: "Embedkleur", placeholder: "#2dd4bf", value: `#${guild.welcomeColor.toString(16).padStart(6, "0")}` },
    ]);
  }
  if (customId === "welcome:test") {
    const guildId = interactionGuildId(interaction);
    const user = interaction.member?.user ?? interaction.user;
    if (!guildId || !user || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen een welkomtest sturen.");
      return;
    }
    const sent = await sendWelcomeMessage(guildId, user, interaction.channel_id);
    await sendInteractionResponse(interaction, sent ? "Testwelkomstbericht verstuurd." : "Stel eerst een welkomkanaal in of geef het bot toegang tot het kanaal.");
    return;
  }
  if (customId.startsWith("welcome:say-hello:")) {
    const user = interaction.member?.user ?? interaction.user;
    if (!interaction.guild_id || !interaction.channel_id || !user) return;
    const messageId = interaction.message?.id;
    const welcomedUserId = customId.slice("welcome:say-hello:".length);
    if (user.id === welcomedUserId) {
      await sendInteractionResponse(interaction, "Andere leden kunnen hier hallo zeggen; jij kunt niet op je eigen knop klikken.");
      return;
    }
    if (messageId && welcomeHelloUsedMessages.has(messageId)) {
      await sendInteractionResponse(interaction, "Deze hallo-knop is al gebruikt voor dit welkombericht.");
      return;
    }
    await sendMessage(interaction.channel_id, `👋 <@${user.id}> zegt hallo tegen <@${welcomedUserId}>!`, {
      allowed_mentions: { users: [user.id, welcomedUserId] },
    });
    if (messageId) {
      welcomeHelloUsedMessages.add(messageId);
      await discordRequest(`/channels/${interaction.channel_id}/messages/${messageId}`, {
        method: "PATCH",
        body: JSON.stringify({ components: [] }),
      });
    }
    await sendInteractionResponse(interaction, "Je hallo is verstuurd.");
    return;
  }
  if (customId === "welcome:post") {
    const guildId = interactionGuildId(interaction);
    if (!guildId || !interaction.channel_id || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel plaatsen.");
      return;
    }
    await sendMessage(interaction.channel_id, "", welcomePanelPayload(getGuildConfig(guildId)));
    await sendInteractionResponse(interaction, "Welkombeheerpanel geplaatst.");
    return;
  }
  if (customId === "game:coin" || customId === "game:dice") {
    await sendInteractionResponse(
      interaction,
      customId === "game:coin"
        ? Math.random() > 0.5 ? "Kop!" : "Munt!"
        : `Je gooide **${Math.floor(Math.random() * 6) + 1}**.`,
    );
    return;
  }
  if (customId === "counting:post") {
    const guildId = interactionGuildId(interaction);
    if (!guildId || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel plaatsen.");
      return;
    }
    const guild = getGuildConfig(guildId);
    guild.countingChannelId = interaction.channel_id;
    guild.countingNumber = 1;
    await saveConfig();
    await sendMessage(interaction.channel_id ?? "", "", countingPanelPayload(guild));
    await sendInteractionResponse(interaction, "Tellenpanel geplaatst.");
    return;
  }
  if (customId === "counting:reset") {
    const guildId = interactionGuildId(interaction);
    if (!guildId || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen tellen resetten.");
      return;
    }
    const guild = getGuildConfig(guildId);
    if (!interaction.channel_id) {
      await sendInteractionResponse(interaction, "Dit panel heeft geen geldig kanaal.");
      return;
    }
    await resetGameChannel(guild, interaction.channel_id, "counting");
    await sendInteractionResponse(interaction, "Tellen is gereset, het kanaal is opgeschoond en het startpanel is opnieuw geplaatst.");
    return;
  }
  if (customId === "counting:edit:visual") {
    if (!(await interactionCanManage(interaction))) return;
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    return showModal(interaction, "counting:edit:visual", "Tellenpanel bewerken", [
      { id: "counting_title", label: "Titel", placeholder: guild.countingPanel.title },
      { id: "counting_description", label: "Beschrijving", placeholder: guild.countingPanel.description.slice(0, 100), paragraph: true },
      { id: "counting_banner", label: "Banner URL", placeholder: "https://...", required: false },
      { id: "counting_thumbnail", label: "Thumbnail URL", placeholder: "https://...", required: false },
    ]);
  }
  if (customId === "counting:edit:text") {
    if (!(await interactionCanManage(interaction))) return;
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    return showModal(interaction, "counting:edit:text", "Tellen teksten", [
      { id: "counting_success_text", label: "Succes tekst", placeholder: guild.countingPanel.correctText, paragraph: true },
      { id: "counting_incorrect_text", label: "Fout tekst", placeholder: guild.countingPanel.incorrectText, paragraph: true },
      { id: "counting_next_text", label: "Volgende tekst", placeholder: guild.countingPanel.nextText, paragraph: true },
    ]);
  }
  if (customId === "counting:edit:emoji") {
    if (!(await interactionCanManage(interaction))) return;
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    return showModal(interaction, "counting:edit:emoji", "Tellen emoji", [
      { id: "counting_success_emoji", label: "Succes emoji", placeholder: guild.countingPanel.successEmoji },
      { id: "counting_incorrect_emoji", label: "Fout emoji", placeholder: guild.countingPanel.incorrectEmoji },
    ]);
  }
  if (customId === "guess:start") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen een ronde starten.");
      return;
    }
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    return showModal(interaction, "guess:start", "Raad het getal", [
      { id: "guess_min", label: "Minimum", placeholder: String(guild.guessPanel.minNumber), value: String(guild.guessPanel.minNumber) },
      { id: "guess_max", label: "Maximum", placeholder: String(guild.guessPanel.maxNumber), value: String(guild.guessPanel.maxNumber) },
      { id: "guess_channel", label: "Kanaal ID", placeholder: interaction.channel_id ? `<#${interaction.channel_id}>` : "#spelkanaal", value: guild.guessChannelId ? `<#${guild.guessChannelId}>` : interaction.channel_id ? `<#${interaction.channel_id}>` : "", required: false },
    ]);
  }
  if (customId === "guess:post") {
    const guildId = interactionGuildId(interaction);
    if (!guildId || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel plaatsen.");
      return;
    }
    const guild = getGuildConfig(guildId);
    guild.guessChannelId = interaction.channel_id;
    await saveConfig();
    await sendMessage(interaction.channel_id ?? "", "", guessPanelPayload(guild));
    await sendInteractionResponse(interaction, "Raad-het-getal-panel geplaatst.");
    return;
  }
  if (customId === "guess:stop") {
    const guildId = interactionGuildId(interaction);
    if (!guildId || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen de ronde stoppen.");
      return;
    }
    const guild = getGuildConfig(guildId);
    if (!interaction.channel_id) {
      await sendInteractionResponse(interaction, "Dit panel heeft geen geldig kanaal.");
      return;
    }
    await resetGameChannel(guild, interaction.channel_id, "guess");
    await sendInteractionResponse(interaction, "De ronde is gestopt, het kanaal is opgeschoond en het startpanel is opnieuw geplaatst.");
    return;
  }
  if (customId === "guess:edit:visual") {
    if (!(await interactionCanManage(interaction))) return;
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    return showModal(interaction, "guess:edit:visual", "Raad getal instellingen", [
      { id: "guess_title", label: "Titel", placeholder: guild.guessPanel.title, value: guild.guessPanel.title },
      { id: "guess_description", label: "Beschrijving", placeholder: guild.guessPanel.description.slice(0, 100), value: guild.guessPanel.description, paragraph: true },
      { id: "guess_banner", label: "Banner URL", placeholder: "https://...", value: guild.guessPanel.bannerUrl || "", required: false },
      { id: "guess_thumbnail", label: "Thumbnail URL", placeholder: "https://...", value: guild.guessPanel.thumbnailUrl || "", required: false },
      { id: "guess_min", label: "Minimum getal", placeholder: String(guild.guessPanel.minNumber), value: String(guild.guessPanel.minNumber) },
      { id: "guess_max", label: "Maximum getal", placeholder: String(guild.guessPanel.maxNumber), value: String(guild.guessPanel.maxNumber) },
      { id: "guess_channel", label: "Startkanaal ID", placeholder: guild.guessChannelId ? `<#${guild.guessChannelId}>` : "#kanaal", value: guild.guessChannelId ? `<#${guild.guessChannelId}>` : "", required: false },
    ]);
  }
  if (customId === "guess:edit:text") {
    if (!(await interactionCanManage(interaction))) return;
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    return showModal(interaction, "guess:edit:text", "Raad getal teksten", [
      { id: "guess_higher_text", label: "Hoger tekst", placeholder: guild.guessPanel.higherText },
      { id: "guess_lower_text", label: "Lager tekst", placeholder: guild.guessPanel.lowerText },
      { id: "guess_winner_text", label: "Winnaar tekst", placeholder: guild.guessPanel.winnerText, paragraph: true },
      { id: "guess_start_label", label: "Start knop label", placeholder: guild.guessPanel.startButtonLabel },
    ]);
  }
  if (customId === "clock:in") return clockInteraction(interaction, "in");
  if (customId === "clock:out") return clockInteraction(interaction, "out");
  if (customId === "clock:edit") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
      return;
    }
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    return showModal(interaction, "clock:edit", "Klokpanel bewerken", [
      { id: "clock_title", label: "Titel", placeholder: guild.clockPanel.title },
      {
        id: "clock_description",
        label: "Beschrijving",
        placeholder: guild.clockPanel.description.slice(0, 100),
        paragraph: true,
      },
      { id: "clock_banner", label: "Banner URL", placeholder: "https://..." , required: false },
      { id: "clock_thumbnail", label: "Thumbnail URL", placeholder: "https://...", required: false },
      {
        id: "clock_labels",
        label: "Knoplabels",
        placeholder: "Inklokken | Uitklokken",
      },
    ]);
  }
  if (customId === "clock:post") {
    const guildId = interactionGuildId(interaction);
    if (!guildId || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel plaatsen.");
      return;
    }
    const guild = getGuildConfig(guildId);
    guild.clockChannelId = interaction.channel_id;
    await saveConfig();
    await sendMessage(interaction.channel_id ?? "", "", clockPanelPayload(guild));
    await sendInteractionResponse(interaction, "Klokpanel geplaatst.");
    return;
  }
  if (customId === "clock:settings") {
    await sendInteractionResponse(
      interaction,
      "Gebruik `~config moderatie log #kanaal` voor logs en `~klok rol add 09:00 @Rol` voor tijdrollen. Paneldetails beheer je via Panel bewerken.",
    );
    return;
  }
  if (customId === "giveaway:create") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen giveaways maken.");
      return;
    }
    return showModal(interaction, "giveaway:create", "Nieuwe giveaway", [
        { id: "giveaway_prize", label: "Prijs", placeholder: "Bijvoorbeeld: Discord Nitro", required: true },
        { id: "giveaway_duration", label: "Duur", placeholder: "Bijvoorbeeld: 2h, 30m of 1d", required: true },
        { id: "giveaway_winners", label: "Aantal winnaars", placeholder: "1", required: true },
        {
          id: "giveaway_description",
          label: "Extra beschrijving",
          placeholder: "Optioneel: vertel waarom leden mee willen doen.",
          paragraph: true,
          required: false,
        },
    ]);
  }
  if (customId === "giveaway:edit") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
      return;
    }
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    return showModal(interaction, "giveaway:edit", "Giveawaypanel bewerken", [
      { id: "giveaway_title", label: "Titel", placeholder: guild.giveawayPanel.title },
      {
        id: "giveaway_description",
        label: "Beschrijving",
        placeholder: guild.giveawayPanel.description.slice(0, 100),
        paragraph: true,
      },
      { id: "giveaway_banner", label: "Banner URL", placeholder: "https://...", required: false },
      { id: "giveaway_thumbnail", label: "Thumbnail URL", placeholder: "https://...", required: false },
      { id: "giveaway_emoji", label: "Deelname-emoji", placeholder: "🎉" },
    ]);
  }
  if (customId.startsWith("giveaway:enter:")) {
    return enterGiveaway(interaction, customId.slice("giveaway:enter:".length));
  }
  if (customId.startsWith("giveaway:reroll:")) {
    return rerollGiveaway(interaction, customId.slice("giveaway:reroll:".length));
  }
  if (customId.startsWith("giveaway:end:")) {
    return endGiveawayEarly(interaction, customId.slice("giveaway:end:".length));
  }
  if (customId.startsWith("application:approve:")) {
    return approveApplication(interaction, customId.slice("application:approve:".length));
  }
  if (customId.startsWith("application:reject:")) {
    return rejectApplication(interaction, customId.slice("application:reject:".length));
  }
  if (customId === "clock:stats") {
    return showClockStats(interaction);
  }
  if (customId.startsWith("clock:in:role:")) {
    const roleId = customId.slice("clock:in:role:".length);
    const guildId = interactionGuildId(interaction);
    const userId = interactionUserId(interaction);
    if (!guildId || !userId) return;
    clockSessions.set(`${guildId}:${userId}`, { guildId, userId, startedAt: Date.now(), roleId });
    const embed = {
      title: "✅ Ingeklokt",
      description: `Je bent ingeklokt op **${new Date(Date.now()).toLocaleTimeString("nl-NL")}**`,
      color: 0x10b981,
      thumbnail: { url: DEFAULT_PANEL_THUMBNAIL },
      timestamp: new Date().toISOString(),
    };
    await sendInteractionResponse(interaction, "", true, { embeds: [embed] });
    return;
  }
  if (customId === "invite:check") return checkInvites(interaction);
  if (customId === "invite:create") return createInvite(interaction);
  if (customId === "invite:post") return postInvitePanel(interaction);
  if (customId === "invite:edit") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen het invitepanel bewerken.");
      return;
    }
    const guildId = interactionGuildId(interaction);
    if (!guildId) return;
    const guild = getGuildConfig(guildId);
    return showModal(interaction, "invite:edit", "Invitepanel bewerken", [
      { id: "invite_title", label: "Titel", placeholder: guild.invitePanel.title },
      { id: "invite_description", label: "Beschrijving", placeholder: guild.invitePanel.description.slice(0, 100), paragraph: true },
      { id: "invite_banner", label: "Banner URL", placeholder: "Leeg = ticketbanner", required: false },
      { id: "invite_thumbnail", label: "Thumbnail URL", placeholder: "Leeg = ticketthumbnail", required: false },
      { id: "invite_channel", label: "Invitekanaal", placeholder: "#kanaal of kanaal-ID", required: false },
    ]);
  }
  if (customId === "invite:settings") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen invite-instellingen beheren.");
      return;
    }
    const guildId = interactionGuildId(interaction);
    if (!guildId) return;
    const guild = getGuildConfig(guildId);
    return showModal(interaction, "invite:settings", "Invite-instellingen", [
      { id: "invite_labels", label: "Knoplabels", placeholder: `${guild.invitePanel.checkButtonLabel} | ${guild.invitePanel.createButtonLabel}` },
      { id: "invite_channel", label: "Invitekanaal", placeholder: "#kanaal of kanaal-ID", required: false },
      { id: "invite_color", label: "Embedkleur", placeholder: "#36393f", required: false },
    ]);
  }
  if (customId.startsWith("poll:vote:")) {
    const [, , pollId, option] = customId.split(":");
    return votePoll(interaction, pollId, Number.parseInt(option ?? "-1", 10));
  }
  if (customId.startsWith("application:approve:")) {
    return decideApplication(
      interaction,
      "approve",
      customId.slice("application:approve:".length),
    );
  }
  if (customId.startsWith("application:reject:")) {
    return decideApplication(
      interaction,
      "reject",
      customId.slice("application:reject:".length),
    );
  }
  if (customId === "mod:warn") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen modereren.");
      return;
    }
    return showModal(interaction, "mod:warn", "Lid waarschuwen", [
      { id: "mod_target", label: "Lid", placeholder: "@Lid of user-ID" },
      { id: "mod_reason", label: "Reden", placeholder: "Waarom krijgt dit lid een waarschuwing?", paragraph: true },
    ]);
  }
  if (customId === "mod:timeout") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen modereren.");
      return;
    }
    return showModal(interaction, "mod:timeout", "Time-out geven", [
      { id: "timeout_target", label: "Lid", placeholder: "@Lid of user-ID" },
      { id: "timeout_duration", label: "Duur", placeholder: "Bijvoorbeeld: 30m of 2h" },
      { id: "timeout_reason", label: "Reden", placeholder: "Optioneel", required: false },
    ]);
  }
  if (customId === "mod:clear") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen modereren.");
      return;
    }
    return showModal(interaction, "mod:clear", "Berichten wissen", [
      { id: "clear_amount", label: "Aantal", placeholder: "1 tot 100" },
    ]);
  }
  if (customId === "mod:edit") {
    if (!(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit panel beheren.");
      return;
    }
    const guild = getGuildConfig(interactionGuildId(interaction) ?? "");
    return showModal(interaction, "mod:edit", "Moderatiepanel bewerken", [
      { id: "mod_panel_title", label: "Titel", placeholder: guild.moderationPanel.title },
      {
        id: "mod_panel_description",
        label: "Beschrijving",
        placeholder: guild.moderationPanel.description.slice(0, 100),
        paragraph: true,
      },
      { id: "mod_panel_banner", label: "Banner URL", placeholder: "https://...", required: false },
      { id: "mod_panel_thumbnail", label: "Thumbnail URL", placeholder: "https://...", required: false },
    ]);
  }
  if (customId === "mod:lock" || customId === "mod:unlock") {
    const guildId = interactionGuildId(interaction);
    if (!guildId || !interaction.channel_id || !(await interactionCanManage(interaction))) {
      await sendInteractionResponse(interaction, "Alleen bevoegde teamleden kunnen dit kanaal beheren.");
      return;
    }
    await discordRequest(`/channels/${interaction.channel_id}/permissions/${guildId}`, {
      method: "PUT",
      body: JSON.stringify({
        type: 0,
        allow: customId === "mod:unlock" ? "0" : "0",
        deny: customId === "mod:lock" ? "2048" : "0",
      }),
    });
    await sendInteractionResponse(
      interaction,
      customId === "mod:lock" ? "Kanaal vergrendeld." : "Kanaal ontgrendeld.",
    );
    return;
  }
  if (customId.startsWith("help:")) {
    const pages: Record<string, string> = {
      "help:ticket": "`~setup ticket` plaatst het ticketpanel. Maak daarna zelf categorieën aan; elke categorie opent een eigen privékanaal.",
      "help:application": "`~setup sollicitatie` plaatst DM-sollicitaties. Vragen beheer je met `~sollicitatie vraag add|remove|list`.",
      "help:clock": "`~setupklok` plaatst het in- en uitklokpanel. `~klokinpanel` opent de privébeheerknoppen.",
      "help:moderation": "`~setupmoderatie` plaatst waarschuwing, time-out, clear en lock/unlock als privéformulieren. Waarschuwingen beheer je met `~warnings`, `~warnremove` en `~warnclear`.",
      "help:admin": "Moderatie: `~warn`, `~warnings`, `~warnremove`, `~warnclear`, `~modstats`, `~mute`, `~unmute`, `~kick`, `~softban`, `~unban`, `~clear`, `~nuke`, `~slowmode`, `~lock` en `~unlock`. Utilities: `~avatar`, `~servericon`, `~roleinfo`, `~channelinfo`, `~memberroles`, `~nick`, `~roleadd`, `~roleremove`, `~timeout`, `~untimeout`, `~clearuser`, `~announce`, `~say` en `~timer`. Auditlogs stel je in met `~logs`.",
      "help:giveaway": "`~setupgiveaway` plaatst het giveawaybeheerpanel. Maak en bewerk giveaways via buttons en modals.",
      "help:games": "Games: `~spel munt`, `~spel dobbel`, `~spel steen steen`, `~spel 8ball`, `~spel casino`, `~spel roulette`, `~spel hogerlager` en `~spel blackjack`. Ook `~tellen` en `~raad` zijn beschikbaar.",
      "help:roles": "`~rollen` toont de publieke rollenlijst. Beheerders kunnen via het rollenlijstpanel rollen toevoegen of verwijderen met een dropdown.",
      "help:levels": "`!rank` of `~rank` toont je rankkaart met avatar, level, XP en voortgang. Gebruik `!leaderboard` of `~leaderboard` voor de top 10.",
      "help:invites": "`~setupinvite` plaatst het invitepanel. Leden kunnen hun invites controleren en een persoonlijke invite-link maken; de leaderboard wordt elke 5 minuten vernieuwd.",
    };
    await sendInteractionResponse(interaction, pages[customId] ?? "Geen helptekst beschikbaar.");
  }
}

async function handleGatewayEvent(event: GatewayEvent) {
  if (event.s !== undefined) sequence = event.s;
  if (event.op === 10) {
    const heartbeatInterval = Number((event.d as JsonRecord)?.heartbeat_interval ?? 45000);
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    heartbeatTimer = setInterval(() => {
      gateway?.send(JSON.stringify({ op: 1, d: sequence }));
    }, heartbeatInterval);
    gateway?.send(
      JSON.stringify({
        op: 2,
        d: {
          token: token(),
          intents: 37379,
          properties: { os: "linux", browser: "community-bot", device: "community-bot" },
        },
      }),
    );
    return;
  }
  if (event.op === 7) {
    gateway?.close();
    return;
  }
  if (event.op === 9) {
    connected = false;
    scheduleReconnect();
    return;
  }
  if (event.t === "READY") {
    const data = event.d as JsonRecord;
    const user = data.user as { id?: string; username?: string } | undefined;
    const application = data.application as { id?: string } | undefined;
    botUserId = user?.id;
    applicationId = application?.id ?? botUserId;
    connected = true;
    logger.info({ username: user?.username }, "Discord bot connected");
    void registerPrivatePanelCommands();
    void refreshAllPanelsOnStartup();
    const sessionStartLimit = data.session_start_limit as JsonRecord | undefined;
    if (sessionStartLimit) {
      logger.info(
        { remaining: sessionStartLimit.remaining },
        "Discord session quota available",
      );
    }
    return;
  }
  if (["GUILD_MEMBER_ADD", "GUILD_MEMBER_REMOVE", "MESSAGE_DELETE", "MESSAGE_UPDATE", "CHANNEL_CREATE", "CHANNEL_DELETE"].includes(event.t ?? "")) {
    if (event.t === "GUILD_MEMBER_ADD") await handleWelcome(event.d ?? {});
    void handleAuditGatewayEvent(event);
    return;
  }
  if (event.t === "INTERACTION_CREATE")
    return handleInteraction(event.d as unknown as DiscordInteraction);
  if (event.t !== "MESSAGE_CREATE") return;
  const message = event.d as unknown as DiscordMessage;
  if (!message.author || message.author.id === botUserId || message.author.bot) return;
  const ticket = tickets.get(message.channel_id);
  if (ticket && message.author.id !== ticket.userId) {
    const category = getGuildConfig(ticket.guildId).ticketCategories.find((entry) => entry.id === ticket.categoryId);
    if (category?.supportRoleId && message.member?.roles?.includes(category.supportRoleId)) {
      ticket.lastStaffMessageAt = Date.now();
      void saveConfig();
    }
  }
  if (!message.guild_id && (await handleApplicationAnswer(message))) return;
  if (message.guild_id) {
    if (await handleWhitelistDurationMessage(message)) return;
    if (await handleAIChatMessage(message)) return;
    if (await moderateMessage(message)) return;
    if (await handleCountingAndGuess(message)) return;
    if (!splitCommand(message.content)) await awardMessageXp(message);
  }
  await handleCommand(message);
}

function scheduleReconnect() {
  if (stopping || reconnectTimer) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = undefined;
    connectGateway().catch((error: unknown) => {
      logger.error({ error }, "Discord bot reconnect failed");
      scheduleReconnect();
    });
  }, 5000);
}

async function connectGateway() {
  if (!token() || !WebSocketCtor) {
    logger.warn(
      "Discord bot is paused: add DISCORD_TOKEN to Secrets and restart the API workflow",
    );
    return;
  }
  const gatewayInfo = await discordRequest<{ url?: string }>("/gateway/bot");
  gatewayUrl = gatewayInfo?.url
    ? `${gatewayInfo.url}?v=10&encoding=json`
    : gatewayUrl;
  const socket = new WebSocketCtor(gatewayUrl);
  gateway = socket;
  socket.onopen = () => logger.info("Discord Gateway socket opened");
  socket.onmessage = (event) => {
    try {
      void handleGatewayEvent(JSON.parse(event.data) as GatewayEvent);
    } catch (error) {
      logger.error({ error }, "Invalid Discord Gateway event");
    }
  };
  socket.onerror = (error) => logger.warn({ error }, "Discord Gateway socket error");
  socket.onclose = () => {
    connected = false;
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    heartbeatTimer = undefined;
    logger.warn("Discord Gateway socket closed");
    scheduleReconnect();
  };
}

async function registerPrivatePanelCommands() {
  if (!applicationId) return;
  for (const guildId of Object.keys(config.guilds)) {
    await discordRequest(`/applications/${applicationId}/guilds/${guildId}/commands`, {
      method: "POST",
      body: JSON.stringify({ name: "panel", description: "Open het privé beheerpanel", type: 1 }),
    });
  }
}

export async function startDiscordBot() {
  await loadConfig();
  if (!token()) {
    logger.warn("DISCORD_TOKEN is not set; Discord bot will start when a token is added");
    return;
  }
  if (!WebSocketCtor) {
    logger.error("This Node runtime does not expose WebSocket; Discord bot cannot start");
    return;
  }
  for (const [guildId, storedGuild] of Object.entries(config.guilds)) {
    const guild = getGuildConfig(guildId);
    await ensureUnbanCategory(guildId);
    for (const giveaway of Object.values(guild.giveaways ?? {})) {
      scheduleGiveaway(giveaway);
    }
    if (guild !== storedGuild || guild.giveaways !== storedGuild.giveaways) {
      await saveConfig();
    }
  }
  for (const reminder of reminders.values()) scheduleReminder(reminder);
  for (const guildId of Object.keys(config.guilds)) await syncGuildInvites(guildId);
  stopping = false;
  await connectGateway();
  levelLeaderboardTimer = setInterval(() => {
    void refreshLevelLeaderboards();
  }, 60_000);
  roleDirectoryTimer = setInterval(() => {
    void refreshRoleDirectoryPanels();
  }, 60_000);
  setInterval(() => {
    void updateClockRoles();
  }, 60_000);
  inviteSyncTimer = setInterval(() => {
    void updateInvitePanels();
  }, 5 * 60_000);
}

export function stopDiscordBot() {
  stopping = true;
  connected = false;
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  if (reconnectTimer) clearTimeout(reconnectTimer);
  if (inviteSyncTimer) clearInterval(inviteSyncTimer);
  if (roleDirectoryTimer) clearInterval(roleDirectoryTimer);
  if (levelLeaderboardTimer) clearInterval(levelLeaderboardTimer);
  inviteSyncTimer = undefined;
  roleDirectoryTimer = undefined;
  levelLeaderboardTimer = undefined;
  for (const timer of reminderTimers.values()) clearTimeout(timer);
  reminderTimers.clear();
  gateway?.close();
}